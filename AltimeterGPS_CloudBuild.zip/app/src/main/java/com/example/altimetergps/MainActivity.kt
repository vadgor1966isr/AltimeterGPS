package com.example.altimetergps

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.widget.*
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity(), LocationListener, SensorEventListener {
    private lateinit var lm: LocationManager
    private lateinit var current: TextView
    private lateinit var average: TextView
    private lateinit var terrain: TextView
    private lateinit var hAcc: TextView
    private lateinit var status: TextView
    private lateinit var updated: TextView
    private lateinit var speedView: TextView
    private lateinit var compassView: TextView
    private lateinit var terrainUpdatedView: TextView
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private var lastTerrainUpdateTime = 0L
    private lateinit var coordinates: TextView
    private lateinit var mapView: WebView
    private var mapReady = false
    private var mapHasLocation = false
    private var latestCoordinates = ""
    private val samples = ArrayDeque<Pair<Long, Double>>()
    private val executor = Executors.newSingleThreadExecutor()
    private var lastTerrainFetch = 0L
    private var lastLat = 0.0
    private var lastLon = 0.0
    private var lastTerrainLat = 0.0
    private var lastTerrainLon = 0.0
    private var lastUiUpdate = 0L
    private var latestGpsAltitude: Double? = null
    private var terrainAltitude: Double? = null
    private var lastValidGpsAltitude: Double? = null
    private var lastValidAverageAltitude: Double? = null
    private val requestCode = 101
    private val demZoom = 12
    private val demDownloading = AtomicBoolean(false)
    private var demProgressDialog: android.app.AlertDialog? = null
    private var demProgressText: TextView? = null
    private var demProgressBar: ProgressBar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 28)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF10243A.toInt(), 0xFF183B55.toInt(), 0xFF0D1B2A.toInt())
            )
        }
        fun text(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(4, 5, 4, 5)
        }
        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16, 13, 16, 13)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF203B52.toInt())
                cornerRadius = 24f
                setStroke(1, 0xFF426078.toInt())
            }
            elevation = 5f
        }
        fun addCard(v: android.view.View, top: Int = 10) {
            page.addView(v, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = top
            })
        }

        page.addView(text(14f, 0xFF9DB9CC.toInt(), true).apply { text = "GEOTRACKER" })
        page.addView(text(27f, 0xFFFFFFFF.toInt(), true).apply { text = "МОЁ МЕСТОПОЛОЖЕНИЕ" })
        page.addView(text(13f, 0xFF9DB9CC.toInt()).apply { text = "ТЕКУЩЕЕ МЕСТОПОЛОЖЕНИЕ" })

        val mapCard = card()
        mapCard.addView(text(14f, 0xFF9FC3D9.toInt(), true).apply { text = "КАРТА ТЕКУЩЕГО МЕСТОПОЛОЖЕНИЯ" })
        mapView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    mapReady = true
                    if (lastLat != 0.0 || lastLon != 0.0) updateMapLocation(lastLat, lastLon)
                }
            }
            setBackgroundColor(0xFFE7E5DF.toInt())
            overScrollMode = android.view.View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = false
        }
        mapCard.addView(mapView, LinearLayout.LayoutParams(-1, dp(280)).apply {
            topMargin = 8
        })
        val mapButton = Button(this).apply {
            text = "ПОКАЗАТЬ МОЁ МЕСТОПОЛОЖЕНИЕ"
            setOnClickListener {
                if (mapHasLocation) mapView.evaluateJavascript("map.setView([$lastLat,$lastLon],16,{animate:false});", null)
                else Toast.makeText(this@MainActivity, "Ожидание координат GPS…", Toast.LENGTH_SHORT).show()
            }
        }
        mapCard.addView(mapButton)
        addCard(mapCard, 12)
        mapView.loadDataWithBaseURL("https://altimetergps.local/", mapHtml(), "text/html", "UTF-8", null)

        // Равноценные показатели под картой: высота, местоположение и компас.
        val dataCard = card()
        fun addMetric(title: String, value: TextView) {
            dataCard.addView(text(12f, 0xFF9FC3D9.toInt(), true).apply { text = title })
            dataCard.addView(value)
        }
        terrain = text(17f, 0xFFFFFFFF.toInt(), true).apply { text = "Загрузка…" }
        addMetric("ВЫСОТА НАД УРОВНЕМ МОРЯ", terrain)
        coordinates = text(16f, 0xFFFFFFFF.toInt()).apply { text = "Широта: —\nДолгота: —" }
        addMetric("МЕСТОПОЛОЖЕНИЕ", coordinates)
        compassView = text(17f, 0xFFFFFFFF.toInt(), true).apply { text = "Компас: —" }
        addMetric("НАПРАВЛЕНИЕ", compassView)
        val copyButton = Button(this).apply {
            text = "КОПИРОВАТЬ КООРДИНАТЫ"
            setOnClickListener {
                if (latestCoordinates.isNotEmpty()) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GPS coordinates", latestCoordinates))
                    Toast.makeText(this@MainActivity, "Координаты скопированы", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this@MainActivity, "Пока нет координат GPS", Toast.LENGTH_SHORT).show()
            }
        }
        dataCard.addView(copyButton)
        addCard(dataCard, 12)

        val offlineCard = card()
        offlineCard.addView(text(15f, 0xFF9FC3D9.toInt(), true).apply { text = "ОФЛАЙН-МОДЕЛИ ВЫСОТ" })
        offlineCard.addView(text(12f, 0xFFD7E5ED.toInt()).apply {
            text = "Скачайте территорию заранее. После загрузки высота определяется без интернета."
        })
        offlineCard.addView(Button(this).apply {
            text = "УПРАВЛЕНИЕ ОФЛАЙН-ДАННЫМИ"
            setOnClickListener { showOfflineDemDialog() }
        })
        addCard(offlineCard, 12)

        val infoCard = card()
        hAcc = text(14f, 0xFFD7E5ED.toInt()).apply { text = "Точность координат: —" }
        speedView = text(16f, 0xFFD7E5ED.toInt(), true).apply { text = "Скорость: — км/ч" }
        terrainUpdatedView = text(12f, 0xFF9DB9CC.toInt()).apply { text = "Высота обновлена: —" }
        status = text(15f, 0xFF7FE0A0.toInt(), true).apply { text = "Ожидание GPS…" }
        updated = text(12f, 0xFF9DB9CC.toInt()).apply { text = "" }
        infoCard.addView(hAcc)
        infoCard.addView(speedView)
        infoCard.addView(terrainUpdatedView)
        infoCard.addView(status)
        addCard(infoCard)

        val buttons = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "Обновить GPS"; setOnClickListener { checkPermission() } })
        buttons.addView(Button(this).apply {
            text = "Сбросить"
            setOnClickListener { samples.clear(); latestGpsAltitude = null; lastValidGpsAltitude = null; lastValidAverageAltitude = null; updateGpsAltitudeDisplay(); status.text = "Измерения сброшены" }
        })
        addCard(buttons)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(page) })
        checkPermission()
    }

    private fun updateGpsAltitudeDisplay() {
        val reference = terrainAltitude
        if (reference != null && abs(reference) >= 1.0) {
            val gps = latestGpsAltitude
            if (gps != null && abs(gps - reference) <= abs(reference) * 0.20) {
                lastValidGpsAltitude = gps
            }
            val avg = if (samples.isNotEmpty()) samples.map { it.second }.average() else null
            if (avg != null && abs(avg - reference) <= abs(reference) * 0.20) {
                lastValidAverageAltitude = avg
            }
        }
        average.text = lastValidAverageAltitude?.let {
            String.format(Locale.getDefault(), "%.1f m", it)
        } ?: "— m"
    }

    private fun formatDms(value: Double, latitude: Boolean): String {
        val absolute = abs(value)
        val degrees = absolute.toInt()
        val minutesFull = (absolute - degrees) * 60.0
        val minutes = minutesFull.toInt()
        val seconds = (minutesFull - minutes) * 60.0
        val hemisphere = if (latitude) {
            if (value >= 0) "N" else "S"
        } else {
            if (value >= 0) "E" else "W"
        }
        return String.format(Locale.US, "%d° %02d′ %05.2f″ %s", degrees, minutes, seconds, hemisphere)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun updateMapLocation(lat: Double, lon: Double) {
        if (!mapReady) return
        mapView.evaluateJavascript("if(window.updateGpsPosition){window.updateGpsPosition($lat,$lon);}", null)
    }

    private fun mapHtml(): String = """<!DOCTYPE html>
<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>html,body,#map{height:100%;width:100%;margin:0;padding:0;background:#e7e5df} .leaflet-control-attribution{font-size:9px}</style>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script></head>
<body><div id="map"></div><script>
var map=L.map('map',{zoomControl:true}).setView([32.7,35.3],7);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
 maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
var gpsMarker=null;
window.updateGpsPosition=function(lat,lon){
 var point=[lat,lon];
 if(!gpsMarker){gpsMarker=L.marker(point).addTo(map).bindPopup('Ваше местоположение');map.setView(point,16);}
 else{gpsMarker.setLatLng(point);}
};
setTimeout(function(){map.invalidateSize();},300);
</script></body></html>"""

    private fun checkPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestCode)
        else startGps()
    }
    private fun startGps() {
        try {
            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { status.text="Включите Местоположение / GPS"; return }
            lm.removeUpdates(this); status.text="Поиск спутников GPS…"
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000L,5f,this,Looper.getMainLooper())
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
        } catch (_:Exception) { status.text="Не удалось запустить GPS" }
    }
    override fun onLocationChanged(loc:Location) {
        val now=System.currentTimeMillis()
        val recent=samples.filter { now-it.first<=30000L }.map { it.second }.sorted()
        val median=if(recent.isEmpty()) null else recent[recent.size/2]
        if(median==null || abs(loc.altitude-median)<=80.0 || recent.size<3) samples.addLast(now to loc.altitude)
        while(samples.isNotEmpty() && now-samples.first().first>30000L) samples.removeFirst()
        if (now - lastUiUpdate < 5000L) {
            lastLat = loc.latitude
            lastLon = loc.longitude
            latestCoordinates = "${formatDms(loc.latitude, true)}, ${formatDms(loc.longitude, false)}"
            mapHasLocation = true
            return
        }
        lastUiUpdate = now
        latestGpsAltitude = loc.altitude
        latestCoordinates = "${formatDms(loc.latitude, true)}, ${formatDms(loc.longitude, false)}"
        lastLat = loc.latitude
        lastLon = loc.longitude
        mapHasLocation = true
        updateMapLocation(loc.latitude, loc.longitude)
        coordinates.text = "Широта: ${formatDms(loc.latitude, true)}\nДолгота: ${formatDms(loc.longitude, false)}"
        updateGpsAltitudeDisplay()
        hAcc.text=String.format(Locale.getDefault(),"Точность координат: ±%.0f м",loc.accuracy)
        speedView.text = if (loc.hasSpeed()) {
            String.format(Locale.getDefault(), "Скорость: %.1f км/ч", loc.speed * 3.6f)
        } else {
            "Скорость: — км/ч"
        }
        status.text="GPS работает • измерений: ${samples.size}"
        val moved = if (lastTerrainFetch == 0L) true else {
            val distance = FloatArray(1)
            Location.distanceBetween(lastTerrainLat, lastTerrainLon, loc.latitude, loc.longitude, distance)
            distance[0] > 100f
        }
        if (lastTerrainFetch == 0L || (terrainAltitude == null && now - lastTerrainFetch > 30000L) ||
            now - lastTerrainFetch > 300000L || (moved && now - lastTerrainFetch > 120000L)) {
            lastTerrainFetch=now; lastTerrainLat=loc.latitude; lastTerrainLon=loc.longitude; fetchTerrain(loc.latitude,loc.longitude)
        }
    }
    private fun fetchTerrain(lat:Double,lon:Double) {
        executor.execute {
            val value = readOfflineElevation(lat, lon)
            runOnUiThread {
                if (value != null && value.isFinite()) {
                    terrainAltitude = value
                    terrain.text = String.format(Locale.getDefault(), "%.1f m", value)
                    lastTerrainUpdateTime = System.currentTimeMillis()
                    terrainUpdatedView.text = "Офлайн-модель • " +
                        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastTerrainUpdateTime))
                    status.text = "Высота получена из офлайн-модели"
                    updateGpsAltitudeDisplay()
                } else {
                    terrain.text = "Нет офлайн-данных"
                    terrainUpdatedView.text = "Для этой территории модель не загружена"
                    status.text = "Откройте «Офлайн-модели высот» и скачайте регион"
                }
            }
        }
    }

    private fun demDir(): File = File(filesDir, "dem/$demZoom").apply { mkdirs() }
    private fun tileFile(x: Int, y: Int): File = File(demDir(), "${x}_${y}.png")

    private fun tileXY(lat: Double, lon: Double, zoom: Int): Pair<Int, Int> {
        val n = 1 shl zoom
        val x = kotlin.math.floor((lon + 180.0) / 360.0 * n).toInt().coerceIn(0, n - 1)
        val latRad = Math.toRadians(lat.coerceIn(-85.05112878, 85.05112878))
        val y = kotlin.math.floor((1.0 - kotlin.math.ln(kotlin.math.tan(latRad) + 1.0 / kotlin.math.cos(latRad)) / Math.PI) / 2.0 * n).toInt().coerceIn(0, n - 1)
        return x to y
    }

    private fun readOfflineElevation(lat: Double, lon: Double): Double? {
        val (x, y) = tileXY(lat, lon, demZoom)
        val file = tileFile(x, y)
        if (!file.exists()) return null
        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return null
        try {
            val n = 1 shl demZoom
            val xf = (lon + 180.0) / 360.0 * n
            val latRad = Math.toRadians(lat.coerceIn(-85.05112878, 85.05112878))
            val yf = (1.0 - kotlin.math.ln(kotlin.math.tan(latRad) + 1.0 / kotlin.math.cos(latRad)) / Math.PI) / 2.0 * n
            val px = (((xf - x) * 256.0).toInt()).coerceIn(0, 255)
            val py = (((yf - y) * 256.0).toInt()).coerceIn(0, 255)
            val color = bitmap.getPixel(px, py)
            val r = android.graphics.Color.red(color)
            val g = android.graphics.Color.green(color)
            val b = android.graphics.Color.blue(color)
            return (r * 256.0 + g + b / 256.0) - 32768.0
        } finally { bitmap.recycle() }
    }

    private data class DemCountry(val name: String, val south: Double, val west: Double, val north: Double, val east: Double)

    // Approximate country bounding boxes. The user selects a country by its familiar name;
    // coordinates remain internal and are never requested from the user.
    private val demCountries = listOf(
        DemCountry("Израиль", 29.4, 34.3, 33.4, 35.9),
        DemCountry("Италия", 35.3, 6.5, 47.2, 18.8),
        DemCountry("Франция", 41.3, -5.2, 51.2, 9.7),
        DemCountry("Норвегия", 57.9, 4.0, 71.2, 31.2),
        DemCountry("Швейцария", 45.8, 5.9, 47.9, 10.6),
        DemCountry("Австрия", 46.4, 9.5, 49.1, 17.2),
        DemCountry("Германия", 47.2, 5.8, 55.1, 15.1),
        DemCountry("Польша", 49.0, 14.1, 54.9, 24.2),
        DemCountry("Чехия", 48.5, 12.1, 51.1, 18.9),
        DemCountry("Словакия", 47.7, 16.8, 49.6, 22.6),
        DemCountry("Словения", 45.4, 13.4, 46.9, 16.6),
        DemCountry("Хорватия", 42.3, 13.4, 46.6, 19.5),
        DemCountry("Венгрия", 45.7, 16.1, 48.6, 22.9),
        DemCountry("Румыния", 43.6, 20.2, 48.3, 29.8),
        DemCountry("Болгария", 41.2, 22.3, 44.3, 28.6),
        DemCountry("Греция", 34.8, 19.3, 41.8, 29.7),
        DemCountry("Испания", 27.6, -18.2, 43.8, 4.4),
        DemCountry("Португалия", 36.9, -9.6, 42.2, -6.2),
        DemCountry("Великобритания", 49.9, -8.2, 59.5, 2.0),
        DemCountry("Ирландия", 51.4, -10.7, 55.5, -5.4),
        DemCountry("Нидерланды", 50.7, 3.2, 53.7, 7.3),
        DemCountry("Бельгия", 49.5, 2.5, 51.6, 6.4),
        DemCountry("Дания", 54.5, 8.0, 57.8, 15.2),
        DemCountry("Швеция", 55.3, 10.9, 69.1, 24.2),
        DemCountry("Финляндия", 59.8, 20.5, 70.1, 31.6),
        DemCountry("Исландия", 63.3, -24.5, 66.6, -13.3),
        DemCountry("Турция", 35.8, 25.7, 42.1, 44.8),
        DemCountry("Грузия", 41.0, 40.0, 43.6, 46.8),
        DemCountry("Армения", 38.8, 43.4, 41.3, 46.6),
        DemCountry("Азербайджан", 38.4, 44.8, 41.9, 51.0),
        DemCountry("Кипр", 34.5, 32.2, 35.7, 34.7),
        DemCountry("Иордания", 29.2, 34.9, 33.4, 39.3),
        DemCountry("Египет", 22.0, 24.7, 31.7, 36.9),
        DemCountry("Марокко", 27.6, -13.2, 35.9, -1.0),
        DemCountry("США", 24.4, -125.0, 49.5, -66.9),
        DemCountry("Канада", 41.7, -141.0, 83.1, -52.6),
        DemCountry("Мексика", 14.5, -118.4, 32.7, -86.7),
        DemCountry("Бразилия", -33.8, -73.9, 5.3, -34.8),
        DemCountry("Аргентина", -55.1, -73.6, -21.8, -53.6),
        DemCountry("Чили", -55.9, -75.7, -17.5, -66.4),
        DemCountry("Япония", 24.0, 122.9, 45.6, 153.0),
        DemCountry("Южная Корея", 33.1, 124.6, 38.6, 131.9),
        DemCountry("Китай", 18.1, 73.5, 53.6, 134.8),
        DemCountry("Таиланд", 5.6, 97.3, 20.5, 105.7),
        DemCountry("Вьетнам", 8.2, 102.1, 23.4, 109.5),
        DemCountry("Индия", 6.7, 68.1, 35.5, 97.4),
        DemCountry("Непал", 26.3, 80.0, 30.5, 88.2),
        DemCountry("Австралия", -43.7, 113.1, -10.0, 153.7),
        DemCountry("Новая Зеландия", -47.4, 166.4, -34.0, 178.6)
    )

    private fun showOfflineDemDialog() {
        val options = arrayOf("Выбрать страну", "Управление загруженными данными")
        android.app.AlertDialog.Builder(this)
            .setTitle("Офлайн-модели высот")
            .setItems(options) { _, which ->
                if (which == 0) showCountryPicker() else showDownloadedDemFiles()
            }.setNegativeButton("Закрыть", null).show()
    }

    private fun showCountryPicker() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }
        val search = EditText(this).apply {
            hint = "Поиск страны…"
            setSingleLine(true)
        }
        val list = ListView(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, demCountries.map { it.name })
        list.adapter = adapter
        layout.addView(search)
        layout.addView(list, LinearLayout.LayoutParams(-1, dp(360)))
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Выберите страну")
            .setView(layout)
            .setNegativeButton("Закрыть", null)
            .create()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter.filter(s)
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        list.setOnItemClickListener { _, _, position, _ ->
            val selectedName = adapter.getItem(position) ?: return@setOnItemClickListener
            val country = demCountries.firstOrNull { it.name == selectedName } ?: return@setOnItemClickListener
            dialog.dismiss()
            confirmDemDownload(country.name, country.south, country.west, country.north, country.east)
        }
        dialog.show()
    }

    private fun confirmDemDownload(name: String, south: Double, west: Double, north: Double, east: Double) {
        val sw=tileXY(south, west, demZoom); val ne=tileXY(north, east, demZoom)
        val minX=minOf(sw.first, ne.first); val maxX=maxOf(sw.first, ne.first)
        val minY=minOf(sw.second, ne.second); val maxY=maxOf(sw.second, ne.second)
        val count=(maxX-minX+1)*(maxY-minY+1)
        val estimateMb=count*25/1024.0
        val sizeWarning = if (count > 50000) "\n\nВНИМАНИЕ: область очень большая. Загрузка может занять много времени и потребовать десятки гигабайт памяти. Для такой страны лучше выбрать меньшую область." else ""
        android.app.AlertDialog.Builder(this).setTitle("Скачать: $name")
            .setMessage("""Будет загружено до $count фрагментов модели высот.
Предварительная оценка объёма: около ${String.format(Locale.getDefault(), "%.0f", estimateMb)} МБ. Фактический размер может отличаться.
Уровень детализации: zoom $demZoom.
Границы страны охватываются прямоугольником, поэтому часть тайлов может приходиться на море и соседние территории.
Источник: глобальная модель Terrain Tiles (AWS).$sizeWarning""")
            .setPositiveButton("Скачать") { _, _ -> downloadDemTiles(minX,minY,maxX,maxY,name) }
            .setNegativeButton("Отмена", null).show()
    }

    private fun downloadDemTiles(minX:Int,minY:Int,maxX:Int,maxY:Int,name:String) {
        if (!demDownloading.compareAndSet(false,true)) return
        val total=(maxX-minX+1)*(maxY-minY+1)
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,20,32,8) }
        demProgressText=TextView(this).apply { text="Подготовка загрузки…" }
        demProgressBar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=total; progress=0 }
        layout.addView(demProgressText); layout.addView(demProgressBar)
        demProgressDialog=android.app.AlertDialog.Builder(this).setTitle("Загрузка модели: $name").setView(layout)
            .setNegativeButton("В фоне", null).create()
        demProgressDialog?.show()

        executor.execute {
            val nextIndex = java.util.concurrent.atomic.AtomicInteger(0)
            val finished = java.util.concurrent.atomic.AtomicInteger(0)
            val downloaded = java.util.concurrent.atomic.AtomicInteger(0)
            val missing = java.util.concurrent.atomic.AtomicInteger(0)
            val errors = java.util.concurrent.atomic.AtomicInteger(0)
            val workers = Executors.newFixedThreadPool(4)
            val latch = java.util.concurrent.CountDownLatch(4)

            repeat(4) {
                workers.execute {
                    try {
                        while (true) {
                            val index = nextIndex.getAndIncrement()
                            if (index >= total) break
                            val x = minX + (index % (maxX - minX + 1))
                            val y = minY + (index / (maxX - minX + 1))
                            val target = tileFile(x, y)
                            if (target.exists() && target.length() > 100) {
                                downloaded.incrementAndGet()
                            } else {
                                var tileSaved = false
                                var wasMissing = false
                                for (attempt in 0..2) {
                                    var connection: HttpURLConnection? = null
                                    val temp = File(target.parentFile, target.name + ".tmp")
                                    try {
                                        connection = URL("https://s3.amazonaws.com/elevation-tiles-prod/terrarium/$demZoom/$x/$y.png").openConnection() as HttpURLConnection
                                        connection.connectTimeout = 12000
                                        connection.readTimeout = 15000
                                        connection.instanceFollowRedirects = true
                                        connection.setRequestProperty("User-Agent", "GeoTracker Android/2.4")
                                        connection.setRequestProperty("Accept", "image/png")
                                        val response = connection.responseCode
                                        if (response == HttpURLConnection.HTTP_NOT_FOUND) {
                                            wasMissing = true
                                            break
                                        }
                                        if (response == HttpURLConnection.HTTP_OK) {
                                            connection.inputStream.use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } }
                                            val validPng = temp.length() > 100 && temp.inputStream().use { input ->
                                                val signature = ByteArray(8)
                                                input.read(signature) == 8 && signature.contentEquals(byteArrayOf(
                                                    0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
                                                ))
                                            }
                                            if (validPng && (temp.renameTo(target) || target.exists())) {
                                                tileSaved = true
                                                break
                                            }
                                            temp.delete()
                                        } else if (response in 500..599 && attempt < 2) {
                                            Thread.sleep(500L * (attempt + 1))
                                        } else {
                                            break
                                        }
                                    } catch (_: Exception) {
                                        temp.delete()
                                        if (attempt < 2) Thread.sleep(500L * (attempt + 1))
                                    } finally {
                                        connection?.disconnect()
                                    }
                                }
                                when {
                                    tileSaved -> downloaded.incrementAndGet()
                                    wasMissing -> missing.incrementAndGet()
                                    else -> errors.incrementAndGet()
                                }
                            }
                            val d = finished.incrementAndGet()
                            if (d % 10 == 0 || d == total) {
                                val ok = downloaded.get()
                                val absent = missing.get()
                                val err = errors.get()
                                runOnUiThread {
                                    demProgressBar?.progress = d
                                    demProgressText?.text = "Обработано $d из $total\nСохранено: $ok • нет данных: $absent • ошибок: $err"
                                }
                            }
                        }
                    } finally {
                        latch.countDown()
                    }
                }
            }
            try { latch.await() } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            workers.shutdown()
            demDownloading.set(false)
            val ok = downloaded.get()
            val absent = missing.get()
            val err = errors.get()
            runOnUiThread {
                demProgressBar?.progress = total
                demProgressText?.text = "Завершено.\nСохранено: $ok\nНет данных для участков: $absent\nОшибок загрузки: $err"
                if (ok > 0) {
                    val prefs = getSharedPreferences("offline_dem", Context.MODE_PRIVATE)
                    val saved = prefs.getStringSet("regions", emptySet())?.toMutableSet() ?: mutableSetOf()
                    saved.add(name)
                    prefs.edit().putStringSet("regions", saved).apply()
                    Toast.makeText(this, "Офлайн-модель $name: сохранено $ok фрагментов", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Не удалось загрузить данные. Проверьте интернет-соединение и повторите попытку.", Toast.LENGTH_LONG).show()
                }
                demProgressDialog?.setButton(-1, "Закрыть") { dialog, _ -> dialog.dismiss() }
            }
        }
    }

    private fun showDownloadedDemFiles() {
        val files = demDir().listFiles()?.filter { it.extension == "png" } ?: emptyList()
        val regions = getSharedPreferences("offline_dem", Context.MODE_PRIVATE).getStringSet("regions", emptySet())?.toList()?.sorted().orEmpty()
        val regionText = if (regions.isEmpty()) "Названия загруженных стран пока не сохранены." else "Загружено: ${regions.joinToString(", ")}"
        android.app.AlertDialog.Builder(this).setTitle("Офлайн-данные")
            .setMessage("""$regionText

Сохранено фрагментов модели: ${files.size}
Занято: ${files.sumOf { it.length() } / (1024*1024)} МБ

Удаление всех фрагментов освободит память телефона.""")
            .setPositiveButton("Удалить всё") { _, _ ->
                files.forEach { it.delete() }
                getSharedPreferences("offline_dem", Context.MODE_PRIVATE).edit().remove("regions").apply()
                terrainAltitude=null; terrain.text="Нет офлайн-данных"
                Toast.makeText(this,"Офлайн-данные удалены",Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null).show()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            val rotationMatrix = FloatArray(9)
            val orientation = FloatArray(3)
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientation)
            val degrees = ((Math.toDegrees(orientation[0].toDouble()).toInt() + 360) % 360)
            val directions = arrayOf("С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ")
            val direction = directions[((degrees + 22) / 45) % 8]
            compassView.text = String.format(Locale.getDefault(), "Компас: %s (%d°)", direction, degrees)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) { super.onRequestPermissionsResult(r,p,g); if(r==requestCode) { if(g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED) startGps() else status.text="Разрешите доступ к местоположению" } }
    override fun onProviderEnabled(p:String) { if(p==LocationManager.GPS_PROVIDER) startGps() }
    override fun onProviderDisabled(p:String) { if(p==LocationManager.GPS_PROVIDER) status.text="GPS отключён" }
    override fun onStatusChanged(p:String?,s:Int,e:Bundle?) {}
    override fun onPause() {
        super.onPause()
        lm.removeUpdates(this)
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
    }
    override fun onResume() {
        super.onResume()
        if (::sensorManager.isInitialized) {
            rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        }
        if(::lm.isInitialized && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) startGps()
    }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
