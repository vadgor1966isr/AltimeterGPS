package com.example.altimetergps

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity(), LocationListener {
    private lateinit var lm: LocationManager
    private lateinit var current: TextView
    private lateinit var average: TextView
    private lateinit var terrain: TextView
    private lateinit var vAcc: TextView
    private lateinit var hAcc: TextView
    private lateinit var status: TextView
    private lateinit var updated: TextView
    private val samples = ArrayDeque<Pair<Long, Double>>()
    private val executor = Executors.newSingleThreadExecutor()
    private var lastTerrainFetch = 0L
    private var lastLat = 0.0
    private var lastLon = 0.0
    private val requestCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(24,28,24,28); setBackgroundColor(0xFFF4F6F8.toInt()) }
        fun label(size:Float,color:Int)=TextView(this).apply { textSize=size; setTextColor(color); gravity=Gravity.CENTER; setPadding(0,7,0,7) }
        fun add(v:TextView)=root.addView(v,LinearLayout.LayoutParams(-1,-2))
        add(label(20f,0xFF37474F.toInt()).apply { text="ALTIMETER GPS 2.0" })
        current=label(25f,0xFF607D8B.toInt()).apply { text="GPS сейчас: — m" }; add(current)
        average=label(50f,0xFF1565C0.toInt()).apply { text="— m" }; add(average)
        add(label(14f,0xFF455A64.toInt()).apply { text="Среднее GPS за последние 30 секунд" })
        terrain=label(25f,0xFF2E7D32.toInt()).apply { text="Над уровнем моря: ожидание GPS" }; add(terrain)
        vAcc=label(16f,0xFF455A64.toInt()).apply { text="Точность высоты GPS: нет данных" }; add(vAcc)
        hAcc=label(14f,0xFF607D8B.toInt()).apply { text="Точность координат: —" }; add(hAcc)
        status=label(17f,0xFF263238.toInt()).apply { text="Ожидание GPS…" }; add(status)
        updated=label(13f,0xFF78909C.toInt()); add(updated)
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER }
        row.addView(Button(this).apply { text="Обновить GPS"; setOnClickListener { checkPermission() } })
        row.addView(Button(this).apply { text="Сбросить"; setOnClickListener { samples.clear(); average.text="— m"; status.text="Измерения сброшены" } })
        root.addView(row)
        add(label(12f,0xFF78909C.toInt()).apply { text="Зелёное значение берётся из цифровой модели рельефа через интернет. GPS-высота может отличаться от высоты над средним уровнем моря." })
        setContentView(ScrollView(this).apply { addView(root) })
        checkPermission()
    }

    private fun checkPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestCode)
        else startGps()
    }
    private fun startGps() {
        try {
            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { status.text="Включите Местоположение / GPS"; return }
            lm.removeUpdates(this); status.text="Поиск спутников GPS…"
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000L,1f,this,Looper.getMainLooper())
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
        } catch (_:Exception) { status.text="Не удалось запустить GPS" }
    }
    override fun onLocationChanged(loc:Location) {
        val now=System.currentTimeMillis()
        val recent=samples.filter { now-it.first<=30000L }.map { it.second }.sorted()
        val median=if(recent.isEmpty()) null else recent[recent.size/2]
        if(median==null || abs(loc.altitude-median)<=80.0 || recent.size<3) samples.addLast(now to loc.altitude)
        while(samples.isNotEmpty() && now-samples.first().first>30000L) samples.removeFirst()
        current.text=String.format(Locale.getDefault(),"GPS сейчас: %.1f m",loc.altitude)
        if(samples.isNotEmpty()) average.text=String.format(Locale.getDefault(),"%.1f m",samples.map{it.second}.average())
        vAcc.text=if(loc.hasVerticalAccuracy()) String.format(Locale.getDefault(),"Точность высоты GPS: ±%.1f м",loc.verticalAccuracyMeters) else "Точность высоты GPS: устройство не сообщает"
        hAcc.text=String.format(Locale.getDefault(),"Точность координат: ±%.0f м",loc.accuracy)
        status.text="GPS работает • измерений: ${samples.size}"
        updated.text="Обновлено: "+SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date(loc.time))
        if(now-lastTerrainFetch>60000L || Location.distanceBetween(lastLat,lastLon,loc.latitude,loc.longitude,FloatArray(1)).let { false }) {
            lastTerrainFetch=now; lastLat=loc.latitude; lastLon=loc.longitude; fetchTerrain(loc.latitude,loc.longitude)
        }
    }
    private fun fetchTerrain(lat:Double,lon:Double) {
        terrain.text="Над уровнем моря: загрузка модели…"
        executor.execute {
            var c:HttpURLConnection?=null
            try {
                c=URL("https://api.open-meteo.com/v1/elevation?latitude=$lat&longitude=$lon").openConnection() as HttpURLConnection
                c.connectTimeout=8000; c.readTimeout=8000
                val body=c.inputStream.bufferedReader().use{it.readText()}
                val value=Regex(""elevation"\\s*:\\s*\\[\\s*(-?\\d+(?:\\.\\d+)?)").find(body)?.groupValues?.get(1)?.toDoubleOrNull()
                runOnUiThread { terrain.text=if(value!=null) String.format(Locale.getDefault(),"Над уровнем моря: %.1f m",value) else "Нет данных модели рельефа" }
            } catch(_:Exception) { runOnUiThread { terrain.text="Нет интернета / данных модели" } }
            finally { c?.disconnect() }
        }
    }
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) { super.onRequestPermissionsResult(r,p,g); if(r==requestCode) { if(g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED) startGps() else status.text="Разрешите доступ к местоположению" } }
    override fun onProviderEnabled(p:String) { if(p==LocationManager.GPS_PROVIDER) startGps() }
    override fun onProviderDisabled(p:String) { if(p==LocationManager.GPS_PROVIDER) status.text="GPS отключён" }
    override fun onStatusChanged(p:String?,s:Int,e:Bundle?) {}
    override fun onPause() { super.onPause(); lm.removeUpdates(this) }
    override fun onResume() { super.onResume(); if(::lm.isInitialized && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) startGps() }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
