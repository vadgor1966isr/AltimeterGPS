package com.example.altimetergps

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), LocationListener {
    private lateinit var lm: LocationManager
    private lateinit var altitude: TextView
    private lateinit var status: TextView
    private lateinit var accuracy: TextView
    private lateinit var updated: TextView
    private val permissionRequest = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFFF4F6F8.toInt())
        }
        fun label(size: Float, color: Int) = TextView(this).apply {
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
        }
        val title = label(20f, 0xFF37474F.toInt()).apply { text = "ALTIMETER GPS" }
        altitude = label(58f, 0xFF1565C0.toInt()).apply { text = "— m"; setPadding(0, 36, 0, 24) }
        status = label(18f, 0xFF263238.toInt()).apply { text = "Ожидание GPS…" }
        accuracy = label(16f, 0xFF546E7A.toInt()).apply { text = "Точность: —"; setPadding(0, 16, 0, 4) }
        updated = label(14f, 0xFF607D8B.toInt())
        val button = Button(this).apply { text = "Обновить GPS"; setOnClickListener { checkPermission() } }
        val note = label(13f, 0xFF78909C.toInt()).apply {
            text = "Высота определяется по GPS и является приблизительной. Возможна погрешность."
            setPadding(8, 28, 8, 0)
        }
        listOf(title, altitude, status, accuracy, updated, button, note).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                if (it == button) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { if (it == button) topMargin = 24 })
        }
        setContentView(layout)
        checkPermission()
    }

    private fun checkPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), permissionRequest)
        } else startGps()
    }

    private fun startGps() {
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            status.text = "Включите GPS в настройках устройства"
            return
        }
        try {
            lm.removeUpdates(this)
            status.text = "Поиск спутников GPS…"
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 1f, this, Looper.getMainLooper())
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
        } catch (_: SecurityException) {
            status.text = "Нет разрешения на геолокацию"
        } catch (_: Exception) {
            status.text = "Не удалось запустить GPS"
        }
    }

    override fun onLocationChanged(location: Location) {
        altitude.text = String.format(Locale.getDefault(), "%.1f m", location.altitude)
        status.text = "GPS работает"
        accuracy.text = "Точность координат: ±${location.accuracy.toInt()} м"
        updated.text = "Обновлено: " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(location.time))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == permissionRequest) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startGps()
            else status.text = "Разрешите доступ к местоположению"
        }
    }

    override fun onProviderEnabled(provider: String) { if (provider == LocationManager.GPS_PROVIDER) startGps() }
    override fun onProviderDisabled(provider: String) { if (provider == LocationManager.GPS_PROVIDER) status.text = "GPS отключён" }
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit

    override fun onPause() { super.onPause(); lm.removeUpdates(this) }
    override fun onResume() {
        super.onResume()
        if (::lm.isInitialized && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) startGps()
    }
}
