package com.example.altimetergps

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.widget.*
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity(), LocationListener {
    private lateinit var lm: LocationManager
    private lateinit var current: TextView
    private lateinit var average: TextView
    private lateinit var terrain: TextView
    private lateinit var vAcc: TextView
    private lateinit var hAcc: TextView
    private lateinit var status: TextView
    private lateinit var updated: TextView
    private lateinit var coordinates: TextView
    private lateinit var mapView: WebView
    private var mapReady = false
    private var mapHasLocation = false
    private var latestCoordinates = ""
    private val samples = ArrayDeque<Pair<Long, Double>>()
    private val executor = Executors.newSingleThreadExecutor()
    private var lastTerrainFetch = 0L
    private var lastLat = 0.0
    private var lastLon = 0.0
    private var lastTerrainLat = 0.0
    private var lastTerrainLon = 0.0
    private var lastUiUpdate = 0L
    private val requestCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 28)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF10243A.toInt(), 0xFF183B55.toInt(), 0xFF0D1B2A.toInt())
            )
        }
        fun text(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(4, 5, 4, 5)
        }
        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16, 13, 16, 13)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF203B52.toInt())
                cornerRadius = 24f
                setStroke(1, 0xFF426078.toInt())
            }
            elevation = 5f
        }
        fun addCard(v: android.view.View, top: Int = 10) {
            page.addView(v, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = top
            })
        }

        page.addView(text(14f, 0xFF9DB9CC.toInt(), true).apply { text = "GPS  •  ALTIMETER" })
        page.addView(text(27f, 0xFFFFFFFF.toInt(), true).apply { text = "Высота и координаты" })
        page.addView(text(13f, 0xFF9DB9CC.toInt()).apply { text = "ТЕКУЩЕЕ МЕСТОПОЛОЖЕНИЕ" })

        val mainCard = card()
        mainCard.addView(text(14f, 0xFF9FC3D9.toInt()).apply { text = "ВЫСОТА ПО GPS" })
        current = text(22f, 0xFFD8EAF5.toInt()).apply { text = "Сейчас: — m" }
        mainCard.addView(current)
        average = text(58f, 0xFFFFFFFF.toInt(), true).apply { text = "— m" }
        mainCard.addView(average)
        mainCard.addView(text(13f, 0xFF9FC3D9.toInt()).apply { text = "Среднее за последние 30 секунд" })
        addCard(mainCard, 14)

        val terrainCard = card()
        terrainCard.addView(text(14f, 0xFF9FC3D9.toInt()).apply { text = "ВЫСОТА НАД УРОВНЕМ МОРЯ" })
        terrain = text(34f, 0xFF7FE0A0.toInt(), true).apply { text = "— m" }
        terrainCard.addView(terrain)
        terrainCard.addView(text(12f, 0xFFB6CCD9.toInt()).apply { text = "По цифровой модели рельефа" })
        addCard(terrainCard)

        val mapCard = card()
        mapCard.addView(text(14f, 0xFF9FC3D9.toInt(), true).apply { text = "КАРТА ТЕКУЩЕГО МЕСТОПОЛОЖЕНИЯ" })
        mapView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    mapReady = true
                    if (lastLat != 0.0 || lastLon != 0.0) updateMapLocation(lastLat, lastLon)
                }
            }
            setBackgroundColor(0xFFE7E5DF.toInt())
            overScrollMode = android.view.View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = false
        }
        mapCard.addView(mapView, LinearLayout.LayoutParams(-1, dp(280)).apply {
            topMargin = 8
        })
        val mapButton = Button(this).apply {
            text = "ПОКАЗАТЬ МОЁ МЕСТОПОЛОЖЕНИЕ"
            setOnClickListener {
                if (mapHasLocation) mapView.evaluateJavascript("map.setView([$lastLat,$lastLon],16,{animate:false});", null)
                else Toast.makeText(this@MainActivity, "Ожидание координат GPS…", Toast.LENGTH_SHORT).show()
            }
        }
        mapCard.addView(mapButton)
        addCard(mapCard, 12)
        mapView.loadDataWithBaseURL("https://altimetergps.local/", mapHtml(), "text/html", "UTF-8", null)

        val locationCard = card()
        locationCard.addView(text(14f, 0xFF9FC3D9.toInt(), true).apply { text = "GPS-КООРДИНАТЫ" })
        coordinates = text(19f, 0xFFFFFFFF.toInt(), true).apply { text = "Широта: —\nДолгота: —" }
        locationCard.addView(coordinates)
        val copyButton = Button(this).apply {
            text = "КОПИРОВАТЬ КООРДИНАТЫ"
            setOnClickListener {
                if (latestCoordinates.isNotEmpty()) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GPS coordinates", latestCoordinates))
                    Toast.makeText(this@MainActivity, "Координаты скопированы", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this@MainActivity, "Пока нет координат GPS", Toast.LENGTH_SHORT).show()
            }
        }
        locationCard.addView(copyButton)
        addCard(locationCard)

        val infoCard = card()
        vAcc = text(14f, 0xFFD7E5ED.toInt()).apply { text = "Точность высоты GPS: —" }
        hAcc = text(14f, 0xFFD7E5ED.toInt()).apply { text = "Точность координат: —" }
        status = text(15f, 0xFF7FE0A0.toInt(), true).apply { text = "Ожидание GPS…" }
        updated = text(12f, 0xFF9DB9CC.toInt()).apply { text = "" }
        infoCard.addView(vAcc); infoCard.addView(hAcc); infoCard.addView(status); infoCard.addView(updated)
        addCard(infoCard)

        val buttons = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "Обновить GPS"; setOnClickListener { checkPermission() } })
        buttons.addView(Button(this).apply {
            text = "Сбросить"
            setOnClickListener { samples.clear(); average.text = "— m"; status.text = "Измерения сброшены" }
        })
        addCard(buttons)
        page.addView(text(11f, 0xFF9DB1BF.toInt()).apply {
            text = "Синяя высота определяется спутниками GPS и работает без интернета. Зелёная высота берётся из онлайн-модели рельефа."
            setPadding(8, 16, 8, 8)
        })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(page) })
        checkPermission()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun updateMapLocation(lat: Double, lon: Double) {
        if (!mapReady) return
        mapView.evaluateJavascript("if(window.updateGpsPosition){window.updateGpsPosition($lat,$lon);}", null)
    }

    private fun mapHtml(): String = """<!DOCTYPE html>
<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>html,body,#map{height:100%;width:100%;margin:0;padding:0;background:#e7e5df} .leaflet-control-attribution{font-size:9px}</style>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script></head>
<body><div id="map"></div><script>
var map=L.map('map',{zoomControl:true}).setView([32.7,35.3],7);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
 maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
var gpsMarker=null;
window.updateGpsPosition=function(lat,lon){
 var point=[lat,lon];
 if(!gpsMarker){gpsMarker=L.marker(point).addTo(map).bindPopup('Ваше местоположение');map.setView(point,16);}
 else{gpsMarker.setLatLng(point);}
};
setTimeout(function(){map.invalidateSize();},300);
</script></body></html>"""

    private fun checkPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestCode)
        else startGps()
    }
    private fun startGps() {
        try {
            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { status.text="Включите Местоположение / GPS"; return }
            lm.removeUpdates(this); status.text="Поиск спутников GPS…"
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000L,5f,this,Looper.getMainLooper())
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
        } catch (_:Exception) { status.text="Не удалось запустить GPS" }
    }
    override fun onLocationChanged(loc:Location) {
        val now=System.currentTimeMillis()
        val recent=samples.filter { now-it.first<=30000L }.map { it.second }.sorted()
        val median=if(recent.isEmpty()) null else recent[recent.size/2]
        if(median==null || abs(loc.altitude-median)<=80.0 || recent.size<3) samples.addLast(now to loc.altitude)
        while(samples.isNotEmpty() && now-samples.first().first>30000L) samples.removeFirst()
        if (now - lastUiUpdate < 5000L) {
            lastLat = loc.latitude
            lastLon = loc.longitude
            latestCoordinates = String.format(Locale.US, "%.6f, %.6f", loc.latitude, loc.longitude)
            mapHasLocation = true
            return
        }
        lastUiUpdate = now
        current.text=String.format(Locale.getDefault(),"GPS сейчас: %.1f m",loc.altitude)
        latestCoordinates = String.format(Locale.US, "%.6f, %.6f", loc.latitude, loc.longitude)
        lastLat = loc.latitude
        lastLon = loc.longitude
        mapHasLocation = true
        updateMapLocation(loc.latitude, loc.longitude)
        coordinates.text = String.format(Locale.US, "Широта: %.6f\nДолгота: %.6f", loc.latitude, loc.longitude)
        if(samples.isNotEmpty()) average.text=String.format(Locale.getDefault(),"%.1f m",samples.map{it.second}.average())
        vAcc.text=if(loc.hasVerticalAccuracy()) String.format(Locale.getDefault(),"Точность высоты GPS: ±%.1f м",loc.verticalAccuracyMeters) else "Точность высоты GPS: устройство не сообщает"
        hAcc.text=String.format(Locale.getDefault(),"Точность координат: ±%.0f м",loc.accuracy)
        status.text="GPS работает • измерений: ${samples.size}"
        updated.text="Обновлено: "+SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date(loc.time))
        val moved = if (lastTerrainFetch == 0L) true else {
            val distance = FloatArray(1)
            Location.distanceBetween(lastTerrainLat, lastTerrainLon, loc.latitude, loc.longitude, distance)
            distance[0] > 100f
        }
        if (lastTerrainFetch == 0L || now - lastTerrainFetch > 300000L || (moved && now - lastTerrainFetch > 120000L)) {
            lastTerrainFetch=now; lastTerrainLat=loc.latitude; lastTerrainLon=loc.longitude; fetchTerrain(loc.latitude,loc.longitude)
        }
    }
    private fun fetchTerrain(lat:Double,lon:Double) {
        // Keep the last valid elevation visible while refreshing.
        executor.execute {
            var c:HttpURLConnection?=null
            try {
                c=URL("https://api.open-meteo.com/v1/elevation?latitude=$lat&longitude=$lon").openConnection() as HttpURLConnection
                c.connectTimeout=8000; c.readTimeout=8000
                val body=c.inputStream.bufferedReader().use{it.readText()}
                val value = org.json.JSONObject(body).getJSONArray("elevation").optDouble(0)
                runOnUiThread { terrain.text=if(value!=null) String.format(Locale.getDefault(),"%.1f m",value) else "Нет данных" }
            } catch(_:Exception) { runOnUiThread { terrain.text="Нет интернета / данных" } }
            finally { c?.disconnect() }
        }
    }
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) { super.onRequestPermissionsResult(r,p,g); if(r==requestCode) { if(g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED) startGps() else status.text="Разрешите доступ к местоположению" } }
    override fun onProviderEnabled(p:String) { if(p==LocationManager.GPS_PROVIDER) startGps() }
    override fun onProviderDisabled(p:String) { if(p==LocationManager.GPS_PROVIDER) status.text="GPS отключён" }
    override fun onStatusChanged(p:String?,s:Int,e:Bundle?) {}
    override fun onPause() { super.onPause(); lm.removeUpdates(this) }
    override fun onResume() { super.onResume(); if(::lm.isInitialized && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) startGps() }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
