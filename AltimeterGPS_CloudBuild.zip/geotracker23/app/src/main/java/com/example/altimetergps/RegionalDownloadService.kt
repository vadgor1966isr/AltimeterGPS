package com.example.altimetergps

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean

/** Runs map -> routing segments -> elevation tiles as one persistent background operation. */
class RegionalDownloadService : Service() {
    companion object {
        const val ACTION_START = "com.example.altimetergps.REGIONAL_DOWNLOAD_START"
        const val ACTION_CANCEL = "com.example.altimetergps.REGIONAL_DOWNLOAD_CANCEL"
        const val EXTRA_MAP_NAME = "map_name"
        const val EXTRA_MAP_URL = "map_url"
        private const val CHANNEL = "regional_download"
        private const val NOTIFICATION_ID = 4601
        private val active = AtomicBoolean(false)
    }

    @Volatile private var cancelRequested = false
    @Volatile private var worker: Thread? = null
    private val status by lazy { getSharedPreferences("regional_download", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            cancelRequested = true
            cancelChildServices()
            worker?.interrupt()
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START || !active.compareAndSet(false, true)) return START_NOT_STICKY
        cancelRequested = false
        val mapName = intent.getStringExtra(EXTRA_MAP_NAME) ?: "nord-est.map"
        val mapUrl = intent.getStringExtra(EXTRA_MAP_URL) ?: "https://download.mapsforge.org/maps/v5/europe/italy/nord-est.map"
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Подготовка загрузки", 0, true))
        status.edit().putString("state", "running").putString("map_name", mapName)
            .putString("stage", "Подготовка офлайн-карты").putInt("progress", 0)
            .putString("message", "Подготовка загрузки для $mapName").remove("error").commit()
        worker = Thread({ runPipeline(mapName, mapUrl, startId) }, "GeoTracker-regional-download").also { it.start() }
        return START_NOT_STICKY
    }

    private fun runPipeline(mapName: String, mapUrl: String, startId: Int) {
        try {
            val mapPrefs = getSharedPreferences("mapsforge", MODE_PRIVATE)
            val sameMapReady = mapPrefs.getString("downloaded_map_name", "") == mapName &&
                mapPrefs.getString("download_status", "") == "completed" &&
                mapPrefs.getString("downloaded_map_uri", null) != null
            if (!sameMapReady) {
                stage("Загрузка офлайн-карты", 5, "Загружается $mapName")
                startChild(MapsforgeDownloadService::class.java, Intent(this, MapsforgeDownloadService::class.java).apply {
                    action = MapsforgeDownloadService.ACTION_START
                    putExtra(MapsforgeDownloadService.EXTRA_MAP_NAME, mapName)
                    putExtra(MapsforgeDownloadService.EXTRA_MAP_URL, mapUrl)
                })
                val result = waitFor("mapsforge", "download_status", setOf("completed", "failed", "cancelled"), 6 * 60 * 60_000L)
                if (result != "completed") throw IllegalStateException("Не удалось загрузить офлайн-карту: ${mapPrefs.getString("download_error", result)}")
            }
            checkCancelled()

            val south = mapPrefs.getFloat("map_south", Float.NaN).toDouble()
            val west = mapPrefs.getFloat("map_west", Float.NaN).toDouble()
            val north = mapPrefs.getFloat("map_north", Float.NaN).toDouble()
            val east = mapPrefs.getFloat("map_east", Float.NaN).toDouble()
            require(south.isFinite() && west.isFinite() && north.isFinite() && east.isFinite() && south < north && west < east) {
                "Не удалось прочитать реальные границы выбранной карты"
            }
            val segments = MapsforgeCatalog.brouterSegments(south, west, north, east)
            require(segments.isNotEmpty()) { "Для выбранной карты не найдены сегменты маршрутизации" }
            val extentText = String.format(java.util.Locale.US,
                "границы %.4f, %.4f — %.4f, %.4f", south, west, north, east)
            stage("Подготовка маршрутизации", 35,
                "Определено сегментов: ${segments.size}; $extentText")
            val rdState = getSharedPreferences("brouter_download", MODE_PRIVATE).getString("state", "")
            if (rdState == "running") throw IllegalStateException("Уже выполняется другая загрузка данных маршрутизации")
            startChild(BRouterSegmentDownloadService::class.java, Intent(this, BRouterSegmentDownloadService::class.java).apply {
                action = BRouterSegmentDownloadService.ACTION_START
                putStringArrayListExtra(BRouterSegmentDownloadService.EXTRA_NAMES, ArrayList(segments))
            })
            val rdResult = waitFor("brouter_download", "state", setOf("completed", "cancelled", "error"), 12 * 60 * 60_000L)
            if (rdResult != "completed") throw IllegalStateException("Загрузка данных маршрутизации завершилась: $rdResult")
            val routingWarnings = getSharedPreferences("brouter_download", MODE_PRIVATE).getString("error", "") ?: ""
            checkCancelled()

            val tiles = MapsforgeCatalog.demTileBounds(south, west, north, east)
            val tileCount = (tiles[2] - tiles[0] + 1L) * (tiles[3] - tiles[1] + 1L)
            require(tileCount > 0L) { "Не удалось определить участки модели высот" }
            stage("Загрузка модели высот", 65,
                "Подготовлено участков высот: $tileCount; используются те же границы карты")
            val demState = getSharedPreferences("dem_download", MODE_PRIVATE).getString("state", "")
            if (demState == "running") throw IllegalStateException("Уже выполняется другая загрузка модели высот")
            startChild(DemDownloadService::class.java, Intent(this, DemDownloadService::class.java).apply {
                putExtra("minX", tiles[0]); putExtra("minY", tiles[1]); putExtra("maxX", tiles[2]); putExtra("maxY", tiles[3])
                putExtra("name", mapName.removeSuffix(".map"))
            })
            val demResult = waitFor("dem_download", "state", setOf("completed", "cancelled", "error"), 12 * 60 * 60_000L)
            if (demResult != "completed") throw IllegalStateException("Загрузка модели высот завершилась: $demResult")
            val demPrefs = getSharedPreferences("dem_download", MODE_PRIVATE)
            val demWarnings = "нет данных: ${demPrefs.getInt("missing", 0)}, ошибок: ${demPrefs.getInt("errors", 0)}"
            val partial = routingWarnings.isNotBlank() || demPrefs.getInt("errors", 0) > 0
            val finalMessage = if (partial)
                "Загрузка завершена частично. Сегментов маршрутизации: ${segments.size}; участков высот: $tileCount. $demWarnings. Некоторые файлы источника недоступны."
            else
                "Все данные для выбранной карты загружены. Сегментов маршрутизации: ${segments.size}; участков высот: $tileCount. $demWarnings."
            status.edit().putString("state", if (partial) "partial" else "completed").putString("stage", "Готово")
                .putString("message", finalMessage).putString("routing_warnings", routingWarnings).putInt("progress", 100).commit()
            notify(finalMessage, 100, false, true)
        } catch (e: InterruptedException) {
            status.edit().putString("state", "cancelled").putString("stage", "Остановлено")
                .putString("message", "Загрузка отменена пользователем").commit()
            notify("Загрузка отменена", 0, false, true)
        } catch (e: Exception) {
            val cancelled = cancelRequested
            val message = if (cancelled) "Загрузка отменена" else (e.message ?: "Неизвестная ошибка")
            status.edit().putString("state", if (cancelled) "cancelled" else "error")
                .putString("stage", if (cancelled) "Остановлено" else "Ошибка")
                .putString("message", message).putString("error", message).commit()
            notify(message, 0, false, true)
        } finally {
            active.set(false)
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf(startId)
        }
    }

    private fun waitFor(prefsName: String, key: String, terminal: Set<String>, timeoutMs: Long): String {
        val p = getSharedPreferences(prefsName, MODE_PRIVATE)
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            checkCancelled()
            val value = p.getString(key, "idle") ?: "idle"
            if (value in terminal) return value
            Thread.sleep(1000)
        }
        throw IllegalStateException("Истекло время ожидания этапа загрузки")
    }

    private fun checkCancelled() { if (cancelRequested || Thread.currentThread().isInterrupted) throw InterruptedException() }

    private fun startChild(clazz: Class<out Service>, intent: Intent) {
        checkCancelled()
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun cancelChildServices() {
        try { startService(Intent(this, MapsforgeDownloadService::class.java).setAction(MapsforgeDownloadService.ACTION_CANCEL)) } catch (_: Exception) {}
        try { startService(Intent(this, BRouterSegmentDownloadService::class.java).setAction(BRouterSegmentDownloadService.ACTION_CANCEL)) } catch (_: Exception) {}
        try { startService(Intent(this, DemDownloadService::class.java).setAction(DemDownloadService.ACTION_CANCEL)) } catch (_: Exception) {}
    }

    private fun stage(label: String, progress: Int, message: String) {
        status.edit().putString("stage", label).putString("message", message).putInt("progress", progress).apply()
        notify("$label • $message", progress, false)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Загрузка карт GeoTracker", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(text: String, progress: Int, indeterminate: Boolean, finished: Boolean = false) =
        NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("GeoTracker — загрузка карт").setContentText(text).setOngoing(!finished)
            .setOnlyAlertOnce(true).setProgress(100, progress.coerceIn(0, 100), indeterminate && !finished).build()
    private fun notify(text: String, progress: Int, indeterminate: Boolean, finished: Boolean = false) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text, progress, indeterminate, finished))
    }
}
