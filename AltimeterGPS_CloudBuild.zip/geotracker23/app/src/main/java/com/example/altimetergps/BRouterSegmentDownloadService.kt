package com.example.altimetergps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Keeps BRouter RD5 downloads alive when RoutePlannerActivity is closed. */
class BRouterSegmentDownloadService : Service() {
    companion object {
        const val ACTION_START = "com.example.altimetergps.RD5_START"
        const val ACTION_CANCEL = "com.example.altimetergps.RD5_CANCEL"
        const val ACTION_PROGRESS = "com.example.altimetergps.RD5_PROGRESS"
        const val EXTRA_NAMES = "names"
        private const val CHANNEL = "brouter_segments"
        private const val NOTIFICATION_ID = 4301
        private const val PREFS = "brouter_download"
        private val running = AtomicBoolean(false)
    }

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private lateinit var nm: NotificationManager
    private var worker: Thread? = null
    @Volatile private var cancelRequested = false
    @Volatile private var activeConnection: HttpURLConnection? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Загрузка данных BRouter", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            cancelRequested = true
            try { activeConnection?.disconnect() } catch (_: Exception) {}
            worker?.interrupt()
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        if (!running.compareAndSet(false, true)) return START_NOT_STICKY
        cancelRequested = false
        val names = intent.getStringArrayListExtra(EXTRA_NAMES) ?: arrayListOf()
        if (names.isEmpty()) {
            running.set(false)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        prefs.edit().putString("state", "running").putString("message", "Подготовка загрузки")
            .putInt("done", 0).putInt("count", names.size).putLong("received", 0)
            .putLong("total", -1).putString("current", "").putString("error", "").commit()
        startForeground(NOTIFICATION_ID, buildNotification("Подготовка загрузки BRouter", 0, true, false))
        worker = Thread({ download(names, startId) }, "BRouter-RD5-Service").also { it.start() }
        return START_NOT_STICKY
    }

    private fun download(names: List<String>, startId: Int) {
        var ok = 0
        var totalBytes = 0L
        val failures = mutableListOf<String>()
        val dir = File(filesDir, "brouter/segments4").apply { mkdirs() }
        try {
            for ((index, name) in names.withIndex()) {
                if (cancelRequested) break
                val target = File(dir, name)
                if (target.exists() && target.length() > 1024L) {
                    if (RegionStorage.rootUri(this) != null && !RegionStorage.copyFileToFolder(this, target, "Routing"))
                        failures.add("$name: не удалось сохранить во внешнюю папку региона")
                    ok++; totalBytes += target.length()
                    publish(index + 1, names.size, name, target.length(), target.length(), ok, totalBytes,
                        "Файл ${index + 1}/${names.size}: $name уже имеется")
                    continue
                }
                val temp = File(dir, "$name.download")
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL("https://brouter.de/brouter/segments4/$name").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 20000; readTimeout = 60000; requestMethod = "GET"
                        setRequestProperty("User-Agent", "GeoTracker/3.20")
                    }
                    activeConnection = conn
                    if (cancelRequested) throw InterruptedException("Загрузка отменена")
                    val code = conn.responseCode
                    if (code != 200) throw IllegalStateException("HTTP $code")
                    val expected = conn.contentLengthLong
                    var received = 0L
                    prefs.edit().putString("current", name).putLong("total", expected).putLong("received", 0)
                        .putString("message", "Загрузка $name").apply()
                    temp.outputStream().buffered().use { out ->
                        conn.inputStream.buffered().use { input ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                if (cancelRequested || Thread.currentThread().isInterrupted)
                                    throw InterruptedException("Загрузка отменена")
                                val n = input.read(buffer)
                                if (n < 0) break
                                out.write(buffer, 0, n); received += n
                                prefs.edit().putLong("received", received).apply()
                                val percent = if (expected > 0) ((received * 100L) / expected).toInt().coerceIn(0,100) else 0
                                updateNotification("$name • ${mb(received)} МБ" + if (expected > 0) " • $percent%" else "", percent, expected <= 0, false)
                                sendProgress()
                            }
                        }
                    }
                    if (temp.length() < 1024L) throw IllegalStateException("файл слишком мал")
                    if (expected > 0 && temp.length() != expected) throw IllegalStateException("загружен не весь файл")
                    if (target.exists()) target.delete()
                    if (!temp.renameTo(target)) throw IllegalStateException("не удалось сохранить файл")
                    if (RegionStorage.rootUri(this) != null && !RegionStorage.copyFileToFolder(this, target, "Routing"))
                        failures.add("$name: скачан, но не сохранён во внешнюю папку региона")
                    ok++; totalBytes += target.length()
                } catch (e: Exception) {
                    temp.delete()
                    if (!cancelRequested) failures.add("$name: ${e.message ?: "ошибка"}")
                } finally {
                    conn?.disconnect()
                    activeConnection = null
                }
                if (cancelRequested) break
                publish(index + 1, names.size, name, 0, 0, ok, totalBytes,
                    "Обработано ${index + 1}/${names.size}; успешно $ok")
            }
            val cancelled = cancelRequested
            // The operation is terminal once every selected file was processed.
            // Per-file errors are reported, but do not leave the offline-data UI locked.
            val state = if (cancelled) "cancelled" else "completed"
            val message = if (cancelled) "Загрузка отменена. Успешно загружено: $ok из ${names.size}." else buildString {
                append("Загрузка завершена: $ok из ${names.size}. ")
                if (failures.isNotEmpty()) append("Ошибки: ${failures.joinToString("; ")}")
            }
            prefs.edit().putString("state", state).putString("message", message)
                .putString("error", failures.joinToString("; ")).putInt("done", names.size)
                .putLong("bytes_total", totalBytes).commit()
            updateNotification(message, 100, false, true)
            sendProgress()
        } catch (e: Exception) {
            val cancelled = cancelRequested || e is InterruptedException
            val message = if (cancelled) "Загрузка отменена." else "Загрузка завершена с ошибкой: ${e.message ?: e.javaClass.simpleName}"
            prefs.edit().putString("state", if (cancelled) "cancelled" else "completed")
                .putString("message", message).putString("error", if (cancelled) "" else message).commit()
            updateNotification(message, 0, false, true)
            sendProgress()
        } finally {
            running.set(false)
            stopForeground(false)
            stopSelf(startId)
        }
    }

    private fun publish(done: Int, count: Int, name: String, received: Long, expected: Long,
                        ok: Int, bytes: Long, message: String) {
        prefs.edit().putInt("done", done).putInt("count", count).putString("current", name)
            .putLong("received", received).putLong("total", expected).putInt("ok", ok)
            .putLong("bytes_total", bytes).putString("message", message).apply()
        updateNotification(message, if (count > 0) done * 100 / count else 0, false, false)
        sendProgress()
    }

    private fun sendProgress() {
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName))
    }

    private fun buildNotification(text: String, progress: Int, indeterminate: Boolean, finished: Boolean): Notification {
        val open = Intent(this, DownloadCenterActivity::class.java)
        val pi = PendingIntent.getActivity(this, 4301, open,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        val builder = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("GeoTracker — BRouter")
            .setContentText(text).setContentIntent(pi).setOnlyAlertOnce(true)
            .setOngoing(!finished).setAutoCancel(finished)
            .setProgress(100, progress.coerceIn(0,100), indeterminate && !finished)
        if (!finished) {
            val cancelIntent = Intent(this, BRouterSegmentDownloadService::class.java).setAction(ACTION_CANCEL)
            val cancelPi = PendingIntent.getService(this, 4302, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Отменить", cancelPi)
        }
        return builder.build()
    }

    private fun updateNotification(text: String, progress: Int, indeterminate: Boolean, finished: Boolean) {
        nm.notify(NOTIFICATION_ID, buildNotification(text, progress, indeterminate, finished))
    }

    private fun mb(bytes: Long) = String.format(Locale.US, "%.1f", bytes / 1048576.0)

    override fun onBind(intent: Intent?): IBinder? = null
}
