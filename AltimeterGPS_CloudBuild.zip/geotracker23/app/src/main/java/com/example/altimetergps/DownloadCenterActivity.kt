package com.example.altimetergps

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.Locale

/** Single user-facing entry point for selecting a Mapsforge area and downloading its matching data. */
class DownloadCenterActivity : Activity() {
    private lateinit var mapSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private lateinit var cancelButton: Button
    private val choices = MapsforgeCatalog.italy
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() { refreshStatus(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        page.addView(TextView(this).apply {
            text = "ЦЕНТР ЗАГРУЗОК"
            textSize = 24f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 18)
        })
        page.addView(TextView(this).apply {
            text = "Сначала выберите область офлайн-карты. Приложение прочитает её реальные границы из файла карты и по ним подберёт данные маршрутизации и высот."
            textSize = 15f; setPadding(0, 0, 0, 16)
        })
        page.addView(TextView(this).apply { text = "СТРАНА"; textSize = 13f })
        page.addView(TextView(this).apply { text = "Италия"; textSize = 19f; setPadding(0, 4, 0, 12) })
        page.addView(TextView(this).apply { text = "ОБЛАСТЬ ОФЛАЙН-КАРТЫ"; textSize = 13f })
        mapSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@DownloadCenterActivity, android.R.layout.simple_spinner_dropdown_item,
                choices.map { "${it.title}  (${it.fileName})" })
        }
        page.addView(mapSpinner)
        page.addView(TextView(this).apply {
            text = "После выбора приложение загрузит карту, прочитает её координатные границы и по этому прямоугольнику подберёт данные маршрутизации и высот. Дополнительные фрагменты за пределами фактического контура карты допустимы: важнее не пропустить данные у границ."
            textSize = 13f; setPadding(0, 12, 0, 18)
        })
        startButton = Button(this).apply {
            text = "ЗАГРУЗКА КАРТ"
            setOnClickListener { startRegionalDownload() }
        }
        page.addView(startButton)
        cancelButton = Button(this).apply {
            text = "ОТМЕНИТЬ ЗАГРУЗКУ"
            visibility = View.GONE
            setOnClickListener {
                startService(Intent(this@DownloadCenterActivity, RegionalDownloadService::class.java).setAction(RegionalDownloadService.ACTION_CANCEL))
                statusText.text = "Отправлена команда отмены…"
            }
        }
        page.addView(cancelButton)
        statusText = TextView(this).apply { textSize = 15f; setPadding(0, 18, 0, 18) }
        page.addView(statusText)
        page.addView(Button(this).apply {
            text = "ОТКРЫТЬ ОФЛАЙН-КАРТУ / ВЫБРАТЬ ПАПКУ"
            setOnClickListener { startActivity(Intent(this@DownloadCenterActivity, OfflineMapActivity::class.java)) }
        })
        page.addView(Button(this).apply {
            text = "ОТКРЫТЬ ПЛАНИРОВЩИК МАРШРУТОВ"
            setOnClickListener { startActivity(Intent(this@DownloadCenterActivity, RoutePlannerActivity::class.java)) }
        })
        page.addView(Button(this).apply { text = "ЗАКРЫТЬ"; setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(page) })
        refreshStatus()
    }

    override fun onResume() { super.onResume(); handler.removeCallbacks(refreshTask); handler.post(refreshTask) }
    override fun onPause() { handler.removeCallbacks(refreshTask); super.onPause() }

    private fun startRegionalDownload() {
        val choice = choices.getOrNull(mapSpinner.selectedItemPosition) ?: return
        val mapsPrefs = getSharedPreferences("mapsforge", MODE_PRIVATE)
        if (mapsPrefs.getString("maps_tree_uri", null).isNullOrBlank()) {
            statusText.text = "Сначала откройте офлайн-карту и выберите папку для хранения карт. Затем вернитесь сюда."
            return
        }
        val current = getSharedPreferences("regional_download", MODE_PRIVATE).getString("state", "")
        if (current == "running") {
            statusText.text = "Загрузка уже выполняется. Её состояние отображается ниже."
            return
        }
        try {
            // Keep the three data sets together under GeoTracker/<selected map area>/.
            val rootUri = RegionStorage.rootUri(this) ?: Uri.parse(mapsPrefs.getString("maps_tree_uri", null)!!)
            RegionStorage.configure(this, rootUri, choice.fileName.removeSuffix(".map"))
        } catch (e: Exception) {
            statusText.text = "Не удалось подготовить папку для выбранной области: ${e.message}"
            return
        }
        val intent = Intent(this, RegionalDownloadService::class.java).apply {
            action = RegionalDownloadService.ACTION_START
            putExtra(RegionalDownloadService.EXTRA_MAP_NAME, choice.fileName)
            putExtra(RegionalDownloadService.EXTRA_MAP_URL, choice.url)
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            statusText.text = "Запущена загрузка: ${choice.title}"
        } catch (e: Exception) { statusText.text = "Не удалось запустить загрузку: ${e.message}" }
        refreshStatus()
    }

    private fun refreshStatus() {
        val p = getSharedPreferences("regional_download", MODE_PRIVATE)
        val state = p.getString("state", "idle") ?: "idle"
        val stage = p.getString("stage", "") ?: ""
        val message = p.getString("message", "Загрузка ещё не запускалась") ?: ""
        val mapName = p.getString("map_name", "") ?: ""
        val progress = p.getInt("progress", 0)
        val running = state == "running"
        startButton.isEnabled = !running
        mapSpinner.isEnabled = !running
        cancelButton.visibility = if (running) View.VISIBLE else View.GONE
        val mapPrefs = getSharedPreferences("mapsforge", MODE_PRIVATE)
        val bounds = if (mapPrefs.contains("map_south")) {
            val s = mapPrefs.getFloat("map_south", 0f); val w = mapPrefs.getFloat("map_west", 0f)
            val n = mapPrefs.getFloat("map_north", 0f); val e = mapPrefs.getFloat("map_east", 0f)
            "\nГраницы выбранной карты: ${fmt(s)}, ${fmt(w)} — ${fmt(n)}, ${fmt(e)}"
        } else ""
        statusText.text = buildString {
            append("Состояние: ").append(when (state) {
                "running" -> "ВЫПОЛНЯЕТСЯ"
                "completed" -> "ЗАВЕРШЕНО"
                "partial" -> "ЧАСТИЧНО ЗАВЕРШЕНО"
                "cancelled" -> "ОТМЕНЕНО"
                "error" -> "ОШИБКА"
                else -> "ОЖИДАНИЕ"
            })
            if (mapName.isNotBlank()) append("\nОбласть: ").append(mapName)
            if (stage.isNotBlank()) append("\nЭтап: ").append(stage)
            append("\nПрогресс этапов: ").append(progress).append("%")
            append("\n").append(message)
            if (state == "completed" || mapPrefs.getString("download_status", "") == "completed") append(bounds)
            val error = p.getString("error", "") ?: ""
            if (error.isNotBlank() && state == "error") append("\nПодробности: ").append(error)
        }
    }

    private fun fmt(v: Float) = String.format(Locale.US, "%.4f", v)
}
