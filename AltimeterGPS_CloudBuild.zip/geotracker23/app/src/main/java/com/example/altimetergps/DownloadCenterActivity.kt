package com.example.altimetergps

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Persistent overview of DEM and BRouter downloads; independent of the screen that started them. */
class DownloadCenterActivity : Activity() {
    private lateinit var demStatus: TextView
    private lateinit var rd5Status: TextView
    private lateinit var refreshLabel: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            refreshStatuses()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        page.addView(TextView(this).apply {
            text = "ЦЕНТР ЗАГРУЗОК"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })
        page.addView(TextView(this).apply {
            text = "Здесь отображаются загрузки DEM и RD5. Центр остаётся доступным при переходе между экранами."
            textSize = 14f
            setPadding(0, 0, 0, 16)
        })
        page.addView(TextView(this).apply { text = "МОДЕЛИ ВЫСОТ (DEM)"; textSize = 18f })
        demStatus = TextView(this).apply { textSize = 16f; setPadding(0, 8, 0, 8) }
        page.addView(demStatus)
        page.addView(Button(this).apply {
            text = "ОТМЕНИТЬ ЗАГРУЗКУ DEM"
            setOnClickListener {
                startService(Intent(this@DownloadCenterActivity, DemDownloadService::class.java).setAction(DemDownloadService.ACTION_CANCEL))
                refreshStatuses()
            }
        })
        page.addView(TextView(this).apply {
            text = "ДАННЫЕ МАРШРУТИЗАЦИИ (RD5)"
            textSize = 18f
            setPadding(0, 20, 0, 0)
        })
        rd5Status = TextView(this).apply { textSize = 16f; setPadding(0, 8, 0, 8) }
        page.addView(rd5Status)
        page.addView(Button(this).apply {
            text = "ОТМЕНИТЬ ЗАГРУЗКУ RD5"
            setOnClickListener {
                startService(Intent(this@DownloadCenterActivity, BRouterSegmentDownloadService::class.java).setAction(BRouterSegmentDownloadService.ACTION_CANCEL))
                refreshStatuses()
            }
        })
        refreshLabel = TextView(this).apply { textSize = 12f; setPadding(0, 12, 0, 12) }
        page.addView(refreshLabel)
        page.addView(Button(this).apply {
            text = "ОТКРЫТЬ ПЛАНИРОВЩИК МАРШРУТОВ"
            setOnClickListener { startActivity(Intent(this@DownloadCenterActivity, RoutePlannerActivity::class.java)) }
        })
        page.addView(Button(this).apply { text = "ЗАКРЫТЬ"; setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(page) })
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refreshTask)
        handler.post(refreshTask)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshTask)
        super.onPause()
    }

    private fun refreshStatuses() {
        val dem = getSharedPreferences("dem_download", MODE_PRIVATE)
        val ds = dem.getString("state", "idle") ?: "idle"
        val dName = dem.getString("name", "—") ?: "—"
        val dMessage = dem.getString("message", "Загрузки ещё не запускались") ?: ""
        val dDone = dem.getInt("done", 0)
        val dTotal = dem.getInt("total", 0)
        val dSaved = dem.getInt("saved", 0)
        val dMissing = dem.getInt("missing", 0)
        val dErrors = dem.getInt("errors", 0)
        demStatus.text = if (ds == "idle") "Загрузки ещё не запускались" else
            "$dName\nСостояние: ${stateText(ds)}\n$dMessage\nОбработано: $dDone${if (dTotal > 0) " из $dTotal" else ""}\nСохранено: $dSaved • нет данных: $dMissing • ошибок: $dErrors"

        val rd = getSharedPreferences("brouter_download", MODE_PRIVATE)
        val rs = rd.getString("state", "idle") ?: "idle"
        val rMessage = rd.getString("message", "Загрузки ещё не запускались") ?: ""
        val current = rd.getString("current", "") ?: ""
        val done = rd.getInt("done", 0)
        val count = rd.getInt("count", 0)
        val received = rd.getLong("received", 0)
        val total = rd.getLong("total", -1)
        val bytesTotal = rd.getLong("bytes_total", 0)
        val amount = if (total > 0) "${"%.1f".format(received / 1048576.0)} / ${"%.1f".format(total / 1048576.0)} МБ" else "${"%.1f".format(received / 1048576.0)} МБ получено"
        rd5Status.text = if (rs == "idle") "Загрузки ещё не запускались" else
            "$rMessage\nСостояние: ${stateText(rs)}\n${if (current.isNotBlank()) "Текущий файл: $current\n" else ""}Файлов: $done${if (count > 0) " из $count" else ""}\n$amount\nВсего загружено: ${"%.1f".format(bytesTotal / 1048576.0)} МБ"
        refreshLabel.text = "Обновлено автоматически: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}"
    }

    private fun stateText(state: String): String = when (state) {
        "running" -> "ВЫПОЛНЯЕТСЯ"
        "completed" -> "ЗАВЕРШЕНО"
        "cancelled" -> "ОТМЕНЕНО"
        "error" -> "ОШИБКА"
        else -> state
    }
}
