package com.example.altimetergps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.mapsforge.map.reader.MapFile
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/** Foreground downloader: the map transfer survives leaving OfflineMapActivity. */
class MapsforgeDownloadService : Service() {
    companion object {
        const val ACTION_START = "com.example.altimetergps.MAP_DOWNLOAD_START"
        const val ACTION_CANCEL = "com.example.altimetergps.MAP_DOWNLOAD_CANCEL"
        private const val CHANNEL_ID = "mapsforge_download"
        private const val NOTIFICATION_ID = 3201
        private const val MAP_NAME = "openhiking_alps_east.map"
        private const val URL_MAP = "https://www.openhiking.eu/en/component/phocadownload/category/1-terkepek/5-turistaterkepek-mapsforge?Itemid=102&download=28%3Aopenhiking-alps-east"
    }

    private val cancelled = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null
    @Volatile private var activeConnection: HttpURLConnection? = null
    private val prefs by lazy { getSharedPreferences("mapsforge", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancelled.set(true)
                try { activeConnection?.disconnect() } catch (_: Exception) {}
                worker?.interrupt()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (worker?.isAlive == true) return START_NOT_STICKY
                cancelled.set(false)
                createChannel()
                startForeground(NOTIFICATION_ID, notification("Подготовка загрузки карты…", 0, true))
                prefs.edit().putString("download_status", "downloading")
                    .putLong("download_received", 0L).putLong("download_total", -1L)
                    .putLong("download_extracted", 0L).putLong("download_heartbeat", System.currentTimeMillis())
                    .remove("download_error").commit()
                worker = Thread { downloadMap() }.also { it.start() }
            }
        }
        return START_NOT_STICKY
    }

    private fun downloadMap() {
        var connection: HttpURLConnection? = null
        var tempDoc: DocumentFile? = null
        try {
            val treeText = prefs.getString("maps_tree_uri", null)
                ?: throw IllegalStateException("Не выбрана папка для хранения карт")
            val tree = DocumentFile.fromTreeUri(this, Uri.parse(treeText))
                ?: throw IllegalStateException("Нет доступа к выбранной папке. Выберите её заново в приложении.")
            val old = tree.findFile(MAP_NAME)
            val oldPart = tree.findFile("$MAP_NAME.part")
            try { oldPart?.delete() } catch (_: Exception) {}
            tempDoc = tree.createFile("application/octet-stream", "$MAP_NAME.part")
                ?: throw IllegalStateException("Не удалось создать временный файл в выбранной папке")
            connection = (URL(URL_MAP).openConnection() as HttpURLConnection).apply {
                connectTimeout = 45000; readTimeout = 180000; instanceFollowRedirects = true
                requestMethod = "GET"; useCaches = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36 GeoTracker/3.13")
                setRequestProperty("Accept", "application/zip,application/octet-stream,*/*")
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("Referer", "https://www.openhiking.eu/en/downloads/mapsforge-maps")
                setRequestProperty("Connection", "close")
            }
            activeConnection = connection
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("Сервер ответил HTTP $code")
            val total = connection.contentLengthLong
            prefs.edit().putLong("download_total", total).commit()
            var extracted = 0L
            var foundMap = false
            val counted = CountingInputStream(BufferedInputStream(connection.inputStream, 256 * 1024))
            val output = contentResolver.openOutputStream(tempDoc.uri, "w")
                ?: throw IllegalStateException("Не удалось открыть файл для записи")
            output.use { out ->
                ZipInputStream(counted).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name.lowercase(Locale.ROOT).endsWith(".map")) {
                            val buffer = ByteArray(256 * 1024)
                            var lastUpdate = 0L
                            while (true) {
                                if (cancelled.get() || Thread.currentThread().isInterrupted) throw InterruptedException("Загрузка остановлена")
                                val n = zip.read(buffer)
                                if (n < 0) break
                                out.write(buffer, 0, n)
                                extracted += n
                                val now = System.currentTimeMillis()
                                if (now - lastUpdate >= 700L) {
                                    lastUpdate = now
                                    prefs.edit().putLong("download_received", counted.bytesRead).putLong("download_extracted", extracted)
                                        .putLong("download_heartbeat", System.currentTimeMillis()).apply()
                                    val pct = if (total > 0L) ((counted.bytesRead * 100L) / total).toInt().coerceIn(0, 99) else 0
                                    updateNotification(if (total > 0L) "Загрузка карты: $pct% • ${mb(extracted)} МБ распаковано" else "Загружено ${mb(counted.bytesRead)} МБ • распаковано ${mb(extracted)} МБ", pct, total <= 0L)
                                }
                            }
                            foundMap = true
                            break
                        }
                        zip.closeEntry(); entry = zip.nextEntry
                    }
                }
            }
            if (!foundMap || extracted < 500L * 1024L * 1024L) throw IllegalStateException("Архив неполный или не содержит полноценную карту .map")
            if (cancelled.get()) throw InterruptedException("Загрузка остановлена")
            val pfd = contentResolver.openFileDescriptor(tempDoc.uri, "r") ?: throw IllegalStateException("Не удалось проверить загруженную карту")
            pfd.use { descriptor -> MapFile(FileInputStream(descriptor.fileDescriptor)).close() }
            // The temporary map is fully downloaded and validated; only now replace an older copy.
            try { old?.delete() } catch (_: Exception) {}
            val renamed = tempDoc.renameTo(MAP_NAME)
            if (!renamed) {
                val finalDoc = tree.createFile("application/octet-stream", MAP_NAME)
                    ?: throw IllegalStateException("Проверенная карта загружена, но не удалось создать итоговый файл")
                try {
                    val input = contentResolver.openInputStream(tempDoc.uri) ?: throw IllegalStateException("Не удалось прочитать временную карту")
                    val out = contentResolver.openOutputStream(finalDoc.uri, "w") ?: throw IllegalStateException("Не удалось сохранить итоговую карту")
                    input.use { src -> out.use { dst -> src.copyTo(dst, 256 * 1024) } }
                    tempDoc.delete()
                } catch (e: Exception) { finalDoc.delete(); throw e }
            }
            val finalDoc = tree.findFile(MAP_NAME) ?: throw IllegalStateException("Файл карты не найден после сохранения")
            prefs.edit().putString("downloaded_map_uri", finalDoc.uri.toString())
                .putString("download_status", "completed").putLong("download_extracted", extracted).commit()
            updateNotification("Карта загружена и проверена", 100, false, true)
        } catch (e: InterruptedException) {
            try { tempDoc?.delete() } catch (_: Exception) {}
            prefs.edit().putString("download_status", "cancelled").commit()
            updateNotification("Загрузка карты остановлена", 0, false, true)
        } catch (e: Exception) {
            try { tempDoc?.delete() } catch (_: Exception) {}
            prefs.edit().putString("download_status", "failed").putString("download_error", e.message ?: "ошибка соединения").commit()
            updateNotification("Ошибка загрузки: ${e.message ?: "соединение прервано"}", 0, false, true)
        } finally {
            connection?.disconnect(); activeConnection = null
            stopForeground(STOP_FOREGROUND_DETACH); stopSelf()
        }
    }

    private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
        var bytesRead = 0L
            private set
        override fun read(): Int { val v = super.read(); if (v >= 0) bytesRead++; return v }
        override fun read(b: ByteArray, off: Int, len: Int): Int { val n = super.read(b, off, len); if (n > 0) bytesRead += n; return n }
    }

    private fun mb(bytes: Long) = String.format(Locale.US, "%.0f", bytes / 1048576.0)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Загрузка офлайн-карт", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String, progress: Int, indeterminate: Boolean, finished: Boolean = false): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("GeoTracker — офлайн-карта")
            .setContentText(text)
            .setOngoing(!finished)
            .setOnlyAlertOnce(true)
        if (finished) builder.setProgress(0, 0, false)
        else builder.setProgress(100, progress, indeterminate)
        return builder.build()
    }

    private fun updateNotification(text: String, progress: Int, indeterminate: Boolean, finished: Boolean = false) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text, progress, indeterminate, finished))
    }
}
