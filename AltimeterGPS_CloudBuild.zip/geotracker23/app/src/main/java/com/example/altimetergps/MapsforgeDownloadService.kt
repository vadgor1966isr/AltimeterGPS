package com.example.altimetergps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import org.mapsforge.map.reader.MapFile
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Downloads and validates a selected Mapsforge .map file, then records its real header bounds. */
class MapsforgeDownloadService : Service() {
    companion object {
        const val ACTION_START = "com.example.altimetergps.MAP_DOWNLOAD_START"
        const val ACTION_CANCEL = "com.example.altimetergps.MAP_DOWNLOAD_CANCEL"
        const val EXTRA_MAP_NAME = "map_name"
        const val EXTRA_MAP_URL = "map_url"
        private const val CHANNEL_ID = "mapsforge_download"
        private const val NOTIFICATION_ID = 3201
    }

    private val cancelled = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null
    @Volatile private var activeConnection: HttpURLConnection? = null
    private val prefs by lazy { getSharedPreferences("mapsforge", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancelled.set(true)
                try { activeConnection?.disconnect() } catch (_: Exception) {}
                worker?.interrupt()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (worker?.isAlive == true) return START_NOT_STICKY
                val name = intent.getStringExtra(EXTRA_MAP_NAME) ?: "italy-nord-est.map"
                val url = intent.getStringExtra(EXTRA_MAP_URL) ?: "https://download.mapsforge.org/maps/v5/europe/italy/nord-est.map"
                cancelled.set(false)
                createChannel()
                startForeground(NOTIFICATION_ID, notification("Подготовка карты $name", 0, true))
                prefs.edit().putString("download_status", "downloading")
                    .putString("selected_map_name", name).putString("selected_map_url", url)
                    .putLong("download_received", 0L).putLong("download_total", -1L)
                    .remove("download_error").commit()
                worker = Thread { downloadMap(name, url, startId) }.also { it.start() }
            }
        }
        return START_NOT_STICKY
    }

    private fun downloadMap(mapName: String, mapUrl: String, startId: Int) {
        var connection: HttpURLConnection? = null
        var temp: DocumentFile? = null
        try {
            val treeText = prefs.getString("maps_tree_uri", null)
                ?: throw IllegalStateException("Сначала выберите папку для хранения офлайн-карт")
            val tree = RegionStorage.regionFolder(this, "Maps")
                ?: DocumentFile.fromTreeUri(this, Uri.parse(treeText))
                ?: throw IllegalStateException("Нет доступа к выбранной папке. Выберите её заново.")
            val finalName = mapName.substringAfterLast('/')
            try { tree.findFile("$finalName.part")?.delete() } catch (_: Exception) {}
            temp = tree.createFile("application/octet-stream", "$finalName.part")
                ?: throw IllegalStateException("Не удалось создать временный файл карты")
            connection = (URL(mapUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 45000; readTimeout = 180000; instanceFollowRedirects = true
                requestMethod = "GET"; useCaches = false
                setRequestProperty("User-Agent", "GeoTracker/3.23 (Android)")
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("Connection", "close")
            }
            activeConnection = connection
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("Сервер карт ответил HTTP $code")
            val expected = connection.contentLengthLong
            prefs.edit().putLong("download_total", expected).commit()
            var received = 0L
            val output = contentResolver.openOutputStream(temp.uri, "w")
                ?: throw IllegalStateException("Не удалось открыть файл карты для записи")
            output.use { out ->
                connection.inputStream.buffered().use { input ->
                    val buffer = ByteArray(256 * 1024)
                    var last = 0L
                    while (true) {
                        if (cancelled.get() || Thread.currentThread().isInterrupted) throw InterruptedException("Загрузка отменена")
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        received += n
                        val now = System.currentTimeMillis()
                        if (now - last > 700) {
                            last = now
                            prefs.edit().putLong("download_received", received).apply()
                            val pct = if (expected > 0) (received * 100 / expected).toInt().coerceIn(0, 99) else 0
                            updateNotification("$finalName • ${mb(received)} МБ", pct, expected <= 0)
                        }
                    }
                }
            }
            if (received < 1024L * 1024L) throw IllegalStateException("Загруженный файл слишком мал — это не полноценная карта")
            if (expected > 0 && received != expected) throw IllegalStateException("Загрузка неполная: $received из $expected байт")
            if (cancelled.get()) throw InterruptedException("Загрузка отменена")

            val pfd = contentResolver.openFileDescriptor(temp.uri, "r") ?: throw IllegalStateException("Не удалось проверить файл карты")
            val bounds = pfd.use { descriptor ->
                val map = MapFile(FileInputStream(descriptor.fileDescriptor))
                try {
                    val box = map.getMapFileInfo().boundingBox
                    doubleArrayOf(box.minLatitude, box.minLongitude, box.maxLatitude, box.maxLongitude)
                } finally { map.close() }
            }
            require(bounds[0] < bounds[2] && bounds[1] < bounds[3]) { "В карте некорректные географические границы" }

            val old = tree.findFile(finalName)
            try { old?.delete() } catch (_: Exception) {}
            if (!temp.renameTo(finalName)) {
                val dest = tree.createFile("application/octet-stream", finalName)
                    ?: throw IllegalStateException("Не удалось создать итоговый файл карты")
                try {
                    val input = contentResolver.openInputStream(temp.uri) ?: throw IllegalStateException("Не удалось прочитать временный файл")
                    val out = contentResolver.openOutputStream(dest.uri, "w") ?: throw IllegalStateException("Не удалось записать итоговый файл")
                    input.use { src -> out.use { dst -> src.copyTo(dst, 256 * 1024) } }
                    temp.delete()
                } catch (e: Exception) { dest.delete(); throw e }
            }
            val saved = tree.findFile(finalName) ?: throw IllegalStateException("Сохранённая карта не найдена")
            prefs.edit().putString("downloaded_map_uri", saved.uri.toString())
                .putString("downloaded_map_name", finalName)
                .putFloat("map_south", bounds[0].toFloat()).putFloat("map_west", bounds[1].toFloat())
                .putFloat("map_north", bounds[2].toFloat()).putFloat("map_east", bounds[3].toFloat())
                .putString("download_status", "completed").putLong("download_received", received).commit()
            updateNotification("Карта проверена • ${bounds[0]}, ${bounds[1]} — ${bounds[2]}, ${bounds[3]}", 100, false, true)
        } catch (e: InterruptedException) {
            try { temp?.delete() } catch (_: Exception) {}
            prefs.edit().putString("download_status", "cancelled").commit()
            updateNotification("Загрузка карты отменена", 0, false, true)
        } catch (e: Exception) {
            try { temp?.delete() } catch (_: Exception) {}
            prefs.edit().putString("download_status", "failed").putString("download_error", e.message ?: "ошибка").commit()
            updateNotification("Ошибка карты: ${e.message ?: "неизвестная ошибка"}", 0, false, true)
        } finally {
            connection?.disconnect(); activeConnection = null
            stopForeground(STOP_FOREGROUND_DETACH); stopSelf(startId)
        }
    }

    private fun mb(bytes: Long) = String.format(Locale.US, "%.1f", bytes / 1048576.0)
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL_ID, "Загрузка офлайн-карт", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(text: String, progress: Int, indeterminate: Boolean, finished: Boolean = false): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("GeoTracker — офлайн-карта").setContentText(text)
            .setOngoing(!finished).setOnlyAlertOnce(true).setProgress(100, progress.coerceIn(0, 100), indeterminate && !finished).build()
    private fun updateNotification(text: String, progress: Int, indeterminate: Boolean, finished: Boolean = false) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text, progress, indeterminate, finished))
    }
}
