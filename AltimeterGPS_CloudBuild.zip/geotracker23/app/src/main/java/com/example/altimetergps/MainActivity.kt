package com.example.altimetergps

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.widget.*
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

private class CompassDialView(context: Context) : android.view.View(context) {
    private val density = resources.displayMetrics.density
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private var heading = 0f

    fun setHeading(value: Float) {
        heading = ((value % 360f) + 360f) % 360f
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = minOf(width, height) * 0.43f
        paint.style = android.graphics.Paint.Style.FILL
        paint.color = 0xFF142C40.toInt()
        canvas.drawCircle(cx, cy, radius + 5f * density, paint)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f * density
        paint.color = 0xFF83B9D5.toInt()
        canvas.drawCircle(cx, cy, radius, paint)
        paint.strokeWidth = 1.5f * density
        // Rotate the compass rose so north remains aligned with the real north direction.
        canvas.save()
        canvas.rotate(-heading, cx, cy)
        for (i in 0 until 36) {
            val angle = Math.toRadians((i * 10 - 90).toDouble())
            val outer = radius - 3f * density
            val inner = outer - if (i % 9 == 0) 13f * density else if (i % 3 == 0) 9f * density else 5f * density
            val x1 = cx + (inner * kotlin.math.cos(angle)).toFloat()
            val y1 = cy + (inner * kotlin.math.sin(angle)).toFloat()
            val x2 = cx + (outer * kotlin.math.cos(angle)).toFloat()
            val y2 = cy + (outer * kotlin.math.sin(angle)).toFloat()
            paint.color = 0xFFB8D2E0.toInt()
            canvas.drawLine(x1, y1, x2, y2, paint)
        }
        paint.style = android.graphics.Paint.Style.FILL
        paint.textAlign = android.graphics.Paint.Align.CENTER
        paint.textSize = 12f * density
        paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        val labels = arrayOf("С", "В", "Ю", "З")
        for (i in labels.indices) {
            val angle = Math.toRadians((i * 90 - 90).toDouble())
            paint.color = if (i == 0) 0xFFFF7777.toInt() else 0xFFE5F0F5.toInt()
            canvas.drawText(labels[i], cx + (radius * 0.72f * kotlin.math.cos(angle)).toFloat(), cy + (radius * 0.72f * kotlin.math.sin(angle)).toFloat() + 4f * density, paint)
        }
        // Rotate the needle together with the compass rose so its red tip
        // stays exactly aligned with the north mark on the rotating dial.
        val half = 8f * density
        val tip = radius * 0.57f
        val tail = radius * 0.43f
        val path = android.graphics.Path().apply {
            moveTo(cx, cy - tip)
            lineTo(cx - half, cy + 2f * density)
            lineTo(cx, cy - 3f * density)
            lineTo(cx + half, cy + 2f * density)
            close()
        }
        paint.color = 0xFFFF6666.toInt()
        canvas.drawPath(path, paint)
        val tailPath = android.graphics.Path().apply {
            moveTo(cx, cy + tail)
            lineTo(cx - half * 0.75f, cy - 2f * density)
            lineTo(cx, cy + 3f * density)
            lineTo(cx + half * 0.75f, cy - 2f * density)
            close()
        }
        paint.color = 0xFFE3EDF2.toInt()
        canvas.drawPath(tailPath, paint)
        canvas.restore()
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(cx, cy, 3.5f * density, paint)
    }
}

class MainActivity : Activity(), LocationListener, SensorEventListener {
    private lateinit var lm: LocationManager
    private lateinit var current: TextView
    private lateinit var average: TextView
    private lateinit var terrain: TextView
    private lateinit var hAcc: TextView
    private lateinit var status: TextView
    private lateinit var updated: TextView
    private lateinit var speedView: TextView
    private lateinit var compassView: TextView
    private lateinit var compassDial: CompassDialView
    private lateinit var terrainUpdatedView: TextView
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private var lastTerrainUpdateTime = 0L
    private lateinit var coordinates: TextView
    private lateinit var mapView: WebView
    private var mapReady = false
    private var mapHasLocation = false
    private var latestCoordinates = ""
    private val samples = ArrayDeque<Pair<Long, Double>>()
    private val executor = Executors.newSingleThreadExecutor()
    private val terrainReadInProgress = AtomicBoolean(false)
    private var lastTerrainFetch = 0L
    private var lastLat = 0.0
    private var lastLon = 0.0
    private var lastTerrainLat = 0.0
    private var lastTerrainLon = 0.0
    private var lastUiUpdate = 0L
    private var cachedPositionRestored = false
    private var latestGpsAltitude: Double? = null
    private var terrainAltitude: Double? = null
    private var lastValidGpsAltitude: Double? = null
    private var lastValidAverageAltitude: Double? = null
    private val requestCode = 101
    private val demZoom = 12
    private val demDownloading = AtomicBoolean(false)
    private var demProgressDialog: android.app.AlertDialog? = null
    private var demProgressText: TextView? = null
    private var demProgressBar: ProgressBar? = null
    private val demReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != DemDownloadService.ACTION_PROGRESS) return
            val done = intent.getIntExtra("done", 0)
            val total = intent.getIntExtra("total", 0)
            val saved = intent.getIntExtra("saved", 0)
            val missing = intent.getIntExtra("missing", 0)
            val errors = intent.getIntExtra("errors", 0)
            val complete = intent.getBooleanExtra("complete", false)
            demProgressBar?.max = total.coerceAtLeast(1)
            demProgressBar?.progress = done.coerceAtMost(total)
            demProgressText?.text = if (complete) "Завершено.\nСохранено: $saved\nНет данных: $missing\nОшибок: $errors" else
                "Обработано $done из $total\nСохранено: $saved • нет данных: $missing • ошибок: $errors\nЗагрузка продолжается в фоне — смотрите уведомление Android."
            if (complete) {
                demDownloading.set(false)
                if (saved > 0) Toast.makeText(this@MainActivity, "Загрузка завершена: $saved фрагментов сохранено. Проверяю высоту по текущему GPS…", Toast.LENGTH_LONG).show()
                demProgressDialog?.getButton(android.app.AlertDialog.BUTTON_NEGATIVE)?.text = "Закрыть"
                // Сразу перечитываем DEM для текущего GPS: до загрузки нужного тайла
                // предыдущая проверка могла вернуть отсутствие данных.
                if (mapHasLocation && (lastLat != 0.0 || lastLon != 0.0)) {
                    lastTerrainFetch = 0L
                    fetchTerrain(lastLat, lastLon)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 202)
        }
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 28)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF10243A.toInt(), 0xFF183B55.toInt(), 0xFF0D1B2A.toInt())
            )
        }
        fun text(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(4, 5, 4, 5)
        }
        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16, 13, 16, 13)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF203B52.toInt())
                cornerRadius = 24f
                setStroke(1, 0xFF426078.toInt())
            }
            elevation = 5f
        }
        fun addCard(v: android.view.View, top: Int = 10) {
            page.addView(v, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = top
            })
        }

        page.addView(text(14f, 0xFF9DB9CC.toInt(), true).apply { text = "GEOTRACKER" })
        page.addView(text(27f, 0xFFFFFFFF.toInt(), true).apply { text = "МОЁ МЕСТОПОЛОЖЕНИЕ" })
        page.addView(text(13f, 0xFF9DB9CC.toInt()).apply { text = "ТЕКУЩЕЕ МЕСТОПОЛОЖЕНИЕ" })

        val mapCard = card()
        mapCard.addView(text(14f, 0xFF9FC3D9.toInt(), true).apply { text = "КАРТА ТЕКУЩЕГО МЕСТОПОЛОЖЕНИЯ" })
        mapView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    mapReady = true
                    if (lastLat != 0.0 || lastLon != 0.0) updateMapLocation(lastLat, lastLon)
                }
            }
            setBackgroundColor(0xFFE7E5DF.toInt())
            overScrollMode = android.view.View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = false
        }
        mapCard.addView(mapView, LinearLayout.LayoutParams(-1, dp(280)).apply {
            topMargin = 8
        })
        val mapButton = Button(this).apply {
            text = "ПОКАЗАТЬ МОЁ МЕСТОПОЛОЖЕНИЕ"
            setOnClickListener {
                if (mapHasLocation) mapView.evaluateJavascript("map.setView([$lastLat,$lastLon],16,{animate:false});", null)
                else Toast.makeText(this@MainActivity, "Ожидание координат GPS…", Toast.LENGTH_SHORT).show()
            }
        }
        mapCard.addView(mapButton)
        addCard(mapCard, 12)
        mapView.loadDataWithBaseURL("https://altimetergps.local/", mapHtml(), "text/html", "UTF-8", null)

        // Равноценные показатели под картой: высота, местоположение и компас.
        val dataCard = card()
        fun addMetric(title: String, value: TextView) {
            dataCard.addView(text(12f, 0xFF9FC3D9.toInt(), true).apply { text = title })
            dataCard.addView(value)
        }
        terrain = text(17f, 0xFFFFFFFF.toInt(), true).apply { text = "Ожидание координат для офлайн-высоты…" }
        addMetric("ВЫСОТА НАД УРОВНЕМ МОРЯ", terrain)
        coordinates = text(16f, 0xFFFFFFFF.toInt()).apply { text = "Широта: —\nДолгота: —" }
        addMetric("МЕСТОПОЛОЖЕНИЕ", coordinates)
        dataCard.addView(text(12f, 0xFF9FC3D9.toInt(), true).apply { text = "НАПРАВЛЕНИЕ" })
        compassDial = CompassDialView(this)
        dataCard.addView(compassDial, LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(6) })
        compassView = text(17f, 0xFFFFFFFF.toInt(), true).apply { text = "Направление: —" }
        dataCard.addView(compassView)
        val copyButton = Button(this).apply {
            text = "КОПИРОВАТЬ КООРДИНАТЫ"
            setOnClickListener {
                if (latestCoordinates.isNotEmpty()) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GPS coordinates", latestCoordinates))
                    Toast.makeText(this@MainActivity, "Координаты скопированы", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this@MainActivity, "Пока нет координат GPS", Toast.LENGTH_SHORT).show()
            }
        }
        dataCard.addView(copyButton)
        addCard(dataCard, 12)

        val offlineCard = card()
        offlineCard.addView(text(15f, 0xFF9FC3D9.toInt(), true).apply { text = "ОФЛАЙН-МОДЕЛИ ВЫСОТ" })
        offlineCard.addView(text(12f, 0xFFD7E5ED.toInt()).apply {
            text = "Скачайте территорию заранее. После загрузки высота определяется без интернета."
        })
        offlineCard.addView(Button(this).apply {
            text = "УПРАВЛЕНИЕ ОФЛАЙН-ДАННЫМИ"
            setOnClickListener { showOfflineDemDialog() }
        })
        addCard(offlineCard, 12)

        val infoCard = card()
        hAcc = text(14f, 0xFFD7E5ED.toInt()).apply { text = "Точность координат: —" }
        speedView = text(16f, 0xFFD7E5ED.toInt(), true).apply { text = "Скорость: — км/ч" }
        terrainUpdatedView = text(12f, 0xFF9DB9CC.toInt()).apply { text = "Высота обновлена: —" }
        status = text(15f, 0xFF7FE0A0.toInt(), true).apply { text = "Ожидание GPS…" }
        updated = text(12f, 0xFF9DB9CC.toInt()).apply { text = "" }
        infoCard.addView(hAcc)
        infoCard.addView(speedView)
        infoCard.addView(terrainUpdatedView)
        infoCard.addView(status)
        addCard(infoCard)

        val buttons = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "Обновить GPS"; setOnClickListener { checkPermission() } })
        buttons.addView(Button(this).apply {
            text = "Повторить офлайн-высоту"
            setOnClickListener {
                if (lastLat.isFinite() && lastLon.isFinite() && (lastLat != 0.0 || lastLon != 0.0)) {
                    lastTerrainFetch = System.currentTimeMillis()
                    lastTerrainLat = lastLat
                    lastTerrainLon = lastLon
                    fetchTerrain(lastLat, lastLon)
                } else {
                    terrain.text = "Нет координат для высоты"
                    terrainUpdatedView.text = "Сначала получите координаты GPS"
                }
            }
        })
        buttons.addView(Button(this).apply {
            text = "Сбросить"
            setOnClickListener { samples.clear(); latestGpsAltitude = null; lastValidGpsAltitude = null; lastValidAverageAltitude = null; updateGpsAltitudeDisplay(); status.text = "Измерения сброшены" }
        })
        addCard(buttons)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(page) })
        checkPermission()
    }

    private fun updateGpsAltitudeDisplay() {
        val reference = terrainAltitude
        if (reference != null && abs(reference) >= 1.0) {
            val gps = latestGpsAltitude
            if (gps != null && abs(gps - reference) <= abs(reference) * 0.20) {
                lastValidGpsAltitude = gps
            }
            val avg = if (samples.isNotEmpty()) samples.map { it.second }.average() else null
            if (avg != null && abs(avg - reference) <= abs(reference) * 0.20) {
                lastValidAverageAltitude = avg
            }
        }
        average.text = lastValidAverageAltitude?.let {
            String.format(Locale.getDefault(), "%.1f m", it)
        } ?: "— m"
    }

    private fun formatDms(value: Double, latitude: Boolean): String {
        val absolute = abs(value)
        val degrees = absolute.toInt()
        val minutesFull = (absolute - degrees) * 60.0
        val minutes = minutesFull.toInt()
        val seconds = (minutesFull - minutes) * 60.0
        val hemisphere = if (latitude) {
            if (value >= 0) "N" else "S"
        } else {
            if (value >= 0) "E" else "W"
        }
        return String.format(Locale.US, "%d° %02d′ %05.2f″ %s", degrees, minutes, seconds, hemisphere)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun updateMapLocation(lat: Double, lon: Double) {
        if (!mapReady) return
        mapView.evaluateJavascript("if(window.updateGpsPosition){window.updateGpsPosition($lat,$lon);}", null)
    }

    private fun mapHtml(): String = """<!DOCTYPE html>
<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>html,body,#map{height:100%;width:100%;margin:0;padding:0;background:#e7e5df} .leaflet-control-attribution{font-size:9px}</style>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script></head>
<body><div id="map"></div><script>
var map=L.map('map',{zoomControl:true}).setView([32.7,35.3],7);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
 maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
var gpsMarker=null;
window.updateGpsPosition=function(lat,lon){
 var point=[lat,lon];
 if(!gpsMarker){gpsMarker=L.marker(point).addTo(map).bindPopup('Ваше местоположение');map.setView(point,16);}
 else{gpsMarker.setLatLng(point);}
};
setTimeout(function(){map.invalidateSize();},300);
</script></body></html>"""

    private fun checkPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestCode)
        else startGps()
    }
    private fun startGps() {
        try {
            // First use the freshest cached position from any enabled provider.
            // Offline DEM lookup needs coordinates only; it must not wait for a new GPS fix.
            if (!cachedPositionRestored) {
                cachedPositionRestored = true
                val cached = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                    .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null } }
                    .maxByOrNull { it.time }
                if (cached != null) onLocationChanged(cached)
                else {
                    val prefs = getSharedPreferences("last_position", Context.MODE_PRIVATE)
                    // Current versions save coordinates as Double bits (latBits/lonBits).
                    // The previous check looked for legacy Float keys first, so it silently
                    // skipped the saved position and left offline elevation waiting forever.
                    val hasDoublePosition = prefs.contains("latBits") && prefs.contains("lonBits")
                    val hasLegacyPosition = prefs.contains("lat") && prefs.contains("lon")
                    if (hasDoublePosition || hasLegacyPosition) {
                        val lat = if (hasDoublePosition) java.lang.Double.longBitsToDouble(prefs.getLong("latBits", 0L)) else prefs.getFloat("lat", 0f).toDouble()
                        val lon = if (hasDoublePosition) java.lang.Double.longBitsToDouble(prefs.getLong("lonBits", 0L)) else prefs.getFloat("lon", 0f).toDouble()
                        if (lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0) {
                            lastLat = lat; lastLon = lon; mapHasLocation = true
                            latestCoordinates = "${formatDms(lat, true)}, ${formatDms(lon, false)}"
                            coordinates.text = "Широта: ${formatDms(lat, true)}\nДолгота: ${formatDms(lon, false)}"
                            updateMapLocation(lat, lon)
                            lastTerrainFetch = System.currentTimeMillis()
                            lastTerrainLat = lat; lastTerrainLon = lon
                            fetchTerrain(lat, lon)
                        }
                    }
                }
            }
            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                status.text = if (mapHasLocation) "GPS недоступен • проверяю высоту по последним координатам" else "Включите Местоположение / GPS"
                return
            }
            lm.removeUpdates(this); status.text="Поиск спутников GPS…"
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000L,5f,this,Looper.getMainLooper())
        } catch (_:Exception) { status.text="Не удалось запустить GPS" }
    }
    override fun onLocationChanged(loc:Location) {
        val now=System.currentTimeMillis()
        getSharedPreferences("last_position", Context.MODE_PRIVATE).edit()
            .putLong("latBits", java.lang.Double.doubleToRawLongBits(loc.latitude))
            .putLong("lonBits", java.lang.Double.doubleToRawLongBits(loc.longitude)).apply()
        val recent=samples.filter { now-it.first<=30000L }.map { it.second }.sorted()
        val median=if(recent.isEmpty()) null else recent[recent.size/2]
        if(median==null || abs(loc.altitude-median)<=80.0 || recent.size<3) samples.addLast(now to loc.altitude)
        while(samples.isNotEmpty() && now-samples.first().first>30000L) samples.removeFirst()
        if (now - lastUiUpdate < 5000L) {
            lastLat = loc.latitude
            lastLon = loc.longitude
            latestCoordinates = "${formatDms(loc.latitude, true)}, ${formatDms(loc.longitude, false)}"
            mapHasLocation = true
            // Even when the visual GPS update is throttled, the first DEM lookup
            // must not be skipped.
            if (lastTerrainFetch == 0L || (terrainAltitude == null && now - lastTerrainFetch > 30000L)) {
                lastTerrainFetch = now; lastTerrainLat = loc.latitude; lastTerrainLon = loc.longitude
                fetchTerrain(loc.latitude, loc.longitude)
            }
            return
        }
        lastUiUpdate = now
        latestGpsAltitude = loc.altitude
        latestCoordinates = "${formatDms(loc.latitude, true)}, ${formatDms(loc.longitude, false)}"
        lastLat = loc.latitude
        lastLon = loc.longitude
        mapHasLocation = true
        updateMapLocation(loc.latitude, loc.longitude)
        coordinates.text = "Широта: ${formatDms(loc.latitude, true)}\nДолгота: ${formatDms(loc.longitude, false)}"
        updateGpsAltitudeDisplay()
        hAcc.text=String.format(Locale.getDefault(),"Точность координат: ±%.0f м",loc.accuracy)
        speedView.text = if (loc.hasSpeed()) {
            String.format(Locale.getDefault(), "Скорость: %.1f км/ч", loc.speed * 3.6f)
        } else {
            "Скорость: — км/ч"
        }
        status.text="GPS работает • измерений: ${samples.size}"
        val moved = if (lastTerrainFetch == 0L) true else {
            val distance = FloatArray(1)
            Location.distanceBetween(lastTerrainLat, lastTerrainLon, loc.latitude, loc.longitude, distance)
            distance[0] > 100f
        }
        if (lastTerrainFetch == 0L || (terrainAltitude == null && now - lastTerrainFetch > 30000L) ||
            now - lastTerrainFetch > 300000L || (moved && now - lastTerrainFetch > 120000L)) {
            lastTerrainFetch=now; lastTerrainLat=loc.latitude; lastTerrainLon=loc.longitude; fetchTerrain(loc.latitude,loc.longitude)
        }
    }
    private data class ElevationRead(val value: Double?, val diagnostic: String)

    private fun fetchTerrain(lat:Double,lon:Double) {
        if (!lat.isFinite() || !lon.isFinite() || lat !in -85.05112878..85.05112878 || lon !in -180.0..180.0) {
            terrain.text = "Нет корректных координат для высоты"
            terrainUpdatedView.text = "Проверьте GPS-координаты"
            return
        }
        // Do not queue repeated DEM reads while an earlier read is still running.
        if (!terrainReadInProgress.compareAndSet(false, true)) {
            runOnUiThread {
                if (!isFinishing && !isDestroyed && terrainAltitude == null) {
                    terrain.text = "Чтение офлайн-высоты…"
                    terrainUpdatedView.text = "Предыдущая проверка ещё выполняется"
                }
            }
            return
        }
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                terrain.text = "Проверяю офлайн-высоту…"
                terrainUpdatedView.text = String.format(Locale.US, "Координаты: %.5f, %.5f", lat, lon)
            }
        }
        try {
            executor.execute {
                val result = try {
                    readOfflineElevation(lat, lon)
                } catch (oom: OutOfMemoryError) {
                    ElevationRead(null, "Недостаточно памяти при чтении DEM; приложение продолжает работу")
                } catch (e: Exception) {
                    ElevationRead(null, "Ошибка чтения DEM: ${e.javaClass.simpleName}: ${e.message ?: "без подробностей"}")
                }
                // Release the guard on the worker thread, not inside the UI callback.
                // This guarantees that a later GPS update or manual retry can start a new read.
                terrainReadInProgress.set(false)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    val value = result.value
                    if (value != null && value.isFinite() && value > -12000.0) {
                        terrainAltitude = value
                        terrain.text = String.format(Locale.getDefault(), "%.1f m", value)
                        lastTerrainUpdateTime = System.currentTimeMillis()
                        terrainUpdatedView.text = "Офлайн-модель • " +
                            SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastTerrainUpdateTime))
                        status.text = "Высота получена из офлайн-модели"
                        updateGpsAltitudeDisplay()
                    } else {
                        terrainAltitude = null
                        terrain.text = "Высота не определена"
                        terrainUpdatedView.text = result.diagnostic
                        status.text = "Офлайн-чтение завершено без высоты"
                    }
                }
            }
        } catch (e: java.util.concurrent.RejectedExecutionException) {
            terrainReadInProgress.set(false)
            if (!isFinishing && !isDestroyed) {
                terrain.text = "Чтение высоты недоступно"
                terrainUpdatedView.text = "Фоновый исполнитель уже остановлен. Перезапустите приложение."
            }
        }
    }

    private fun demDir(): File = File(filesDir, "dem/$demZoom").apply { mkdirs() }
    private fun tileFile(x: Int, y: Int): File = File(demDir(), "${x}_${y}.png")

    private fun tileXY(lat: Double, lon: Double, zoom: Int): Pair<Int, Int> {
        val n = 1 shl zoom
        val x = kotlin.math.floor((lon + 180.0) / 360.0 * n).toInt().coerceIn(0, n - 1)
        val latRad = Math.toRadians(lat.coerceIn(-85.05112878, 85.05112878))
        val y = kotlin.math.floor((1.0 - kotlin.math.ln(kotlin.math.tan(latRad) + 1.0 / kotlin.math.cos(latRad)) / Math.PI) / 2.0 * n).toInt().coerceIn(0, n - 1)
        return x to y
    }

    private fun readOfflineElevation(lat: Double, lon: Double): ElevationRead {
        var bitmap: Bitmap? = null
        try {
            val (x, y) = tileXY(lat, lon, demZoom)
            val file = tileFile(x, y)
            if (!file.exists()) return ElevationRead(null, "Нет локального тайла $x/$y для этих координат")
            val length = file.length()
            if (length < 50L || length > 4L * 1024L * 1024L)
                return ElevationRead(null, "Файл тайла $x/$y имеет подозрительный размер: $length байт")

            // Check PNG signature and dimensions before allocating a bitmap. This prevents
            // malformed or unexpectedly huge files from causing an avoidable memory crash.
            val signatureOk = file.inputStream().use { input ->
                val sig = ByteArray(8)
                input.read(sig) == 8 && sig.contentEquals(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
            }
            if (!signatureOk) return ElevationRead(null, "Файл тайла $x/$y повреждён: неверная сигнатура PNG")

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true; inScaled = false }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth != 256 || bounds.outHeight != 256)
                return ElevationRead(null, "Неверный размер PNG $x/$y: ${bounds.outWidth}×${bounds.outHeight}")

            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
                inDither = false
                inSampleSize = 1
            }
            val decoded = BitmapFactory.decodeFile(file.absolutePath, options)
                ?: return ElevationRead(null, "PNG тайла $x/$y прошёл проверку, но декодирование не удалось")
            bitmap = decoded
            if (decoded.width != 256 || decoded.height != 256)
                return ElevationRead(null, "После декодирования размер тайла $x/$y: ${decoded.width}×${decoded.height}")

            val n = 1 shl demZoom
            val xf = (lon + 180.0) / 360.0 * n
            val latRad = Math.toRadians(lat.coerceIn(-85.05112878, 85.05112878))
            val yf = (1.0 - kotlin.math.ln(kotlin.math.tan(latRad) + 1.0 / kotlin.math.cos(latRad)) / Math.PI) / 2.0 * n
            val px = (((xf - x) * 256.0).toInt()).coerceIn(0, 255)
            val py = (((yf - y) * 256.0).toInt()).coerceIn(0, 255)
            val color = decoded.getPixel(px, py)
            if (android.graphics.Color.alpha(color) == 0)
                return ElevationRead(null, "В пикселе $px/$py тайла $x/$y нет высотных данных")
            val r = android.graphics.Color.red(color)
            val g = android.graphics.Color.green(color)
            val b = android.graphics.Color.blue(color)
            val elevation = (r * 256.0 + g + b / 256.0) - 32768.0
            if (!elevation.isFinite() || elevation <= -12000.0)
                return ElevationRead(null, "В пикселе тайла $x/$y отмечено отсутствие высоты")
            return ElevationRead(elevation, "DEM OK • тайл $x/$y • пиксель $px/$py")
        } catch (oom: OutOfMemoryError) {
            return ElevationRead(null, "Android не смог выделить память для изображения DEM")
        } catch (e: Exception) {
            return ElevationRead(null, "Ошибка файла DEM: ${e.javaClass.simpleName}: ${e.message ?: "без подробностей"}")
        } finally {
            try { bitmap?.recycle() } catch (_: Exception) {}
        }
    }

    private data class DemCountry(val name: String, val south: Double, val west: Double, val north: Double, val east: Double)

    // Approximate country bounding boxes. The user selects a country by its familiar name;
    // coordinates remain internal and are never requested from the user.
    private val demCountries = listOf(
        DemCountry("Израиль", 29.4, 34.3, 33.4, 35.9),
        DemCountry("Италия", 35.3, 6.5, 47.2, 18.8),
        DemCountry("Франция", 41.3, -5.2, 51.2, 9.7),
        DemCountry("Норвегия", 57.9, 4.0, 71.2, 31.2),
        DemCountry("Швейцария", 45.8, 5.9, 47.9, 10.6),
        DemCountry("Австрия", 46.4, 9.5, 49.1, 17.2),
        DemCountry("Германия", 47.2, 5.8, 55.1, 15.1),
        DemCountry("Польша", 49.0, 14.1, 54.9, 24.2),
        DemCountry("Чехия", 48.5, 12.1, 51.1, 18.9),
        DemCountry("Словакия", 47.7, 16.8, 49.6, 22.6),
        DemCountry("Словения", 45.4, 13.4, 46.9, 16.6),
        DemCountry("Хорватия", 42.3, 13.4, 46.6, 19.5),
        DemCountry("Венгрия", 45.7, 16.1, 48.6, 22.9),
        DemCountry("Румыния", 43.6, 20.2, 48.3, 29.8),
        DemCountry("Болгария", 41.2, 22.3, 44.3, 28.6),
        DemCountry("Греция", 34.8, 19.3, 41.8, 29.7),
        DemCountry("Испания", 27.6, -18.2, 43.8, 4.4),
        DemCountry("Португалия", 36.9, -9.6, 42.2, -6.2),
        DemCountry("Великобритания", 49.9, -8.2, 59.5, 2.0),
        DemCountry("Ирландия", 51.4, -10.7, 55.5, -5.4),
        DemCountry("Нидерланды", 50.7, 3.2, 53.7, 7.3),
        DemCountry("Бельгия", 49.5, 2.5, 51.6, 6.4),
        DemCountry("Дания", 54.5, 8.0, 57.8, 15.2),
        DemCountry("Швеция", 55.3, 10.9, 69.1, 24.2),
        DemCountry("Финляндия", 59.8, 20.5, 70.1, 31.6),
        DemCountry("Исландия", 63.3, -24.5, 66.6, -13.3),
        DemCountry("Турция", 35.8, 25.7, 42.1, 44.8),
        DemCountry("Грузия", 41.0, 40.0, 43.6, 46.8),
        DemCountry("Армения", 38.8, 43.4, 41.3, 46.6),
        DemCountry("Азербайджан", 38.4, 44.8, 41.9, 51.0),
        DemCountry("Кипр", 34.5, 32.2, 35.7, 34.7),
        DemCountry("Иордания", 29.2, 34.9, 33.4, 39.3),
        DemCountry("Египет", 22.0, 24.7, 31.7, 36.9),
        DemCountry("Марокко", 27.6, -13.2, 35.9, -1.0),
        DemCountry("США", 24.4, -125.0, 49.5, -66.9),
        DemCountry("Канада", 41.7, -141.0, 83.1, -52.6),
        DemCountry("Мексика", 14.5, -118.4, 32.7, -86.7),
        DemCountry("Бразилия", -33.8, -73.9, 5.3, -34.8),
        DemCountry("Аргентина", -55.1, -73.6, -21.8, -53.6),
        DemCountry("Чили", -55.9, -75.7, -17.5, -66.4),
        DemCountry("Япония", 24.0, 122.9, 45.6, 153.0),
        DemCountry("Южная Корея", 33.1, 124.6, 38.6, 131.9),
        DemCountry("Китай", 18.1, 73.5, 53.6, 134.8),
        DemCountry("Таиланд", 5.6, 97.3, 20.5, 105.7),
        DemCountry("Вьетнам", 8.2, 102.1, 23.4, 109.5),
        DemCountry("Индия", 6.7, 68.1, 35.5, 97.4),
        DemCountry("Непал", 26.3, 80.0, 30.5, 88.2),
        DemCountry("Австралия", -43.7, 113.1, -10.0, 153.7),
        DemCountry("Новая Зеландия", -47.4, 166.4, -34.0, 178.6)
    )

    private fun showOfflineDemDialog() {
        val options = arrayOf("Выбрать страну", "Управление загруженными данными")
        android.app.AlertDialog.Builder(this)
            .setTitle("Офлайн-модели высот")
            .setItems(options) { _, which ->
                if (which == 0) showCountryPicker() else showDownloadedDemFiles()
            }.setNegativeButton("Закрыть", null).show()
    }

    private fun showCountryPicker() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }
        val search = EditText(this).apply {
            hint = "Поиск страны…"
            setSingleLine(true)
        }
        val list = ListView(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, demCountries.map { it.name })
        list.adapter = adapter
        layout.addView(search)
        layout.addView(list, LinearLayout.LayoutParams(-1, dp(360)))
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Выберите страну")
            .setView(layout)
            .setNegativeButton("Закрыть", null)
            .create()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter.filter(s)
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        list.setOnItemClickListener { _, _, position, _ ->
            val selectedName = adapter.getItem(position) ?: return@setOnItemClickListener
            val country = demCountries.firstOrNull { it.name == selectedName } ?: return@setOnItemClickListener
            dialog.dismiss()
            confirmDemDownload(country.name, country.south, country.west, country.north, country.east)
        }
        dialog.show()
    }

    private fun confirmDemDownload(name: String, south: Double, west: Double, north: Double, east: Double) {
        val sw=tileXY(south, west, demZoom); val ne=tileXY(north, east, demZoom)
        val minX=minOf(sw.first, ne.first); val maxX=maxOf(sw.first, ne.first)
        val minY=minOf(sw.second, ne.second); val maxY=maxOf(sw.second, ne.second)
        val count=(maxX-minX+1)*(maxY-minY+1)
        val estimateMb=count*25/1024.0
        val sizeWarning = if (count > 50000) "\n\nВНИМАНИЕ: область очень большая. Загрузка может занять много времени и потребовать десятки гигабайт памяти. Для такой страны лучше выбрать меньшую область." else ""
        android.app.AlertDialog.Builder(this).setTitle("Скачать: $name")
            .setMessage("""Будет загружено до $count фрагментов модели высот.
Предварительная оценка объёма: около ${String.format(Locale.getDefault(), "%.0f", estimateMb)} МБ. Фактический размер может отличаться.
Уровень детализации: zoom $demZoom.
Границы страны охватываются прямоугольником, поэтому часть тайлов может приходиться на море и соседние территории.
Источник: глобальная модель Terrain Tiles (AWS).$sizeWarning""")
            .setPositiveButton("Скачать") { _, _ -> downloadDemTiles(minX,minY,maxX,maxY,name) }
            .setNegativeButton("Отмена", null).show()
    }

    private fun downloadDemTiles(minX:Int,minY:Int,maxX:Int,maxY:Int,name:String) {
        if (!demDownloading.compareAndSet(false,true)) return
        val total=(maxX-minX+1)*(maxY-minY+1)
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,20,32,8) }
        demProgressText=TextView(this).apply { text="Запуск фоновой загрузки…" }
        demProgressBar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=total.coerceAtLeast(1); progress=0 }
        layout.addView(demProgressText); layout.addView(demProgressBar)
        demProgressDialog=android.app.AlertDialog.Builder(this).setTitle("Загрузка модели: $name").setView(layout)
            .setNegativeButton("Свернуть", null).create()
        demProgressDialog?.setCanceledOnTouchOutside(false)
        demProgressDialog?.setCancelable(false)
        demProgressDialog?.show()
        demProgressDialog?.getButton(android.app.AlertDialog.BUTTON_NEGATIVE)?.setOnClickListener { demProgressDialog?.dismiss() }
        val intent = Intent(this, DemDownloadService::class.java).apply {
            putExtra("minX", minX); putExtra("minY", minY); putExtra("maxX", maxX); putExtra("maxY", maxY); putExtra("name", name)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            demDownloading.set(false)
            demProgressText?.text = "Не удалось запустить фоновую загрузку: ${e.message}"
        }
    }

    private fun showDownloadedDemFiles() {
        val files = demDir().listFiles()?.filter { it.extension == "png" } ?: emptyList()
        val regions = getSharedPreferences("offline_dem", Context.MODE_PRIVATE).getStringSet("regions", emptySet())?.toList()?.sorted().orEmpty()
        val regionText = if (regions.isEmpty()) "Названия загруженных стран пока не сохранены." else "Загружено: ${regions.joinToString(", ")}"
        android.app.AlertDialog.Builder(this).setTitle("Офлайн-данные")
            .setMessage("""$regionText

Сохранено фрагментов модели: ${files.size}
Занято: ${files.sumOf { it.length() } / (1024*1024)} МБ

Удаление всех фрагментов освободит память телефона.""")
            .setPositiveButton("Удалить всё") { _, _ ->
                files.forEach { it.delete() }
                getSharedPreferences("offline_dem", Context.MODE_PRIVATE).edit().remove("regions").apply()
                terrainAltitude=null; terrain.text="Нет офлайн-данных"
                Toast.makeText(this,"Офлайн-данные удалены",Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null).show()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            val rotationMatrix = FloatArray(9)
            val orientation = FloatArray(3)
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientation)
            val degrees = ((Math.toDegrees(orientation[0].toDouble()).toInt() + 360) % 360)
            val directions = arrayOf("С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ")
            val direction = directions[((degrees + 22) / 45) % 8]
            compassView.text = String.format(Locale.getDefault(), "Телефон направлен: %s • %d°", direction, degrees)
            compassDial.setHeading(degrees.toFloat())
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) { super.onRequestPermissionsResult(r,p,g); if(r==requestCode) { if(g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED) startGps() else status.text="Разрешите доступ к местоположению" } }
    override fun onProviderEnabled(p:String) { if(p==LocationManager.GPS_PROVIDER) startGps() }
    override fun onProviderDisabled(p:String) { if(p==LocationManager.GPS_PROVIDER) status.text="GPS отключён" }
    override fun onStatusChanged(p:String?,s:Int,e:Bundle?) {}
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(DemDownloadService.ACTION_PROGRESS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(demReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(demReceiver, filter)
    }
    override fun onStop() {
        try { unregisterReceiver(demReceiver) } catch (_: Exception) {}
        super.onStop()
    }
    override fun onPause() {
        super.onPause()
        lm.removeUpdates(this)
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
    }
    override fun onResume() {
        super.onResume()
        if (::sensorManager.isInitialized) {
            rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        }
        if(::lm.isInitialized && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) startGps()
    }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
