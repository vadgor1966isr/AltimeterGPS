package com.example.altimetergps

/**
 * Geographic catalogue used by the regional download centre.
 *
 * Region bounds are conservative selection envelopes, not administrative polygons.
 * They are intentionally labelled as envelopes so the app never claims polygon-level
 * clipping until the official ISTAT geometry dataset is bundled and evaluated.
 */
data class GeoRegion(
    val country: String,
    val name: String,
    val south: Double,
    val west: Double,
    val north: Double,
    val east: Double,
    val mapsforgeZone: String
)

object RegionCatalog {
    // Bounding envelopes for Italy's 20 administrative regions.
    // The corresponding Mapsforge source is divided into five published zones.
    val italy: List<GeoRegion> = listOf(
        GeoRegion("Италия","Валле-д’Аоста",45.45,6.80,46.02,7.95,"nord-ovest"),
        GeoRegion("Италия","Пьемонт",44.05,6.60,46.47,9.20,"nord-ovest"),
        GeoRegion("Италия","Лигурия",43.78,7.50,44.68,10.10,"nord-ovest"),
        GeoRegion("Италия","Ломбардия",44.68,8.40,46.65,11.45,"nord-ovest"),
        GeoRegion("Италия","Трентино — Альто-Адидже",45.67,10.38,47.10,12.48,"nord-est"),
        GeoRegion("Италия","Венето",44.79,10.62,46.68,13.10,"nord-est"),
        GeoRegion("Италия","Фриули — Венеция-Джулия",45.58,12.32,46.65,13.95,"nord-est"),
        GeoRegion("Италия","Эмилия-Романья",43.72,9.20,45.15,12.75,"nord-est"),
        GeoRegion("Италия","Тоскана",42.23,9.68,44.48,12.38,"centro"),
        GeoRegion("Италия","Умбрия",42.35,11.90,43.62,13.25,"centro"),
        GeoRegion("Италия","Марке",42.68,12.35,43.98,13.95,"centro"),
        GeoRegion("Италия","Лацио",40.78,11.45,42.85,13.95,"centro"),
        GeoRegion("Италия","Абруццо",41.68,13.00,42.95,14.78,"sud"),
        GeoRegion("Италия","Молизе",41.36,14.05,42.10,15.15,"sud"),
        GeoRegion("Италия","Кампания",39.98,13.75,41.50,15.80,"sud"),
        GeoRegion("Италия","Апулия",39.78,14.90,42.25,18.55,"sud"),
        GeoRegion("Италия","Базиликата",39.88,15.50,40.85,16.90,"sud"),
        GeoRegion("Италия","Калабрия",37.90,15.60,40.15,17.25,"sud"),
        GeoRegion("Италия","Сицилия",35.48,11.90,38.35,15.70,"isole"),
        GeoRegion("Италия","Сардиния",38.80,8.10,41.30,9.85,"isole")
    )

    fun mapsforgeUrl(region: GeoRegion): String =
        "https://download.mapsforge.org/maps/v5/europe/italy/${region.mapsforgeZone}.map"

    /** BRouter segment grid: 5-degree cells named by southwest corner. */
    fun brouterSegments(region: GeoRegion, neighbourRing: Boolean = true): List<String> {
        val westCell = Math.floor(region.west / 5.0).toInt() * 5
        val eastCell = Math.floor(region.east / 5.0).toInt() * 5
        val southCell = Math.floor(region.south / 5.0).toInt() * 5
        val northCell = Math.floor(region.north / 5.0).toInt() * 5
        val pad = if (neighbourRing) 1 else 0
        val names = linkedSetOf<String>()
        for (lat in (southCell - pad * 5)..(northCell + pad * 5) step 5) {
            for (lon in (westCell - pad * 5)..(eastCell + pad * 5) step 5) {
                val ew = if (lon < 0) "W${-lon}" else "E$lon"
                val ns = if (lat < 0) "S${-lat}" else "N$lat"
                names.add("${ew}_${ns}.rd5")
            }
        }
        return names.toList()
    }

    /** Web-Mercator tile rectangle for the region envelope at a given zoom. */
    fun demTileBounds(region: GeoRegion, zoom: Int): IntArray {
        val n = 1 shl zoom
        fun x(lon: Double) = (((lon + 180.0) / 360.0) * n).toInt().coerceIn(0, n - 1)
        fun y(lat: Double): Int {
            val clamped = lat.coerceIn(-85.05112878, 85.05112878)
            val rad = Math.toRadians(clamped)
            return ((1.0 - kotlin.math.asinh(kotlin.math.tan(rad)) / Math.PI) / 2.0 * n)
                .toInt().coerceIn(0, n - 1)
        }
        return intArrayOf(x(region.west), y(region.north), x(region.east), y(region.south))
    }
}

/** Published Mapsforge sub-maps for Italy. The app reads the actual bounding box from each downloaded file. */
data class MapsforgeChoice(val country: String, val title: String, val fileName: String, val url: String)

object MapsforgeCatalog {
    val italy: List<MapsforgeChoice> = listOf(
        MapsforgeChoice("Италия", "Северо-Восток Италии", "nord-est.map", "https://download.mapsforge.org/maps/v5/europe/italy/nord-est.map"),
        MapsforgeChoice("Италия", "Северо-Запад Италии", "nord-ovest.map", "https://download.mapsforge.org/maps/v5/europe/italy/nord-ovest.map"),
        MapsforgeChoice("Италия", "Центральная Италия", "centro.map", "https://download.mapsforge.org/maps/v5/europe/italy/centro.map"),
        MapsforgeChoice("Италия", "Южная Италия", "sud.map", "https://download.mapsforge.org/maps/v5/europe/italy/sud.map"),
        MapsforgeChoice("Италия", "Сицилия и Сардиния", "isole.map", "https://download.mapsforge.org/maps/v5/europe/italy/isole.map")
    )

    /** BRouter filenames are the south-west corners of 5° x 5° cells. */
    fun brouterSegments(south: Double, west: Double, north: Double, east: Double): List<String> {
        require(south < north && west < east) { "Некорректные границы карты" }
        fun cellStart(value: Double): Int = kotlin.math.floor(value / 5.0).toInt() * 5
        val minLon = cellStart(west)
        val maxLon = cellStart(east - 1e-7)
        val minLat = cellStart(south)
        val maxLat = cellStart(north - 1e-7)
        val result = linkedSetOf<String>()
        for (lat in minLat..maxLat step 5) for (lon in minLon..maxLon step 5) {
            val ew = if (lon < 0) "W${-lon}" else "E$lon"
            val ns = if (lat < 0) "S${-lat}" else "N$lat"
            result += "${ew}_${ns}.rd5"
        }
        return result.toList()
    }

    /** Terrarium tiles covering the actual Mapsforge bounding rectangle at zoom 12. */
    fun demTileBounds(south: Double, west: Double, north: Double, east: Double, zoom: Int = 12): IntArray {
        val n = 1 shl zoom
        fun tileX(lon: Double) = (((lon + 180.0) / 360.0) * n).toInt().coerceIn(0, n - 1)
        fun tileY(lat: Double): Int {
            val clamped = lat.coerceIn(-85.05112878, 85.05112878)
            val rad = Math.toRadians(clamped)
            return ((1.0 - kotlin.math.asinh(kotlin.math.tan(rad)) / Math.PI) / 2.0 * n).toInt().coerceIn(0, n - 1)
        }
        return intArrayOf(tileX(west), tileY(north), tileX(east), tileY(south))
    }
}
