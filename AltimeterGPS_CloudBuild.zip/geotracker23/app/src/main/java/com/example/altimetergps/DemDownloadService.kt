package com.example.altimetergps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class DemDownloadService : Service() {
    companion object {
        const val ACTION_PROGRESS = "com.example.altimetergps.DEM_PROGRESS"
        private const val CHANNEL = "dem_download_channel"
        private const val NOTIFICATION_ID = 2212
        private const val MAX_TILE_BYTES = 4 * 1024 * 1024L
    }

    private val zoom = 12
    private lateinit var notificationManager: NotificationManager
    private val downloadActive = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Загрузка офлайн-модели высот", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        // A second tap/repeated service start must never launch another set of
        // workers against the same tile files and notification.
        if (!downloadActive.compareAndSet(false, true)) return START_NOT_STICKY

        val minX = intent.getIntExtra("minX", -1)
        val minY = intent.getIntExtra("minY", -1)
        val maxX = intent.getIntExtra("maxX", -1)
        val maxY = intent.getIntExtra("maxY", -1)
        val name = intent.getStringExtra("name") ?: "Страна"
        val worldTiles = 1 shl zoom
        if (minX < 0 || minY < 0 || maxX < minX || maxY < minY || maxX >= worldTiles || maxY >= worldTiles) {
            downloadActive.set(false)
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification("Подготовка: $name", 0, 1, true))
        Thread({ downloadSafely(minX, minY, maxX, maxY, name, startId) }, "DEM-download").start()
        return START_NOT_STICKY
    }

    private fun buildNotification(text: String, done: Int, total: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        builder.setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)
            .setContentTitle("GeoTracker — офлайн-модель")
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
        if (ongoing && total > 0) builder.setProgress(total, done.coerceIn(0, total), false)
        return builder.build()
    }

    private fun publish(done: Int, total: Int, saved: Int, missing: Int, errors: Int, name: String, complete: Boolean) {
        val line = if (complete) "$name: завершено — $saved сохранено, $missing нет данных, $errors ошибок"
        else "$name: $done из $total • сохранено $saved • ошибок $errors"
        notificationManager.notify(NOTIFICATION_ID, buildNotification(line, done, total, !complete))
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).apply {
            putExtra("done", done)
            putExtra("total", total)
            putExtra("saved", saved)
            putExtra("missing", missing)
            putExtra("errors", errors)
            putExtra("complete", complete)
        })
    }

    private fun downloadSafely(minX: Int, minY: Int, maxX: Int, maxY: Int, name: String, startId: Int) {
        val totalLong = (maxX.toLong() - minX + 1L) * (maxY.toLong() - minY + 1L)
        val total = totalLong.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val saved = AtomicInteger(0)
        val missing = AtomicInteger(0)
        val errors = AtomicInteger(0)
        val done = AtomicInteger(0)

        try {
            if (total <= 0 || totalLong > Int.MAX_VALUE) {
                errors.incrementAndGet()
                return
            }
            val dir = File(filesDir, "dem/$zoom")
            if (!dir.exists() && !dir.mkdirs()) {
                errors.incrementAndGet()
                return
            }

            val next = AtomicInteger(0)
            val width = maxX - minX + 1
            val workerCount = minOf(2, total)
            val workers = Executors.newFixedThreadPool(workerCount)
            val latch = CountDownLatch(workerCount)

            repeat(workerCount) { workerIndex ->
                workers.execute {
                    try {
                        while (!Thread.currentThread().isInterrupted) {
                            val index = next.getAndIncrement()
                            if (index >= total) break
                            val x = minX + index % width
                            val y = minY + index / width
                            val target = File(dir, "${x}_${y}.png")
                            try {
                                when {
                                    isValidPng(target) -> saved.incrementAndGet()
                                    else -> when (downloadTile(x, y, target, workerIndex)) {
                                        1 -> saved.incrementAndGet()
                                        0 -> missing.incrementAndGet()
                                        else -> errors.incrementAndGet()
                                    }
                                }
                            } catch (_: Exception) {
                                errors.incrementAndGet()
                            }
                            val current = done.incrementAndGet()
                            if (current % 10 == 0 || current == total) {
                                publish(current, total, saved.get(), missing.get(), errors.get(), name, false)
                            }
                        }
                    } finally {
                        latch.countDown()
                    }
                }
            }

            try {
                latch.await()
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                errors.incrementAndGet()
            } finally {
                workers.shutdownNow()
            }

            if (saved.get() > 0) {
                // Keep the durable copy in the user-selected region folder. The private
                // filesDir copy remains a working cache for fast bitmap decoding.
                try {
                    val external = RegionStorage.elevationZoomFolder(this, zoom)
                    val local = File(filesDir, "dem/$zoom").listFiles { f -> f.isFile && f.extension.equals("png", true) } ?: emptyArray()
                    local.forEach { RegionStorage.copyFileToDocumentFolder(this, it, external) }
                } catch (_: Exception) {}
                synchronized(DemDownloadService::class.java) {
                    val prefs = getSharedPreferences("offline_dem", Context.MODE_PRIVATE)
                    val regions = prefs.getStringSet("regions", emptySet())?.toMutableSet() ?: mutableSetOf()
                    regions.add(name)
                    prefs.edit().putStringSet("regions", regions).commit()
                }
            }
        } catch (_: Exception) {
            errors.incrementAndGet()
        } finally {
            // Always publish a terminal state and release the foreground service,
            // even if directory creation, preferences, or a worker fails.
            try {
                publish(done.get(), total, saved.get(), missing.get(), errors.get(), name, true)
            } catch (_: Exception) {
                try { notificationManager.cancel(NOTIFICATION_ID) } catch (_: Exception) {}
            }
            downloadActive.set(false)
            try { stopForeground(STOP_FOREGROUND_DETACH) } catch (_: Exception) {
                try { stopForeground(true) } catch (_: Exception) {}
            }
            stopSelf(startId)
        }
    }

    private fun isValidPng(file: File): Boolean {
        if (!file.exists() || file.length() !in 101L..MAX_TILE_BYTES) return false
        return try {
            file.inputStream().use { input ->
                val signature = ByteArray(8)
                input.read(signature) == 8 && signature.contentEquals(
                    byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
                )
            }
        } catch (_: Exception) { false }
    }

    private fun downloadTile(x: Int, y: Int, target: File, workerIndex: Int): Int {
        for (attempt in 0..2) {
            val temp = File(target.parentFile, "${target.name}.$workerIndex.$attempt.tmp")
            var connection: HttpURLConnection? = null
            try {
                connection = URL("https://s3.amazonaws.com/elevation-tiles-prod/terrarium/$zoom/$x/$y.png")
                    .openConnection() as HttpURLConnection
                connection.connectTimeout = 12000
                connection.readTimeout = 15000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "GeoTracker Android/3.4")
                connection.setRequestProperty("Accept", "image/png")
                when (val code = connection.responseCode) {
                    404 -> return 0
                    200 -> {
                        val declaredLength = connection.contentLengthLong
                        if (declaredLength > MAX_TILE_BYTES) return -1
                        connection.inputStream.use { input ->
                            FileOutputStream(temp).use { output ->
                                val buffer = ByteArray(8192)
                                var written = 0L
                                while (true) {
                                    val count = input.read(buffer)
                                    if (count < 0) break
                                    written += count
                                    if (written > MAX_TILE_BYTES) throw IllegalStateException("Tile too large")
                                    output.write(buffer, 0, count)
                                }
                            }
                        }
                        if (isValidPng(temp)) {
                            if (target.exists()) target.delete()
                            if (temp.renameTo(target)) return 1
                            if (isValidPng(target)) return 1
                        }
                        temp.delete()
                    }
                    in 500..599 -> if (attempt < 2) Thread.sleep(400L * (attempt + 1)) else return -1
                    else -> return -1
                }
            } catch (_: Exception) {
                temp.delete()
                if (attempt < 2) Thread.sleep(400L * (attempt + 1))
                else return -1
            } finally {
                connection?.disconnect()
            }
        }
        return -1
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
