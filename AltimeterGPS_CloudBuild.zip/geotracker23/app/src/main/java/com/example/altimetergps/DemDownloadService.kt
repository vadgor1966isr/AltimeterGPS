package com.example.altimetergps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class DemDownloadService : Service() {
    companion object {
        const val ACTION_PROGRESS = "com.example.altimetergps.DEM_PROGRESS"
        private const val CHANNEL = "dem_download_channel"
        private const val NOTIFICATION_ID = 2212
    }
    private val zoom = 12
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) notificationManager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Загрузка офлайн-модели высот", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(startId); return START_NOT_STICKY }
        val minX = intent.getIntExtra("minX", 0)
        val minY = intent.getIntExtra("minY", 0)
        val maxX = intent.getIntExtra("maxX", 0)
        val maxY = intent.getIntExtra("maxY", 0)
        val name = intent.getStringExtra("name") ?: "Страна"
        val total = ((maxX - minX + 1) * (maxY - minY + 1)).coerceAtLeast(0)
        startForeground(NOTIFICATION_ID, buildNotification("Подготовка: $name", 0, total, true))
        Thread { download(minX, minY, maxX, maxY, name, startId) }.start()
        return START_NOT_STICKY
    }

    private fun buildNotification(text: String, done: Int, total: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        builder.setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)
            .setContentTitle("GeoTracker — офлайн-модель")
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
        if (ongoing && total > 0) builder.setProgress(total, done.coerceAtMost(total), false)
        else if (ongoing) builder.setProgress(0, 0, true)
        return builder.build()
    }

    private fun publish(done: Int, total: Int, saved: Int, missing: Int, errors: Int, name: String, complete: Boolean) {
        val line = if (complete) "$name: завершено — $saved сохранено, $missing нет данных, $errors ошибок"
        else "$name: $done из $total • сохранено $saved • ошибок $errors"
        notificationManager.notify(NOTIFICATION_ID, buildNotification(line, done, total, !complete))
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).apply {
            putExtra("done", done); putExtra("total", total); putExtra("saved", saved)
            putExtra("missing", missing); putExtra("errors", errors); putExtra("complete", complete)
        })
    }

    private fun download(minX: Int, minY: Int, maxX: Int, maxY: Int, name: String, startId: Int) {
        val total = ((maxX - minX + 1) * (maxY - minY + 1)).coerceAtLeast(0)
        val dir = File(filesDir, "dem/$zoom").apply { mkdirs() }
        val next = AtomicInteger(0); val done = AtomicInteger(0); val saved = AtomicInteger(0)
        val missing = AtomicInteger(0); val errors = AtomicInteger(0)
        val width = maxX - minX + 1
        val workers = Executors.newFixedThreadPool(4)
        val latch = CountDownLatch(4)
        repeat(4) {
            workers.execute {
                try {
                    while (true) {
                        val index = next.getAndIncrement()
                        if (index >= total) break
                        val x = minX + index % width
                        val y = minY + index / width
                        val target = File(dir, "${x}_${y}.png")
                        if (target.exists() && target.length() > 100) saved.incrementAndGet()
                        else {
                            var ok = false; var absent = false
                            for (attempt in 0..2) {
                                val temp = File(dir, target.name + ".tmp")
                                var conn: HttpURLConnection? = null
                                try {
                                    conn = URL("https://s3.amazonaws.com/elevation-tiles-prod/terrarium/$zoom/$x/$y.png").openConnection() as HttpURLConnection
                                    conn.connectTimeout = 12000; conn.readTimeout = 15000; conn.instanceFollowRedirects = true
                                    conn.setRequestProperty("User-Agent", "GeoTracker Android/2.6")
                                    conn.setRequestProperty("Accept", "image/png")
                                    val code = conn.responseCode
                                    if (code == 404) { absent = true; break }
                                    if (code == 200) {
                                        conn.inputStream.use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } }
                                        val valid = temp.length() > 100 && temp.inputStream().use { input ->
                                            val sig = ByteArray(8)
                                            input.read(sig) == 8 && sig.contentEquals(byteArrayOf(0x89.toByte(),0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A))
                                        }
                                        if (valid && (temp.renameTo(target) || target.exists())) { ok = true; break }
                                        temp.delete()
                                    } else if (code in 500..599 && attempt < 2) Thread.sleep(500L * (attempt + 1)) else break
                                } catch (_: Exception) {
                                    temp.delete()
                                    if (attempt < 2) Thread.sleep(500L * (attempt + 1))
                                } finally { conn?.disconnect() }
                            }
                            when { ok -> saved.incrementAndGet(); absent -> missing.incrementAndGet(); else -> errors.incrementAndGet() }
                        }
                        val d = done.incrementAndGet()
                        if (d % 10 == 0 || d == total) publish(d,total,saved.get(),missing.get(),errors.get(),name,false)
                    }
                } finally { latch.countDown() }
            }
        }
        try { latch.await() } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        workers.shutdown()
        if (saved.get() > 0) {
            val prefs = getSharedPreferences("offline_dem", Context.MODE_PRIVATE)
            val regions = prefs.getStringSet("regions", emptySet())?.toMutableSet() ?: mutableSetOf()
            regions.add(name); prefs.edit().putStringSet("regions", regions).apply()
        }
        publish(done.get(), total, saved.get(), missing.get(), errors.get(), name, true)
        // Keep a completed notification, but remove the active foreground-service state.
        // Use the completed-download icon so Android no longer shows an active download.
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf(startId)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
