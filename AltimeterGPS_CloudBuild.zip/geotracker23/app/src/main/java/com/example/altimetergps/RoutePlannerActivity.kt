package com.example.altimetergps

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import btools.router.OsmNodeNamed
import btools.router.RoutingContext
import btools.router.RoutingEngine
import java.io.File
import java.util.HashMap
import java.util.Locale
import kotlin.concurrent.thread

/** Offline route planning with the embedded BRouter engine. Routing data (.rd5) is user supplied. */
class RoutePlannerActivity : Activity() {
    private lateinit var startLat: EditText
    private lateinit var startLon: EditText
    private lateinit var endLat: EditText
    private lateinit var endLon: EditText
    private lateinit var viaText: EditText
    private lateinit var status: TextView
    private lateinit var routeButton: Button
    private val importRequest = 5201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(20))
            setBackgroundColor(0xFF10243A.toInt())
        }
        fun label(s: String, size: Float = 15f) = TextView(this).apply {
            text = s; textSize = size; setTextColor(0xFFEAF2F7.toInt()); setPadding(0, dp(7), 0, dp(4))
        }
        fun field(hint: String): EditText = EditText(this).apply {
            this.hint = hint; textSize = 16f; setSingleLine(true)
            setTextColor(0xFF10243A.toInt()); setHintTextColor(0xFF667788.toInt())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setPadding(dp(10), dp(6), dp(10), dp(6))
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFB7D2E3.toInt())
        }
        root.addView(label("ПЛАНИРОВАНИЕ ПОХОДА", 21f).apply { gravity = Gravity.CENTER; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        root.addView(label("Маршрут строится офлайн по данным BRouter. Сначала импортируйте сегменты региона (.rd5)."))
        root.addView(Button(this).apply {
            text = "ЗАГРУЗИТЬ ДАННЫЕ BRouter ДЛЯ ДОЛОМИТОВ"
            setOnClickListener { showDolomitesSegmentDownload() }
        })
        root.addView(Button(this).apply {
            text = "ИМПОРТИРОВАТЬ ДАННЫЕ МАРШРУТИЗАЦИИ (.RD5)"
            setOnClickListener { chooseSegments() }
        })
        root.addView(label("НАЧАЛЬНАЯ ТОЧКА — широта, долгота"))
        startLat = field("Например, 46.5210"); startLon = field("Например, 12.1350")
        root.addView(startLat); root.addView(startLon)
        root.addView(label("ПРОМЕЖУТОЧНЫЕ ТОЧКИ — по одной паре lat,lon на строку"))
        viaText = EditText(this).apply {
            hint = "46.5300,12.1400\n46.5400,12.1500"; minLines = 2; gravity = Gravity.TOP
            textSize = 15f; setTextColor(0xFF10243A.toInt()); setHintTextColor(0xFF667788.toInt())
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(viaText, LinearLayout.LayoutParams(-1, dp(92)))
        root.addView(label("КОНЕЧНАЯ ТОЧКА — широта, долгота"))
        endLat = field("Например, 46.5500"); endLon = field("Например, 12.1700")
        root.addView(endLat); root.addView(endLon)
        root.addView(label("Профиль: горный пеший туризм (hiking-mountain, ограничение SAC T2)."))
        routeButton = Button(this).apply {
            text = "ПОСТРОИТЬ МАРШРУТ ОФЛАЙН"
            setOnClickListener { calculateRoute() }
        }
        root.addView(routeButton)
        status = label("Подготовка профиля BRouter…", 14f)
        root.addView(status)
        root.addView(Button(this).apply { text = "НАЗАД"; setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(root) })
        try { ensureProfileFiles() } catch (e: Exception) { status.text = "Ошибка подготовки профиля: ${e.message}" }
        refreshSegmentStatus()
    }

    // BRouter segments are 5x5 degree tiles. The Dolomites (around 11-12E,
    // 46-47N) are covered by E10_N45.rd5. Adjacent tiles are optional.
    private fun showDolomitesSegmentDownload() {
        val labels = arrayOf(
            "E10_N45.rd5 — центральные Доломиты (обязательно)",
            "E5_N45.rd5 — западнее",
            "E15_N45.rd5 — восточнее",
            "E10_N40.rd5 — южнее",
            "E5_N40.rd5 — юго-запад",
            "E15_N40.rd5 — юго-восток"
        )
        val names = arrayOf("E10_N45.rd5", "E5_N45.rd5", "E15_N45.rd5", "E10_N40.rd5", "E5_N40.rd5", "E15_N40.rd5")
        val checked = BooleanArray(labels.size) { it == 0 }
        AlertDialog.Builder(this)
            .setTitle("Данные маршрутизации — Доломиты")
            .setMultiChoiceItems(labels, checked) { _, which, value -> checked[which] = value }
            .setPositiveButton("Загрузить") { _, _ ->
                val selected = names.indices.filter { checked[it] }.map { names[it] }
                if (selected.isNotEmpty()) downloadSegments(selected)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun downloadSegments(names: List<String>) {
        routeButton.isEnabled = false
        status.text = "Загрузка данных BRouter…"
        thread(name = "BRouterSegmentDownload") {
            var ok = 0
            val failures = mutableListOf<String>()
            val dir = segmentDir()
            for (name in names) {
                val target = File(dir, name)
                if (target.exists() && target.length() > 1024L) { ok++; continue }
                val temp = File(dir, "$name.download")
                var connection: java.net.HttpURLConnection? = null
                try {
                    connection = (java.net.URL("https://brouter.de/brouter/segments4/$name").openConnection() as java.net.HttpURLConnection).apply {
                        connectTimeout = 20000
                        readTimeout = 60000
                        requestMethod = "GET"
                        setRequestProperty("User-Agent", "GeoTracker/3.16")
                    }
                    val code = connection.responseCode
                    if (code != 200) throw IllegalStateException("HTTP $code")
                    connection.inputStream.use { input ->
                        temp.outputStream().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                            }
                        }
                    }
                    if (temp.length() < 1024L) throw IllegalStateException("файл слишком мал")
                    if (target.exists()) target.delete()
                    if (!temp.renameTo(target)) throw IllegalStateException("не удалось сохранить файл")
                    ok++
                } catch (e: Exception) {
                    temp.delete()
                    failures.add("$name: ${e.message ?: "ошибка"}")
                } finally {
                    connection?.disconnect()
                }
            }
            runOnUiThread {
                routeButton.isEnabled = true
                status.text = buildString {
                    append("Загрузка сегментов завершена: $ok из ${names.size}.\\n")
                    if (failures.isNotEmpty()) append("Ошибки: ${failures.joinToString("; ")}\\n")
                    append(segmentSummary())
                    append("\\nСегменты .rd5 — отдельные данные маршрутизации, не сама карта.")
                }
            }
        }
    }

    private fun chooseSegments() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_TITLE, "Выберите файлы BRouter .rd5")
        }
        startActivityForResult(intent, importRequest)
    }

    @Deprecated("Storage Access Framework result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != importRequest || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        val unique = uris.distinct()
        if (unique.isEmpty()) return
        status.text = "Импорт данных маршрутизации…"
        thread(name = "BRouterSegmentImport") {
            val dir = segmentDir()
            var copied = 0
            var skipped = 0
            for (uri in unique) {
                val name = queryDisplayName(uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "segment.rd5"
                if (!name.endsWith(".rd5", true)) { skipped++; continue }
                try {
                    val input = contentResolver.openInputStream(uri)
                    if (input == null) { skipped++; continue }
                    input.use { source ->
                        File(dir, name).outputStream().use { output -> source.copyTo(output) }
                    }
                    copied++
                } catch (_: Exception) { skipped++ }
            }
            runOnUiThread {
                status.text = "Импортировано сегментов: $copied. Пропущено: $skipped.\n${segmentSummary()}"
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun segmentDir(): File = File(filesDir, "brouter/segments4").apply { mkdirs() }

    private fun ensureProfileFiles() {
        val dir = File(filesDir, "brouter/profiles2").apply { mkdirs() }
        listOf("hiking-mountain.brf", "lookups.dat").forEach { name ->
            val target = File(dir, name)
            if (!target.exists() || target.length() == 0L) {
                assets.open("brouter/profiles2/$name").use { input -> target.outputStream().use { input.copyTo(it) } }
            }
        }
    }

    private fun refreshSegmentStatus() {
        val files = segmentDir().listFiles { f -> f.isFile && f.name.endsWith(".rd5", true) } ?: emptyArray()
        status.text = "Профиль горного пешего туризма готов.\n${files.size} файлов .rd5 • ${segmentSummary()}"
    }

    private fun segmentSummary(): String {
        val files = segmentDir().listFiles { f -> f.isFile && f.name.endsWith(".rd5", true) } ?: emptyArray()
        val bytes = files.sumOf { it.length() }
        return String.format(Locale.getDefault(), "Данные маршрутизации: %d сегм. • %.1f МБ", files.size, bytes / 1048576.0)
    }

    private fun calculateRoute() {
        val waypoints = try { parseWaypoints() } catch (e: Exception) {
            status.text = "Проверьте координаты: ${e.message}"; return
        }
        val segments = segmentDir().listFiles { f -> f.isFile && f.name.endsWith(".rd5", true) } ?: emptyArray()
        if (segments.isEmpty()) {
            status.text = "Нет данных .rd5. Импортируйте сегменты для региона похода. Карта .map и DEM не заменяют данные маршрутизации."
            return
        }
        routeButton.isEnabled = false
        status.text = "BRouter строит маршрут…"
        thread(name = "BRouterRouteCalculation") {
            try {
                ensureProfileFiles()
                val profile = File(filesDir, "brouter/profiles2/hiking-mountain.brf")
                val rc = RoutingContext().apply {
                    localFunction = profile.absolutePath
                    keyValues = HashMap()
                    memoryclass = 64
                    outputFormat = "gpx"
                }
                val outDir = File(filesDir, "routes").apply { mkdirs() }
                val outBase = File(outDir, "route").absolutePath
                val engine = RoutingEngine(outBase, null, segmentDir(), waypoints, rc)
                engine.doRun(0)
                val error = engine.getErrorMessage()
                val gpx = File(outDir, "route0.gpx")
                runOnUiThread {
                    routeButton.isEnabled = true
                    if (!error.isNullOrBlank() || !gpx.exists()) {
                        status.text = "Маршрут не построен: ${error ?: "BRouter не создал GPX"}\nПроверьте наличие всех .rd5 для начальной, конечной и промежуточных точек."
                    } else {
                        val km = engine.getDistance() / 1000.0
                        status.text = String.format(Locale.getDefault(),
                            "Маршрут построен!\nРасстояние: %.2f км\nНабор высоты: %d м\nВремя по профилю: %s\nGPX: %s",
                            km, engine.getAscend(), engine.getTime(), gpx.absolutePath)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { routeButton.isEnabled = true; status.text = "Ошибка маршрутизации: ${e.message}" }
            }
        }
    }

    private fun parseWaypoints(): MutableList<OsmNodeNamed> {
        val points = mutableListOf<Pair<Double, Double>>()
        fun add(latText: String, lonText: String) {
            val lat = latText.trim().replace(',', '.').toDouble()
            val lon = lonText.trim().replace(',', '.').toDouble()
            require(lat in -90.0..90.0 && lon in -180.0..180.0) { "широта/долгота вне диапазона" }
            points.add(lat to lon)
        }
        add(startLat.text.toString(), startLon.text.toString())
        viaText.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
            val p = line.split(',', ';', ' ', '\t').filter { it.isNotBlank() }
            require(p.size == 2) { "промежуточная точка должна быть в формате lat,lon" }
            add(p[0], p[1])
        }
        add(endLat.text.toString(), endLon.text.toString())
        require(points.size >= 2) { "нужны начало и конец" }
        return points.mapIndexed { i, p ->
            OsmNodeNamed().apply {
                name = if (i == 0) "start" else if (i == points.lastIndex) "finish" else "via_$i"
                ilon = 180000000 + (p.second * 1000000.0 + 0.5).toInt()
                ilat = 90000000 + (p.first * 1000000.0 + 0.5).toInt()
            }
        }.toMutableList()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
