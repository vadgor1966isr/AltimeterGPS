package com.example.altimetergps

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable
import btools.router.OsmNodeNamed
import btools.router.RoutingContext
import btools.router.RoutingEngine
import java.io.File
import java.util.HashMap
import java.util.Locale
import kotlin.concurrent.thread

/** Offline route planning with the embedded BRouter engine. Routing data (.rd5) is user supplied. */
class RoutePlannerActivity : Activity() {
    private lateinit var startLat: EditText
    private lateinit var startLon: EditText
    private lateinit var endLat: EditText
    private lateinit var endLon: EditText
    private lateinit var viaText: EditText
    private lateinit var status: TextView
    private lateinit var routeButton: Button
    private lateinit var exportButton: Button
    private lateinit var showRouteButton: Button
    private var lastGpxFile: File? = null
    private val importRequest = 5201
    private val exportRequest = 5202
    private val storageRequest = 5203

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(20))
            setBackgroundColor(0xFF10243A.toInt())
        }
        fun label(s: String, size: Float = 15f) = TextView(this).apply {
            text = s; textSize = size; setTextColor(0xFFEAF2F7.toInt()); setPadding(0, dp(7), 0, dp(4))
        }
        fun field(hint: String): EditText = EditText(this).apply {
            this.hint = hint; textSize = 16f; setSingleLine(true)
            // Light field on dark screen: entered digits and cursor remain clearly visible.
            setTextColor(0xFF10243A.toInt()); setHintTextColor(0xFF718096.toInt())
            setHighlightColor(0x663B82F6)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = GradientDrawable().apply {
                setColor(0xFFF7FAFC.toInt())
                cornerRadius = dp(7).toFloat()
                setStroke(dp(1), 0xFF9FB8CA.toInt())
            }
            backgroundTintList = null
        }
        root.addView(label("ПЛАНИРОВАНИЕ ПОХОДА", 21f).apply { gravity = Gravity.CENTER; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        root.addView(label("Маршрут строится офлайн по данным BRouter. Сначала выберите внешнее хранилище региона и добавьте сегменты (.rd5)."))
        root.addView(Button(this).apply {
            text = "НАСТРОИТЬ ВНЕШНЕЕ ХРАНИЛИЩЕ РЕГИОНА"
            setOnClickListener { chooseRegionStorage() }
        })
        root.addView(Button(this).apply {
            text = "ЗАГРУЗИТЬ ДАННЫЕ BRouter ДЛЯ ДОЛОМИТОВ"
            setOnClickListener { showDolomitesSegmentDownload() }
        })
        root.addView(Button(this).apply {
            text = "СТАТУС ЗАГРУЗКИ RD5"
            setOnClickListener { showSegmentDownloadStatus() }
        })
        root.addView(Button(this).apply {
            text = "ИМПОРТИРОВАТЬ ДАННЫЕ МАРШРУТИЗАЦИИ (.RD5)"
            setOnClickListener { chooseSegments() }
        })
        root.addView(label("НАЧАЛЬНАЯ ТОЧКА — широта, долгота"))
        startLat = field("Например, 46.5210"); startLon = field("Например, 12.1350")
        root.addView(startLat); root.addView(startLon)
        root.addView(label("ПРОМЕЖУТОЧНЫЕ ТОЧКИ — по одной паре lat,lon на строку"))
        viaText = EditText(this).apply {
            hint = "46.5300,12.1400\n46.5400,12.1500"; minLines = 2; gravity = Gravity.TOP
            textSize = 15f; setTextColor(0xFF10243A.toInt()); setHintTextColor(0xFF718096.toInt())
            setHighlightColor(0x663B82F6)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(0xFFF7FAFC.toInt())
                cornerRadius = dp(7).toFloat()
                setStroke(dp(1), 0xFF9FB8CA.toInt())
            }
            backgroundTintList = null
        }
        root.addView(viaText, LinearLayout.LayoutParams(-1, dp(92)))
        root.addView(label("КОНЕЧНАЯ ТОЧКА — широта, долгота"))
        endLat = field("Например, 46.5500"); endLon = field("Например, 12.1700")
        root.addView(endLat); root.addView(endLon)
        root.addView(label("Профиль: горный пеший туризм (hiking-mountain, ограничение SAC T2)."))
        routeButton = Button(this).apply {
            text = "ПОСТРОИТЬ МАРШРУТ ОФЛАЙН"
            setOnClickListener { calculateRoute() }
        }
        root.addView(routeButton)
        exportButton = Button(this).apply {
            text = "ЭКСПОРТИРОВАТЬ GPX"
            isEnabled = false
            setOnClickListener { exportLastGpx() }
        }
        root.addView(exportButton)
        showRouteButton = Button(this).apply {
            text = "ПОКАЗАТЬ МАРШРУТ НА ОФЛАЙН-КАРТЕ"
            isEnabled = false
            setOnClickListener { showLastRouteOnMap() }
        }
        root.addView(showRouteButton)
        status = label("Подготовка профиля BRouter…", 14f)
        root.addView(status)
        root.addView(Button(this).apply { text = "НАЗАД"; setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(root) })
        try { ensureProfileFiles() } catch (e: Exception) { status.text = "Ошибка подготовки профиля: ${e.message}" }
        restoreRegionSegments()
        refreshSegmentStatus()
    }

    private fun chooseRegionStorage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        startActivityForResult(intent, storageRequest)
    }

    private fun askRegionName(treeUri: Uri) {
        val input = EditText(this).apply { setSingleLine(true); setText(RegionStorage.regionName(this@RoutePlannerActivity)); hint = "Например, Dolomites" }
        AlertDialog.Builder(this).setTitle("Название региона")
            .setMessage("GeoTracker создаст папки Maps, Routing, Elevation и Routes.")
            .setView(input).setPositiveButton("Создать") { _, _ ->
                try {
                    val region = RegionStorage.configure(this, treeUri, input.text.toString())
                    status.text = "Хранилище региона ${region.name} создано. Перенос существующих данных…"
                    Toast.makeText(this, "Хранилище региона создано", Toast.LENGTH_LONG).show()
                    thread(name = "GeoTrackerRegionMigration") {
                        var routingCopied = 0
                        var elevationCopied = 0
                        var routesCopied = 0
                        val localRouting = segmentDir().listFiles { f -> f.isFile && f.name.endsWith(".rd5", true) } ?: emptyArray()
                        localRouting.forEach { if (RegionStorage.copyFileToFolder(this@RoutePlannerActivity, it, "Routing")) routingCopied++ }
                        val localDem = File(filesDir, "dem/12").listFiles { f -> f.isFile && f.extension.equals("png", true) } ?: emptyArray()
                        val demFolder = RegionStorage.elevationZoomFolder(this@RoutePlannerActivity, 12)
                        localDem.forEach { if (RegionStorage.copyFileToDocumentFolder(this@RoutePlannerActivity, it, demFolder)) elevationCopied++ }
                        val localRoutes = File(filesDir, "routes").listFiles { f -> f.isFile && f.extension.equals("gpx", true) } ?: emptyArray()
                        localRoutes.forEach { if (RegionStorage.copyFileToFolder(this@RoutePlannerActivity, it, "Routes")) routesCopied++ }
                        restoreRegionSegments()
                        runOnUiThread {
                            status.text = "Внешнее хранилище настроено: ${region.name}.\nПеренесено: RD5 $routingCopied, DEM $elevationCopied, GPX $routesCopied.\n${segmentSummary()}"
                        }
                    }
                } catch (e: Exception) { status.text = "Не удалось настроить хранилище: ${e.message}" }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun restoreRegionSegments() {
        try {
            val folder = RegionStorage.regionFolder(this, "Routing") ?: return
            val targetDir = segmentDir()
            folder.listFiles().filter { it.isFile && it.name?.endsWith(".rd5", true) == true }.forEach { doc ->
                val target = File(targetDir, doc.name ?: return@forEach)
                if (!target.exists() || target.length() != doc.length()) RegionStorage.copyDocumentToFile(this, doc, target)
            }
        } catch (_: Exception) {}
    }

    // BRouter segments are 5x5 degree tiles. The Dolomites (around 11-12E,
    // 46-47N) are covered by E10_N45.rd5. Adjacent tiles are optional.
    private fun showDolomitesSegmentDownload() {
        val labels = arrayOf(
            "E10_N45.rd5 — центральные Доломиты (обязательно)",
            "E5_N45.rd5 — западнее",
            "E15_N45.rd5 — восточнее",
            "E10_N40.rd5 — южнее",
            "E5_N40.rd5 — юго-запад",
            "E15_N40.rd5 — юго-восток"
        )
        val names = arrayOf("E10_N45.rd5", "E5_N45.rd5", "E15_N45.rd5", "E10_N40.rd5", "E5_N40.rd5", "E15_N40.rd5")
        val checked = BooleanArray(labels.size) { it == 0 }
        AlertDialog.Builder(this)
            .setTitle("Данные маршрутизации — Доломиты")
            .setMultiChoiceItems(labels, checked) { _, which, value -> checked[which] = value }
            .setPositiveButton("Загрузить") { _, _ ->
                val selected = names.indices.filter { checked[it] }.map { names[it] }
                if (selected.isNotEmpty()) downloadSegments(selected)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun downloadSegments(names: List<String>) {
        val currentState = getSharedPreferences("brouter_download", MODE_PRIVATE).getString("state", "")
        if (currentState == "running") {
            Toast.makeText(this, "Загрузка RD5 уже выполняется. Сначала завершите её или отмените.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, BRouterSegmentDownloadService::class.java).apply {
            action = BRouterSegmentDownloadService.ACTION_START
            putStringArrayListExtra(BRouterSegmentDownloadService.EXTRA_NAMES, ArrayList(names))
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            status.text = "Загрузка RD5 выполняется в фоне. Её можно скрыть или закрыть экран — прогресс останется в уведомлении."
            Toast.makeText(this, "Загрузка RD5 началась. Статус доступен в уведомлениях и в кнопке «Статус загрузки RD5».", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.text = "Не удалось запустить загрузку: ${e.message}"
        }
    }

    private fun showSegmentDownloadStatus() {
        val p = getSharedPreferences("brouter_download", MODE_PRIVATE)
        val state = p.getString("state", "not_started") ?: "not_started"
        val message = p.getString("message", "Загрузка ещё не запускалась") ?: ""
        val current = p.getString("current", "") ?: ""
        val received = p.getLong("received", 0L)
        val total = p.getLong("total", -1L)
        val done = p.getInt("done", 0)
        val count = p.getInt("count", 0)
        val detail = buildString {
            append(message)
            if (state == "running") {
                append("\\nФайл: ").append(current)
                append("\\nОбработано файлов: ").append(done).append(" из ").append(count)
                append("\\nПолучено: ").append(String.format(Locale.US, "%.1f", received / 1048576.0)).append(" МБ")
                if (total > 0) append(" из ").append(String.format(Locale.US, "%.1f", total / 1048576.0)).append(" МБ")
            } else if (state == "completed" || state == "partial" || state == "failed" || state == "cancelled") {
                append("\\nСостояние: ").append(state)
                val error = p.getString("error", "") ?: ""
                if (error.isNotBlank()) append("\\nПодробности: ").append(error)
            }
        }
        val dialog = AlertDialog.Builder(this).setTitle("Статус загрузки RD5")
            .setMessage(detail)
            .setPositiveButton(if (state == "running") "Отменить загрузку" else "Обновить") { _, _ ->
                if (state == "running") {
                    val cancel = Intent(this, BRouterSegmentDownloadService::class.java).apply {
                        action = BRouterSegmentDownloadService.ACTION_CANCEL
                    }
                    startService(cancel)
                    Toast.makeText(this, "Запрошена отмена загрузки RD5…", Toast.LENGTH_SHORT).show()
                } else showSegmentDownloadStatus()
            }
            .setNegativeButton("Закрыть", null)
        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        val p = getSharedPreferences("brouter_download", MODE_PRIVATE)
        if (p.getString("state", "") == "running") {
            status.text = "Загрузка RD5 продолжается в фоне. " +
                (p.getString("message", "") ?: "") + "\\nОткройте «Статус загрузки RD5» для подробностей."
        }
    }

    private fun chooseSegments() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_TITLE, "Выберите файлы BRouter .rd5")
        }
        startActivityForResult(intent, importRequest)
    }

    @Deprecated("Storage Access Framework result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == storageRequest) {
            if (resultCode == RESULT_OK && data?.data != null) {
                val uri = data.data!!
                try { contentResolver.takePersistableUriPermission(uri, data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)) } catch (_: Exception) {}
                askRegionName(uri)
            }
            return
        }
        if (requestCode == exportRequest) {
            if (resultCode != RESULT_OK || data?.data == null) return
            val source = lastGpxFile
            if (source == null || !source.exists()) {
                status.text = "Исходный GPX-файл не найден."
                return
            }
            try {
                val output = contentResolver.openOutputStream(data.data!!, "w")
                    ?: throw IllegalStateException("Не удалось открыть файл для записи")
                output.use { out -> source.inputStream().buffered().use { input -> input.copyTo(out) } }
                status.text = "GPX экспортирован. Файл доступен в выбранной папке и его можно открыть в другом приложении."
                Toast.makeText(this, "Файл GPX сохранён", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                status.text = "Не удалось сохранить GPX: ${e.message}"
            }
            return
        }
        if (requestCode != importRequest || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        val unique = uris.distinct()
        if (unique.isEmpty()) return
        status.text = "Импорт данных маршрутизации…"
        thread(name = "BRouterSegmentImport") {
            val dir = segmentDir()
            var copied = 0
            var skipped = 0
            for (uri in unique) {
                val name = queryDisplayName(uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "segment.rd5"
                if (!name.endsWith(".rd5", true)) { skipped++; continue }
                try {
                    val input = contentResolver.openInputStream(uri)
                    if (input == null) { skipped++; continue }
                    input.use { source ->
                        File(dir, name).outputStream().use { output -> source.copyTo(output) }
                    }
                    val imported = File(dir, name)
                    if (RegionStorage.rootUri(this@RoutePlannerActivity) != null && !RegionStorage.copyFileToFolder(this@RoutePlannerActivity, imported, "Routing")) {
                        skipped++
                    } else copied++
                } catch (_: Exception) { skipped++ }
            }
            runOnUiThread {
                status.text = "Импортировано сегментов: $copied. Пропущено: $skipped.\n${segmentSummary()}"
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun segmentDir(): File = File(filesDir, "brouter/segments4").apply { mkdirs() }

    private fun ensureProfileFiles() {
        val dir = File(filesDir, "brouter/profiles2").apply { mkdirs() }
        listOf("hiking-mountain.brf", "lookups.dat").forEach { name ->
            val target = File(dir, name)
            if (!target.exists() || target.length() == 0L) {
                assets.open("brouter/profiles2/$name").use { input -> target.outputStream().use { input.copyTo(it) } }
            }
        }
    }

    private fun refreshSegmentStatus() {
        val files = segmentDir().listFiles { f -> f.isFile && f.name.endsWith(".rd5", true) } ?: emptyArray()
        status.text = "Профиль горного пешего туризма готов.\n${files.size} файлов .rd5 • ${segmentSummary()}"
    }

    private fun segmentSummary(): String {
        val files = segmentDir().listFiles { f -> f.isFile && f.name.endsWith(".rd5", true) } ?: emptyArray()
        val bytes = files.sumOf { it.length() }
        val region = if (RegionStorage.rootUri(this) != null) " • регион: ${RegionStorage.regionName(this)} (внешнее хранилище)" else " • внешнее хранилище не настроено"
        return String.format(Locale.getDefault(), "Данные маршрутизации: %d сегм. • %.1f МБ", files.size, bytes / 1048576.0) + region
    }

    private fun exportLastGpx() {
        val file = lastGpxFile
        if (file == null || !file.exists()) {
            status.text = "Сначала постройте маршрут."
            return
        }
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(java.util.Date())
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/gpx+xml"
            putExtra(Intent.EXTRA_TITLE, "GeoTracker_route_$stamp.gpx")
        }
        startActivityForResult(intent, exportRequest)
    }

    private fun showLastRouteOnMap() {
        val file = lastGpxFile
        if (file == null || !file.exists()) {
            status.text = "Сначала постройте маршрут."
            return
        }
        startActivity(Intent(this, OfflineMapActivity::class.java)
            .putExtra(OfflineMapActivity.EXTRA_SHOW_GPX_PATH, file.absolutePath))
    }


    private fun calculateRoute() {
        val waypoints = try { parseWaypoints() } catch (e: Exception) {
            status.text = "Проверьте координаты: ${e.message}"; return
        }
        val segments = segmentDir().listFiles { f -> f.isFile && f.name.endsWith(".rd5", true) } ?: emptyArray()
        if (segments.isEmpty()) {
            status.text = "Нет данных .rd5. Импортируйте сегменты для региона похода. Карта .map и DEM не заменяют данные маршрутизации."
            return
        }
        routeButton.isEnabled = false
        exportButton.isEnabled = false
        showRouteButton.isEnabled = false
        lastGpxFile = null
        status.text = "BRouter строит маршрут…"
        thread(name = "BRouterRouteCalculation") {
            try {
                ensureProfileFiles()
                val profile = File(filesDir, "brouter/profiles2/hiking-mountain.brf")
                val rc = RoutingContext().apply {
                    localFunction = profile.absolutePath
                    keyValues = HashMap()
                    memoryclass = 64
                    outputFormat = "gpx"
                }
                val outDir = File(filesDir, "routes").apply { mkdirs() }
                val outBase = File(outDir, "route").absolutePath
                val engine = RoutingEngine(outBase, null, segmentDir(), waypoints, rc)
                engine.doRun(0)
                val error = engine.getErrorMessage()
                val gpx = File(outDir, "route0.gpx")
                if (gpx.exists() && RegionStorage.rootUri(this@RoutePlannerActivity) != null) {
                    val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
                    val saved = File(outDir, "route_$stamp.gpx")
                    gpx.copyTo(saved, overwrite = true)
                    RegionStorage.copyFileToFolder(this@RoutePlannerActivity, saved, "Routes")
                }
                runOnUiThread {
                    routeButton.isEnabled = true
                    if (!error.isNullOrBlank() || !gpx.exists()) {
                        lastGpxFile = null
                        status.text = "Маршрут не построен: ${error ?: "BRouter не создал GPX"}\nПроверьте наличие всех .rd5 для начальной, конечной и промежуточных точек."
                    } else {
                        lastGpxFile = gpx
                        exportButton.isEnabled = true
                        showRouteButton.isEnabled = true
                        val km = engine.getDistance() / 1000.0
                        status.text = String.format(Locale.getDefault(),
                            "Маршрут построен!\nРасстояние: %.2f км\nНабор высоты: %d м\nВремя по профилю: %s\nФайл GPX готов. Выберите экспорт или просмотр на карте.",
                            km, engine.getAscend(), engine.getTime())
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    routeButton.isEnabled = true
                    status.text = "Ошибка маршрутизации: ${e.message}"
                }
            }
        }
    }

    private fun parseWaypoints(): MutableList<OsmNodeNamed> {
        val points = mutableListOf<Pair<Double, Double>>()
        fun add(latText: String, lonText: String) {
            val lat = latText.trim().replace(',', '.').toDouble()
            val lon = lonText.trim().replace(',', '.').toDouble()
            require(lat in -90.0..90.0 && lon in -180.0..180.0) { "широта/долгота вне диапазона" }
            points.add(lat to lon)
        }
        add(startLat.text.toString(), startLon.text.toString())
        viaText.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
            val p = line.split(',', ';', ' ', '\t').filter { it.isNotBlank() }
            require(p.size == 2) { "промежуточная точка должна быть в формате lat,lon" }
            add(p[0], p[1])
        }
        add(endLat.text.toString(), endLon.text.toString())
        require(points.size >= 2) { "нужны начало и конец" }
        return points.mapIndexed { i, p ->
            OsmNodeNamed().apply {
                name = if (i == 0) "start" else if (i == points.lastIndex) "finish" else "via_$i"
                ilon = 180000000 + (p.second * 1000000.0 + 0.5).toInt()
                ilat = 90000000 + (p.first * 1000000.0 + 0.5).toInt()
            }
        }.toMutableList()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
