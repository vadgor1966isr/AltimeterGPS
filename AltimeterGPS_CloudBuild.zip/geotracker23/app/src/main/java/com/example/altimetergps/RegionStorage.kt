package com.example.altimetergps

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/** Persistent user-owned region storage. BRouter still receives a private working copy. */
object RegionStorage {
    private const val PREFS = "region_storage"
    private const val ROOT_URI = "root_uri"
    private const val REGION = "active_region"
    private val folders = listOf("Maps", "Routing", "Elevation", "Routes")

    fun rootUri(context: Context): Uri? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(ROOT_URI, null)?.let { Uri.parse(it) }
    fun regionName(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(REGION, "Dolomites") ?: "Dolomites"

    fun configure(context: Context, treeUri: Uri, regionName: String): DocumentFile {
        val resolver = context.contentResolver
        val tree = DocumentFile.fromTreeUri(context, treeUri) ?: error("Не удалось открыть выбранную папку")
        val safeName = regionName.trim().replace(Regex("[^\\p{L}\\p{N} _-]"), "_").ifBlank { "Region" }
        val appFolder = childFolder(tree, "GeoTracker")
        val region = childFolder(appFolder, safeName)
        folders.forEach { childFolder(region, it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ROOT_URI, treeUri.toString()).putString(REGION, safeName).commit()
        try {
            resolver.takePersistableUriPermission(treeUri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {}
        // Keep the existing Mapsforge downloader and viewer pointed at this region's Maps folder.
        val maps = region.findFile("Maps") ?: error("Не удалось создать папку Maps")
        context.getSharedPreferences("mapsforge", Context.MODE_PRIVATE).edit()
            .putString("maps_tree_uri", maps.uri.toString()).commit()
        return region
    }

    fun regionFolder(context: Context, name: String): DocumentFile? {
        val treeUri = rootUri(context) ?: return null
        val tree = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        val app = tree.findFile("GeoTracker") ?: return null
        val region = app.findFile(regionName(context)) ?: return null
        return region.findFile(name)
    }

    fun copyFileToFolder(context: Context, source: File, folderName: String): Boolean =
        copyFileToDocumentFolder(context, source, regionFolder(context, folderName))

    fun copyFileToDocumentFolder(context: Context, source: File, folder: DocumentFile?): Boolean {
        if (folder == null) return false
        val existing = folder.findFile(source.name)
        val target = existing ?: folder.createFile("application/octet-stream", source.name) ?: return false
        return try {
            val input = source.inputStream().buffered()
            val output = context.contentResolver.openOutputStream(target.uri, "w") ?: return false
            input.use { src -> output.use { dst -> src.copyTo(dst, 256 * 1024) } }
            true
        } catch (_: Exception) { false }
    }

    fun elevationZoomFolder(context: Context, zoom: Int): DocumentFile? {
        val elevation = regionFolder(context, "Elevation") ?: return null
        return try { childFolder(elevation, zoom.toString()) } catch (_: Exception) { null }
    }

    fun copyDocumentToFile(context: Context, doc: DocumentFile, target: File): Boolean {
        return try {
            val input = context.contentResolver.openInputStream(doc.uri) ?: return false
            target.parentFile?.mkdirs()
            input.use { src -> target.outputStream().buffered().use { dst -> src.copyTo(dst, 256 * 1024) } }
            target.length() > 0L
        } catch (_: Exception) { false }
    }

    fun childFolder(parent: DocumentFile, name: String): DocumentFile =
        parent.findFile(name)?.takeIf { it.isDirectory } ?: parent.createDirectory(name)
        ?: error("Не удалось создать папку $name")
}
