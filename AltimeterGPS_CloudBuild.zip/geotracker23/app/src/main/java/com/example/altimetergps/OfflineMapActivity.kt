package com.example.altimetergps

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import org.mapsforge.core.model.LatLong
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.datastore.MapDataStore
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.internal.MapsforgeThemes
import android.os.ParcelFileDescriptor
import android.widget.ProgressBar
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream
import android.os.Handler
import androidx.documentfile.provider.DocumentFile
import android.os.Looper

/** First-stage offline Mapsforge map viewer. It reads the selected .map file directly
 * through Android's Storage Access Framework; it does not copy a 1-2 GB map into app storage. */
class OfflineMapActivity : Activity() {
    private lateinit var mapView: MapView
    private lateinit var info: TextView
    private var mapDataStore: MapDataStore? = null
    private var tileLayer: TileRendererLayer? = null
    private var tileCache: TileCache? = null
    private var mapPfd: ParcelFileDescriptor? = null
    private var mapInputStream: FileInputStream? = null
    private lateinit var downloadButton: Button
    private lateinit var progressBar: ProgressBar
    private val uiHandler = Handler(Looper.getMainLooper())
    private var statusPolling = false
    private val mapFileName = "openhiking_alps_east.map"
    private val mapDownloadUrl = "https://www.openhiking.eu/en/component/phocadownload/category/1-terkepek/5-turistaterkepek-mapsforge?Itemid=102&download=28%3Aopenhiking-alps-east"
    private val pickMapRequest = 4101
    private val pickFolderRequest = 4102
    private val prefs by lazy { getSharedPreferences("mapsforge", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 36, 58))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val title = TextView(this).apply {
            text = "ОФЛАЙН-КАРТА MAPSFORGE"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(4, dp(8), 4, dp(8))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        info = TextView(this).apply {
            text = "Выберите файл карты Mapsforge (.map). После открытия карта будет работать без интернета."
            textSize = 13f
            setTextColor(Color.rgb(210, 225, 235))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(8))
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        val sizeInfo = TextView(this).apply {
            text = "Размер карты Восточные Альпы: примерно 1,3 ГБ для загрузки (архив), около 1,6 ГБ после распаковки. Для установки требуется не менее 1,8 ГБ свободного места."
            textSize = 12f
            setTextColor(Color.rgb(190, 210, 225))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(2), dp(6), dp(8))
        }
        root.addView(sizeInfo, LinearLayout.LayoutParams(-1, -2))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(Button(this).apply {
            text = "ВЫБРАТЬ КАРТУ"
            setOnClickListener { chooseMap() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply {
            text = "ДОЛОМИТЫ"
            setOnClickListener {
                mapView.setCenter(LatLong(46.5, 11.9))
                mapView.setZoomLevel(10.toByte())
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))

        downloadButton = Button(this).apply {
            text = "СКАЧАТЬ КАРТУ АЛЬПЫ ВОСТОЧНЫЕ (ДОЛОМИТЫ)"
            setOnClickListener { handleDownloadButton() }
        }
        root.addView(downloadButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "ВЫБРАТЬ ПАПКУ ДЛЯ ХРАНЕНИЯ КАРТ"
            setOnClickListener { chooseStorageFolder() }
        }, LinearLayout.LayoutParams(-1, -2))
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = android.view.View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(8)))

        mapView = MapView(this).apply {
            setBuiltInZoomControls(true)
        }
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        startStatusPolling()

        val savedMap = prefs.getString("downloaded_map_uri", null)
        val savedTree = prefs.getString("maps_tree_uri", null)
        val mapUri = savedMap?.let { Uri.parse(it) } ?: savedTree?.let { findPersistentMap(Uri.parse(it)) }
        if (mapUri != null) {
            try {
                loadMap(mapUri)
                prefs.edit().putString("downloaded_map_uri", mapUri.toString()).apply()
            } catch (_: Exception) {
                info.text = "Карта в выбранной папке найдена, но недоступна. Выберите папку хранения ещё раз."
            }
        } else {
            val saved = prefs.getString("map_uri", null)
            if (!saved.isNullOrBlank()) {
                try { loadMap(Uri.parse(saved)) }
                catch (_: Exception) { info.text = "Ранее выбранная карта недоступна. Выберите файл .map заново." }
            }
        }
    }

    private fun chooseStorageFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickFolderRequest)
    }

    private fun findPersistentMap(treeUri: Uri): Uri? {
        val tree = DocumentFile.fromTreeUri(this, treeUri) ?: return null
        return tree.findFile(mapFileName)?.takeIf { it.isFile && it.length() > 0L }?.uri
    }

    private fun handleDownloadButton() {
        val status = prefs.getString("download_status", "idle") ?: "idle"
        if (status == "downloading") {
            val intent = Intent(this, MapsforgeDownloadService::class.java).apply { action = MapsforgeDownloadService.ACTION_CANCEL }
            startService(intent)
            info.text = "Отправлена команда остановки загрузки…"
            return
        }
        val tree = prefs.getString("maps_tree_uri", null)
        if (tree.isNullOrBlank()) {
            info.text = "Сначала выберите папку для хранения карт. Рекомендуется общая папка Documents/GeoTracker/Maps."
            chooseStorageFolder()
            return
        }
        val existing = findPersistentMap(Uri.parse(tree))
        if (existing != null) {
            try { loadMap(existing); prefs.edit().putString("downloaded_map_uri", existing.toString()).apply() }
            catch (e: Exception) { info.text = "Не удалось открыть карту: ${e.message}" }
            return
        }
        val intent = Intent(this, MapsforgeDownloadService::class.java).apply { action = MapsforgeDownloadService.ACTION_START }
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            prefs.edit().putString("download_status", "downloading").apply()
            downloadButton.text = "ОТМЕНИТЬ ЗАГРУЗКУ"
            info.text = "Загрузка идёт в выбранную общую папку и продолжится при выходе с этого экрана."
            progressBar.visibility = android.view.View.VISIBLE
            progressBar.isIndeterminate = true
        } catch (e: Exception) { info.text = "Не удалось запустить фоновую загрузку: ${e.message}" }
    }

    private fun startStatusPolling() {
        if (statusPolling) return
        statusPolling = true
        uiHandler.post(statusPollRunnable)
    }

    private val statusPollRunnable = object : Runnable {
        override fun run() {
            if (!statusPolling || isFinishing) return
            val status = prefs.getString("download_status", "idle") ?: "idle"
            when (status) {
                "downloading" -> {
                    val heartbeat = prefs.getLong("download_heartbeat", 0L)
                    if (heartbeat > 0L && System.currentTimeMillis() - heartbeat > 240000L) {
                        prefs.edit().putString("download_status", "failed")
                            .putString("download_error", "процесс загрузки был прерван").apply()
                        uiHandler.postDelayed(this, 1000L)
                        return
                    }
                    val total = prefs.getLong("download_total", -1L)
                    val received = prefs.getLong("download_received", 0L)
                    val extracted = prefs.getLong("download_extracted", 0L)
                    downloadButton.text = "ОТМЕНИТЬ ЗАГРУЗКУ"
                    progressBar.visibility = android.view.View.VISIBLE
                    if (total > 0L) {
                        val pct = ((received * 100L) / total).toInt().coerceIn(0, 99)
                        progressBar.isIndeterminate = false
                        progressBar.progress = pct
                        info.text = "Загрузка карты: $pct% • получено ${formatMb(received)} из ${formatMb(total)} МБ • распаковано ${formatMb(extracted)} МБ"
                    } else {
                        progressBar.isIndeterminate = true
                        info.text = "Загрузка карты… получено ${formatMb(received)} МБ • распаковано ${formatMb(extracted)} МБ • сервер не сообщил общий размер"
                    }
                }
                "failed" -> {
                    downloadButton.text = "ПОВТОРИТЬ ЗАГРУЗКУ КАРТЫ"
                    downloadButton.isEnabled = true
                    progressBar.visibility = android.view.View.GONE
                    info.text = "Загрузка прервана: ${prefs.getString("download_error", "ошибка соединения")}. Нажмите «Повторить загрузку карты»."
                }
                "cancelled" -> {
                    downloadButton.text = "ПОВТОРИТЬ ЗАГРУЗКУ КАРТЫ"
                    downloadButton.isEnabled = true
                    progressBar.visibility = android.view.View.GONE
                    info.text = "Загрузка остановлена. Можно запустить её снова."
                }
                "completed" -> {
                    downloadButton.text = "КАРТА АЛЬП УЖЕ ЗАГРУЖЕНА"
                    downloadButton.isEnabled = true
                    progressBar.visibility = android.view.View.GONE
                    val tree = prefs.getString("maps_tree_uri", null)
                    val uri = tree?.let { findPersistentMap(Uri.parse(it)) }
                    if (uri != null && mapDataStore == null) {
                        try { loadMap(uri); prefs.edit().putString("downloaded_map_uri", uri.toString()).apply() }
                        catch (e: Exception) { info.text = "Карта скачана, но не открылась: ${e.message}" }
                    }
                }
                else -> {
                    downloadButton.text = "СКАЧАТЬ КАРТУ АЛЬПЫ ВОСТОЧНЫЕ (ДОЛОМИТЫ)"
                }
            }
            uiHandler.postDelayed(this, 700L)
        }
    }

    private fun formatMb(bytes: Long): String = String.format(java.util.Locale.US, "%.0f", bytes / 1048576.0)

    private fun chooseMap() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, "Выберите карту Mapsforge (.map)")
        }
        startActivityForResult(intent, pickMapRequest)
    }

    @Deprecated("Uses the Storage Access Framework result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == pickFolderRequest) {
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(uri, flags)
                prefs.edit().putString("maps_tree_uri", uri.toString()).apply()
                val existing = findPersistentMap(uri)
                if (existing != null) {
                    prefs.edit().putString("downloaded_map_uri", existing.toString()).apply()
                    loadMap(existing)
                } else {
                    info.text = "Папка выбрана. Карта будет сохранена здесь: ${DocumentFile.fromTreeUri(this, uri)?.name ?: "выбранная папка"}. Нажмите «Скачать карту»."
                }
            } catch (e: Exception) { info.text = "Не удалось сохранить доступ к папке: ${e.message}" }
            return
        }
        if (requestCode == pickMapRequest) {
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                try { contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                prefs.edit().putString("map_uri", uri.toString()).apply()
                loadMap(uri)
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось открыть карту: ${e.message ?: "неверный файл"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadMap(uri: Uri) {
        info.text = "Открываю карту…"
        val pfd = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Не удалось открыть файл")
        val stream = FileInputStream(pfd.fileDescriptor)
        try {
            installMapStream(stream, pfd, uri.lastPathSegment?.substringAfterLast('/') ?: "карта")
        } catch (e: Exception) {
            try { stream.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
            throw e
        }
    }

    private fun installMapStream(stream: FileInputStream, pfd: ParcelFileDescriptor?, displayName: String) {
        var newStore: MapFile? = null
        try {
            newStore = MapFile(stream)
            val cache = AndroidUtil.createTileCache(
                this, "geotracker-mapsforge-cache",
                mapView.model.displayModel.tileSize, 1f,
                mapView.model.frameBufferModel.overdrawFactor
            )
            val layer = AndroidUtil.createTileRendererLayer(
                cache, mapView.model.mapViewPosition, newStore, MapsforgeThemes.DEFAULT
            )
            tileLayer?.let { old ->
                mapView.layerManager.layers.remove(old)
                old.onDestroy()
            }
            mapDataStore?.close()
            mapInputStream?.close()
            mapPfd?.close()
            tileCache?.destroy()
            mapDataStore = newStore
            mapInputStream = stream
            mapPfd = pfd
            tileCache = cache
            tileLayer = layer
            mapView.layerManager.layers.add(layer)
            val center = newStore.startPosition() ?: LatLong(46.5, 11.9)
            mapView.setCenter(center)
            mapView.setZoomLevel((newStore.startZoomLevel() ?: 10.toByte()).toByte())
            mapView.layerManager.redrawLayers()
            info.text = "Загружена офлайн-карта: $displayName\nМасштабируйте и перемещайте карту. Интернет не требуется."
            downloadButton.text = "КАРТА АЛЬП УЖЕ ЗАГРУЖЕНА"
            newStore = null
        } catch (e: Exception) {
            try { newStore?.close() } catch (_: Exception) {}
            throw e
        }
    }

    override fun onDestroy() {
        try { mapView.destroyAll() } catch (_: Exception) {}
        try { mapDataStore?.close() } catch (_: Exception) {}
        try { mapPfd?.close() } catch (_: Exception) {}
        try { mapInputStream?.close() } catch (_: Exception) {}
        statusPolling = false
        uiHandler.removeCallbacks(statusPollRunnable)
        try { tileCache?.destroy() } catch (_: Exception) {}
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
