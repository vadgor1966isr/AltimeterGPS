package com.example.altimetergps

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import org.mapsforge.core.model.LatLong
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.datastore.MapDataStore
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.internal.MapsforgeThemes
import android.os.ParcelFileDescriptor
import android.os.Environment
import android.widget.ProgressBar
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean
import android.os.StatFs

/** First-stage offline Mapsforge map viewer. It reads the selected .map file directly
 * through Android's Storage Access Framework; it does not copy a 1-2 GB map into app storage. */
class OfflineMapActivity : Activity() {
    private lateinit var mapView: MapView
    private lateinit var info: TextView
    private var mapDataStore: MapDataStore? = null
    private var tileLayer: TileRendererLayer? = null
    private var tileCache: TileCache? = null
    private var mapPfd: ParcelFileDescriptor? = null
    private var mapInputStream: FileInputStream? = null
    private lateinit var downloadButton: Button
    private lateinit var progressBar: ProgressBar
    private var downloadTask: Future<*>? = null
    private val cancelDownload = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()
    private val mapFileName = "openhiking_alps_east.map"
    private val mapDownloadUrl = "https://www.openhiking.eu/en/component/phocadownload/category/1-terkepek/5-turistaterkepek-mapsforge?Itemid=102&download=28%3Aopenhiking-alps-east"
    private val pickMapRequest = 4101
    private val prefs by lazy { getSharedPreferences("mapsforge", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 36, 58))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val title = TextView(this).apply {
            text = "ОФЛАЙН-КАРТА MAPSFORGE"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(4, dp(8), 4, dp(8))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        info = TextView(this).apply {
            text = "Выберите файл карты Mapsforge (.map). После открытия карта будет работать без интернета."
            textSize = 13f
            setTextColor(Color.rgb(210, 225, 235))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(8))
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(Button(this).apply {
            text = "ВЫБРАТЬ КАРТУ"
            setOnClickListener { chooseMap() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply {
            text = "ДОЛОМИТЫ"
            setOnClickListener {
                mapView.setCenter(LatLong(46.5, 11.9))
                mapView.setZoomLevel(10.toByte())
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))

        downloadButton = Button(this).apply {
            text = "СКАЧАТЬ КАРТУ АЛЬПЫ ВОСТОЧНЫЕ (ДОЛОМИТЫ)"
            setOnClickListener { startMapDownload() }
        }
        root.addView(downloadButton, LinearLayout.LayoutParams(-1, -2))
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = android.view.View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(8)))

        mapView = MapView(this).apply {
            setBuiltInZoomControls(true)
        }
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val downloaded = downloadedMapFile()
        if (downloaded.exists() && downloaded.length() > 0L) {
            try {
                loadMapFile(downloaded)
            } catch (_: Exception) {
                info.text = "Скачанная карта найдена, но не открылась. Можно скачать её заново или выбрать другой файл."
            }
        } else {
            val saved = prefs.getString("map_uri", null)
            if (!saved.isNullOrBlank()) {
                try { loadMap(Uri.parse(saved)) }
                catch (_: Exception) { info.text = "Ранее выбранная карта недоступна. Выберите файл .map заново." }
            }
        }
    }

    private fun downloadedMapFile(): File {
        val base = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
        val dir = File(base, "mapsforge")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, mapFileName)
    }

    private fun startMapDownload() {
        if (downloadTask?.isDone == false) {
            cancelDownload.set(true)
            downloadButton.isEnabled = false
            info.text = "Останавливаю загрузку…"
            return
        }
        val target = downloadedMapFile()
        val available = StatFs(target.parentFile!!.absolutePath).availableBytes
        if (available < 1_800_000_000L) {
            info.text = "Недостаточно свободной памяти. Нужно примерно 1,8 ГБ, доступно ${formatMb(available)} МБ."
            return
        }
        if (target.exists() && target.length() > 0L) {
            try {
                loadMapFile(target)
                Toast.makeText(this, "Карта уже загружена", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось открыть карту: ${e.message}", Toast.LENGTH_LONG).show()
            }
            return
        }
        cancelDownload.set(false)
        downloadButton.text = "ОТМЕНИТЬ ЗАГРУЗКУ"
        progressBar.progress = 0
        progressBar.visibility = android.view.View.VISIBLE
        info.text = "Подключаюсь к OpenHiking. Загружается архив карты Восточные Альпы…"
        downloadTask = executor.submit {
            val temp = File(target.parentFile, target.name + ".part")
            var completed = false
            var lastError: Exception? = null
            // OpenHiking occasionally closes long HTTP transfers. Retry the complete
            // streamed ZIP extraction with backoff; no second 1.3 GB ZIP is stored.
            for (attempt in 1..4) {
                if (cancelDownload.get()) break
                var connection: HttpURLConnection? = null
                temp.delete()
                try {
                    runOnUiThread {
                        info.text = if (attempt == 1) {
                            "Подключаюсь к OpenHiking…"
                        } else {
                            "Повторная попытка $attempt из 4…"
                        }
                        progressBar.progress = 0
                    }
                    connection = (URL(mapDownloadUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 45000
                        readTimeout = 180000
                        instanceFollowRedirects = true
                        requestMethod = "GET"
                        useCaches = false
                        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36 GeoTracker/3.10")
                        setRequestProperty("Accept", "application/zip,application/octet-stream,*/*")
                        setRequestProperty("Accept-Encoding", "identity")
                        setRequestProperty("Referer", "https://www.openhiking.eu/en/downloads/mapsforge-maps")
                        setRequestProperty("Connection", "close")
                    }
                    connection.connect()
                    val code = connection.responseCode
                    if (code !in 200..299) throw IllegalStateException("Сервер ответил HTTP $code")
                    val total = connection.contentLengthLong
                    var extracted = 0L
                    var foundMap = false
                    val counted = CountingInputStream(BufferedInputStream(connection.inputStream, 256 * 1024))
                    ZipInputStream(counted).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            if (!entry.isDirectory && entry.name.lowercase().endsWith(".map")) {
                                FileOutputStream(temp).use { out ->
                                    val buffer = ByteArray(256 * 1024)
                                    var lastUi = 0L
                                    while (true) {
                                        if (cancelDownload.get()) throw InterruptedException("Загрузка отменена")
                                        val n = zip.read(buffer)
                                        if (n < 0) break
                                        out.write(buffer, 0, n)
                                        extracted += n
                                        val now = System.currentTimeMillis()
                                        if (now - lastUi >= 700L) {
                                            lastUi = now
                                            val pct = if (total > 0L) ((counted.bytesRead * 100L) / total).toInt().coerceIn(0, 99) else 0
                                            val doneMb = formatMb(extracted)
                                            runOnUiThread {
                                                progressBar.progress = pct
                                                info.text = "Загрузка и распаковка карты… $pct% • $doneMb МБ распаковано • попытка $attempt/4"
                                            }
                                        }
                                    }
                                    out.fd.sync()
                                }
                                foundMap = true
                                break
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                    if (!foundMap || !temp.exists() || temp.length() < 500L * 1024L * 1024L) {
                        throw IllegalStateException("Архив неполный или в нём не найден полноценный файл .map")
                    }
                    if (cancelDownload.get()) throw InterruptedException("Загрузка отменена")
                    // Validate Mapsforge file structure before replacing any existing map.
                    val validation = MapFile(FileInputStream(temp))
                    validation.close()
                    if (target.exists() && !target.delete()) throw IllegalStateException("Не удалось заменить старую карту")
                    if (!temp.renameTo(target)) throw IllegalStateException("Не удалось сохранить файл карты")
                    completed = true
                    runOnUiThread {
                        progressBar.progress = 100
                        downloadButton.text = "КАРТА АЛЬП УЖЕ ЗАГРУЖЕНА"
                        downloadButton.isEnabled = true
                        info.text = "Карта загружена и проверена (${formatMb(target.length())} МБ). Открываю…"
                        try { loadMapFile(target) }
                        catch (e: Exception) { info.text = "Карта загружена, но не открылась: ${e.message}" }
                    }
                    break
                } catch (e: InterruptedException) {
                    lastError = e
                    break
                } catch (e: Exception) {
                    lastError = e
                    temp.delete()
                    if (attempt < 4 && !cancelDownload.get()) {
                        runOnUiThread {
                            info.text = "Соединение прервалось (попытка $attempt/4). Повторяю через ${attempt * 3} сек…"
                        }
                        try { Thread.sleep(attempt * 3000L) } catch (_: InterruptedException) { break }
                    }
                } finally {
                    connection?.disconnect()
                }
            }
            if (!completed) {
                temp.delete()
                runOnUiThread {
                    downloadButton.text = "ПОВТОРИТЬ ЗАГРУЗКУ КАРТЫ"
                    downloadButton.isEnabled = true
                    progressBar.visibility = android.view.View.GONE
                    info.text = if (cancelDownload.get()) {
                        "Загрузка отменена. Можно запустить её снова."
                    } else {
                        "Не удалось загрузить карту после 4 попыток: ${lastError?.message ?: "ошибка соединения"}. Проверьте интернет и повторите позже."
                    }
                }
            }
        }
    }

    private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
        var bytesRead: Long = 0
            private set
        override fun read(): Int {
            val value = super.read()
            if (value >= 0) bytesRead++
            return value
        }
        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            val count = super.read(buffer, offset, length)
            if (count > 0) bytesRead += count
            return count
        }
    }

    private fun formatMb(bytes: Long): String = String.format(java.util.Locale.US, "%.0f", bytes / 1048576.0)

    private fun loadMapFile(file: File) {
        info.text = "Открываю карту ${file.name}…"
        val stream = FileInputStream(file)
        try {
            installMapStream(stream, null, file.name)
            prefs.edit().remove("map_uri").apply()
        } catch (e: Exception) {
            try { stream.close() } catch (_: Exception) {}
            throw e
        }
    }

    private fun chooseMap() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, "Выберите карту Mapsforge (.map)")
        }
        startActivityForResult(intent, pickMapRequest)
    }

    @Deprecated("Uses the Storage Access Framework result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickMapRequest || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("map_uri", uri.toString()).apply()
            loadMap(uri)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть карту: ${e.message ?: "неверный файл"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadMap(uri: Uri) {
        info.text = "Открываю карту…"
        val pfd = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Не удалось открыть файл")
        val stream = FileInputStream(pfd.fileDescriptor)
        try {
            installMapStream(stream, pfd, uri.lastPathSegment?.substringAfterLast('/') ?: "карта")
        } catch (e: Exception) {
            try { stream.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
            throw e
        }
    }

    private fun installMapStream(stream: FileInputStream, pfd: ParcelFileDescriptor?, displayName: String) {
        var newStore: MapFile? = null
        try {
            newStore = MapFile(stream)
            val cache = AndroidUtil.createTileCache(
                this, "geotracker-mapsforge-cache",
                mapView.model.displayModel.tileSize, 1f,
                mapView.model.frameBufferModel.overdrawFactor
            )
            val layer = AndroidUtil.createTileRendererLayer(
                cache, mapView.model.mapViewPosition, newStore, MapsforgeThemes.DEFAULT
            )
            tileLayer?.let { old ->
                mapView.layerManager.layers.remove(old)
                old.onDestroy()
            }
            mapDataStore?.close()
            mapInputStream?.close()
            mapPfd?.close()
            tileCache?.destroy()
            mapDataStore = newStore
            mapInputStream = stream
            mapPfd = pfd
            tileCache = cache
            tileLayer = layer
            mapView.layerManager.layers.add(layer)
            val center = newStore.startPosition() ?: LatLong(46.5, 11.9)
            mapView.setCenter(center)
            mapView.setZoomLevel((newStore.startZoomLevel() ?: 10.toByte()).toByte())
            mapView.layerManager.redrawLayers()
            info.text = "Загружена офлайн-карта: $displayName\nМасштабируйте и перемещайте карту. Интернет не требуется."
            downloadButton.text = "КАРТА АЛЬП УЖЕ ЗАГРУЖЕНА"
            newStore = null
        } catch (e: Exception) {
            try { newStore?.close() } catch (_: Exception) {}
            throw e
        }
    }

    override fun onDestroy() {
        try { mapView.destroyAll() } catch (_: Exception) {}
        try { mapDataStore?.close() } catch (_: Exception) {}
        try { mapPfd?.close() } catch (_: Exception) {}
        try { mapInputStream?.close() } catch (_: Exception) {}
        try { downloadTask?.cancel(true) } catch (_: Exception) {}
        executor.shutdownNow()
        try { tileCache?.destroy() } catch (_: Exception) {}
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
