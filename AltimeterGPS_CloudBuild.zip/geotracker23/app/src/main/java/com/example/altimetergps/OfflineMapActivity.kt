package com.example.altimetergps

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import org.mapsforge.core.model.LatLong
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.datastore.MapDataStore
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.layer.overlay.Polyline
import org.mapsforge.core.graphics.Style
import org.mapsforge.core.graphics.Paint
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import org.mapsforge.map.rendertheme.internal.MapsforgeThemes
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream
import androidx.documentfile.provider.DocumentFile

/** First-stage offline Mapsforge map viewer. It reads the selected .map file directly
 * through Android's Storage Access Framework; it does not copy a 1-2 GB map into app storage. */
class OfflineMapActivity : Activity() {
    companion object {
        const val EXTRA_SHOW_GPX_PATH = "com.example.altimetergps.SHOW_GPX_PATH"
    }

    private lateinit var mapView: MapView
    private var routeOverlay: Polyline? = null
    private lateinit var info: TextView
    private var mapDataStore: MapDataStore? = null
    private var tileLayer: TileRendererLayer? = null
    private var tileCache: TileCache? = null
    private var mapPfd: ParcelFileDescriptor? = null
    private var mapInputStream: FileInputStream? = null
    private val pickMapRequest = 4101
    private val pickFolderRequest = 4102
    private val prefs by lazy { getSharedPreferences("mapsforge", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 36, 58))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val title = TextView(this).apply {
            text = "ОФЛАЙН-КАРТА MAPSFORGE"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(4, dp(8), 4, dp(8))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val topActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topActions.addView(Button(this).apply {
            text = "ПЛАНИРОВАТЬ ПОХОД"
            setOnClickListener { startActivity(Intent(this@OfflineMapActivity, RoutePlannerActivity::class.java)) }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        topActions.addView(Button(this).apply {
            text = "ОНЛАЙН / GPS"
            setOnClickListener {
                startActivity(Intent(this@OfflineMapActivity, MainActivity::class.java).putExtra("OPEN_ONLINE_DASHBOARD", true))
                finish()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(topActions, LinearLayout.LayoutParams(-1, -2))
        info = TextView(this).apply {
            text = "Офлайн-карта — основной экран GeoTracker. Выбор и загрузка картографической области и связанных данных выполняются в Центре загрузок."
            textSize = 13f
            setTextColor(Color.rgb(210, 225, 235))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(8))
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        val sizeInfo = TextView(this).apply {
            text = "Карты Mapsforge хранятся в выбранной вами папке. Выбор и загрузка новой области выполняются в Центре загрузок."
            textSize = 12f
            setTextColor(Color.rgb(190, 210, 225))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(2), dp(6), dp(8))
        }
        root.addView(sizeInfo, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "ВЫБРАТЬ КАРТУ"
            setOnClickListener { chooseMap() }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "УПРАВЛЕНИЕ ЗАГРУЖЕННЫМИ КАРТАМИ"
            setOnClickListener { manageMaps() }
        }, LinearLayout.LayoutParams(-1, -2))

        root.addView(Button(this).apply {
            text = "ВЫБРАТЬ ПАПКУ ДЛЯ ХРАНЕНИЯ КАРТ"
            setOnClickListener { chooseStorageFolder() }
        }, LinearLayout.LayoutParams(-1, -2))

        mapView = MapView(this).apply {
            setBuiltInZoomControls(true)
        }
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val savedMap = prefs.getString("downloaded_map_uri", null)
        val savedTree = prefs.getString("maps_tree_uri", null)
        val mapUri = savedMap?.let { Uri.parse(it) } ?: savedTree?.let { findPersistentMap(Uri.parse(it)) }
        if (mapUri != null) {
            try {
                loadMap(mapUri)
                prefs.edit().putString("downloaded_map_uri", mapUri.toString()).apply()
            } catch (_: Exception) {
                info.text = "Карта в выбранной папке найдена, но недоступна. Выберите папку хранения ещё раз."
            }
        } else {
            val saved = prefs.getString("map_uri", null)
            if (!saved.isNullOrBlank()) {
                try { loadMap(Uri.parse(saved)) }
                catch (_: Exception) { info.text = "Ранее выбранная карта недоступна. Выберите файл .map заново." }
            }
        }
        intent.getStringExtra(EXTRA_SHOW_GPX_PATH)?.let { path ->
            if (mapDataStore != null) {
                try { drawGpxRoute(path) }
                catch (e: Exception) { info.text = "Не удалось показать GPX: ${e.message}" }
            } else {
                info.text = "Маршрут построен, но офлайн-карта не выбрана. Сначала выберите файл карты .map."
                Toast.makeText(this, "Сначала выберите офлайн-карту", Toast.LENGTH_LONG).show()
            }
        }
    }


    private fun drawGpxRoute(path: String) {
        val file = File(path)
        require(file.exists() && file.length() > 0L) { "GPX-файл не найден" }
        val points = mutableListOf<LatLong>()
        val parser = Xml.newPullParser()
        file.inputStream().buffered().use { input ->
            parser.setInput(input, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG &&
                    (parser.name == "trkpt" || parser.name == "rtept")) {
                    val lat = parser.getAttributeValue(null, "lat")?.toDoubleOrNull()
                    val lon = parser.getAttributeValue(null, "lon")?.toDoubleOrNull()
                    if (lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0) {
                        points.add(LatLong(lat, lon))
                    }
                }
                event = parser.next()
            }
        }
        require(points.size >= 2) { "В GPX не найдены точки трека" }

        routeOverlay?.let { old ->
            mapView.layerManager.layers.remove(old)
            old.onDestroy()
        }
        val linePaint: Paint = AndroidGraphicFactory.INSTANCE.createPaint().apply {
            setColor(Color.rgb(220, 35, 35))
            setStrokeWidth(6f)
            setStyle(Style.STROKE)
        }
        val line = Polyline(linePaint, AndroidGraphicFactory.INSTANCE)
        points.forEach { line.addPoint(it) }
        routeOverlay = line
        mapView.layerManager.layers.add(line)

        val minLat = points.minOf { it.latitude }
        val maxLat = points.maxOf { it.latitude }
        val minLon = points.minOf { it.longitude }
        val maxLon = points.maxOf { it.longitude }
        mapView.setCenter(LatLong((minLat + maxLat) / 2.0, (minLon + maxLon) / 2.0))
        mapView.setZoomLevel(13.toByte())
        mapView.layerManager.redrawLayers()
        info.text = "Маршрут GPX показан красной линией на офлайн-карте. Точек: ${points.size}."
    }

    private fun chooseStorageFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickFolderRequest)
    }

    private fun findPersistentMap(treeUri: Uri): Uri? {
        val tree = RegionStorage.regionFolder(this, "Maps") ?: DocumentFile.fromTreeUri(this, treeUri) ?: return null
        return tree.listFiles().firstOrNull { it.isFile && it.name?.endsWith(".map", true) == true && it.length() > 0L }?.uri
    }

    private fun formatMb(bytes: Long): String = String.format(java.util.Locale.US, "%.0f", bytes / 1048576.0)

    private fun chooseMap() {
        val treeText = prefs.getString("maps_tree_uri", null)
        val mapFiles = if (treeText.isNullOrBlank()) emptyList() else try {
            (RegionStorage.regionFolder(this, "Maps") ?: DocumentFile.fromTreeUri(this, Uri.parse(treeText)))?.listFiles()
                ?.filter { it.isFile && it.name?.endsWith(".map", ignoreCase = true) == true && it.length() > 0L }
                ?.sortedBy { it.name?.lowercase(java.util.Locale.ROOT) }
                ?: emptyList()
        } catch (_: Exception) { emptyList() }

        val options = mutableListOf<String>()
        mapFiles.forEach { options.add(it.name ?: "Карта Mapsforge") }
        options.add("Выбрать файл .map на устройстве…")

        AlertDialog.Builder(this)
            .setTitle("Выберите офлайн-карту")
            .setItems(options.toTypedArray()) { _, which ->
                if (which < mapFiles.size) {
                    val selected = mapFiles[which]
                    try {
                        loadMap(selected.uri)
                        prefs.edit().putString("downloaded_map_uri", selected.uri.toString()).apply()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Не удалось открыть карту: ${e.message ?: "ошибка файла"}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    openMapFilePicker()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun manageMaps() {
        val treeText = prefs.getString("maps_tree_uri", null)
        val tree = RegionStorage.regionFolder(this, "Maps") ?: treeText?.let { DocumentFile.fromTreeUri(this, Uri.parse(it)) }
        val maps = tree?.listFiles()?.filter {
            it.isFile && it.name?.endsWith(".map", true) == true && it.length() > 0L
        }?.sortedBy { it.name?.lowercase(java.util.Locale.ROOT) } ?: emptyList()
        if (maps.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Загруженные карты")
                .setMessage("В выбранной папке пока нет файлов .map. Выберите папку хранения или добавьте карту с устройства.")
                .setPositiveButton("ОК", null).show()
            return
        }
        val labels = maps.map { file ->
            "${file.name}  •  ${formatMb(file.length())} МБ"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Карты в выбранной папке")
            .setItems(labels) { _, index ->
                val selected = maps[index]
                AlertDialog.Builder(this)
                    .setTitle("Удалить карту?")
                    .setMessage("${selected.name}\nРазмер: ${formatMb(selected.length())} МБ\nФайл будет удалён из выбранной папки.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить") { _, _ ->
                        val wasCurrent = prefs.getString("downloaded_map_uri", null) == selected.uri.toString()
                        val deleted = selected.delete()
                        if (deleted && wasCurrent) prefs.edit().remove("downloaded_map_uri").apply()
                        Toast.makeText(this, if (deleted) "Карта удалена" else "Не удалось удалить файл", Toast.LENGTH_LONG).show()
                    }.show()
            }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun openMapFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, "Выберите карту Mapsforge (.map)")
        }
        startActivityForResult(intent, pickMapRequest)
    }

    @Deprecated("Uses the Storage Access Framework result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == pickFolderRequest) {
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(uri, flags)
                getSharedPreferences("region_storage", MODE_PRIVATE).edit().clear().apply()
                prefs.edit().putString("maps_tree_uri", uri.toString()).apply()
                val existing = findPersistentMap(uri)
                if (existing != null) {
                    prefs.edit().putString("downloaded_map_uri", existing.toString()).apply()
                    loadMap(existing)
                } else {
                    info.text = "Папка выбрана: ${DocumentFile.fromTreeUri(this, uri)?.name ?: "выбранная папка"}. Вернитесь в Центр загрузок, чтобы выбрать область карты и загрузить комплект данных."
                }
            } catch (e: Exception) { info.text = "Не удалось сохранить доступ к папке: ${e.message}" }
            return
        }
        if (requestCode == pickMapRequest) {
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                try { contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                prefs.edit().putString("map_uri", uri.toString()).apply()
                loadMap(uri)
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось открыть карту: ${e.message ?: "неверный файл"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadMap(uri: Uri) {
        info.text = "Открываю карту…"
        val pfd = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Не удалось открыть файл")
        val stream = FileInputStream(pfd.fileDescriptor)
        try {
            installMapStream(stream, pfd, uri.lastPathSegment?.substringAfterLast('/') ?: "карта")
        } catch (e: Exception) {
            try { stream.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
            throw e
        }
    }

    private fun installMapStream(stream: FileInputStream, pfd: ParcelFileDescriptor?, displayName: String) {
        var newStore: MapFile? = null
        try {
            newStore = MapFile(stream)
            val cache = AndroidUtil.createTileCache(
                this, "geotracker-mapsforge-cache",
                mapView.model.displayModel.tileSize, 1f,
                mapView.model.frameBufferModel.overdrawFactor
            )
            val layer = AndroidUtil.createTileRendererLayer(
                cache, mapView.model.mapViewPosition, newStore, MapsforgeThemes.DEFAULT
            )
            tileLayer?.let { old ->
                mapView.layerManager.layers.remove(old)
                old.onDestroy()
            }
            mapDataStore?.close()
            mapInputStream?.close()
            mapPfd?.close()
            tileCache?.destroy()
            mapDataStore = newStore
            mapInputStream = stream
            mapPfd = pfd
            tileCache = cache
            tileLayer = layer
            mapView.layerManager.layers.add(layer)
            val center = newStore.startPosition() ?: LatLong(46.5, 11.9)
            mapView.setCenter(center)
            mapView.setZoomLevel((newStore.startZoomLevel() ?: 10.toByte()).toByte())
            mapView.layerManager.redrawLayers()
            info.text = "Загружена офлайн-карта: $displayName\nМасштабируйте и перемещайте карту. Интернет не требуется."
            newStore = null
        } catch (e: Exception) {
            try { newStore?.close() } catch (_: Exception) {}
            throw e
        }
    }

    override fun onDestroy() {
        try { mapView.destroyAll() } catch (_: Exception) {}
        try { mapDataStore?.close() } catch (_: Exception) {}
        try { mapPfd?.close() } catch (_: Exception) {}
        try { mapInputStream?.close() } catch (_: Exception) {}
        try { tileCache?.destroy() } catch (_: Exception) {}
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
