package com.example.altimetergps

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import org.mapsforge.core.model.LatLong
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.datastore.MapDataStore
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.internal.MapsforgeThemes
import java.io.FileInputStream
import android.os.ParcelFileDescriptor

/** First-stage offline Mapsforge map viewer. It reads the selected .map file directly
 * through Android's Storage Access Framework; it does not copy a 1-2 GB map into app storage. */
class OfflineMapActivity : Activity() {
    private lateinit var mapView: MapView
    private lateinit var info: TextView
    private var mapDataStore: MapDataStore? = null
    private var tileLayer: TileRendererLayer? = null
    private var tileCache: TileCache? = null
    private var mapPfd: ParcelFileDescriptor? = null
    private val pickMapRequest = 4101
    private val prefs by lazy { getSharedPreferences("mapsforge", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 36, 58))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val title = TextView(this).apply {
            text = "ОФЛАЙН-КАРТА MAPSFORGE"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(4, dp(8), 4, dp(8))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        info = TextView(this).apply {
            text = "Выберите файл карты Mapsforge (.map). После открытия карта будет работать без интернета."
            textSize = 13f
            setTextColor(Color.rgb(210, 225, 235))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(8))
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(Button(this).apply {
            text = "ВЫБРАТЬ КАРТУ"
            setOnClickListener { chooseMap() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply {
            text = "ДОЛОМИТЫ"
            setOnClickListener {
                mapView.setCenter(LatLong(46.5, 11.9))
                mapView.setZoomLevel(10.toByte())
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))

        mapView = MapView(this).apply {
            setBuiltInZoomControls(true)
        }
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val saved = prefs.getString("map_uri", null)
        if (!saved.isNullOrBlank()) {
            try {
                loadMap(Uri.parse(saved))
            } catch (_: Exception) {
                info.text = "Ранее выбранная карта недоступна. Выберите файл .map заново."
            }
        }
    }

    private fun chooseMap() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, "Выберите карту Mapsforge (.map)")
        }
        startActivityForResult(intent, pickMapRequest)
    }

    @Deprecated("Uses the Storage Access Framework result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickMapRequest || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("map_uri", uri.toString()).apply()
            loadMap(uri)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть карту: ${e.message ?: "неверный файл"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadMap(uri: Uri) {
        info.text = "Открываю карту…"
        val pfd = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Не удалось открыть файл")
        var newStore: MapFile? = null
        try {
            val stream = FileInputStream(pfd.fileDescriptor)
            newStore = MapFile(stream)
            val cache = AndroidUtil.createTileCache(
                this, "geotracker-mapsforge-cache",
                mapView.model.displayModel.tileSize, 1f,
                mapView.model.frameBufferModel.overdrawFactor
            )
            val layer = AndroidUtil.createTileRendererLayer(
                cache, mapView.model.mapViewPosition, newStore, MapsforgeThemes.DEFAULT
            )

            tileLayer?.let { old ->
                mapView.layerManager.layers.remove(old)
                old.onDestroy()
            }
            mapDataStore?.close()
            mapPfd?.close()
            tileCache?.destroy()

            mapDataStore = newStore
            mapPfd = pfd
            tileCache = cache
            tileLayer = layer
            mapView.layerManager.layers.add(layer)
            val center = newStore.startPosition() ?: LatLong(46.5, 11.9)
            mapView.setCenter(center)
            mapView.setZoomLevel((newStore.startZoomLevel() ?: 10.toByte()).toByte())
            mapView.layerManager.redrawLayers()
            val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "карта"
            info.text = "Загружена офлайн-карта: $fileName\nМасштабируйте и перемещайте карту. Интернет не требуется."
            newStore = null
        } catch (e: Exception) {
            try { newStore?.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
            throw e
        }
    }

    override fun onDestroy() {
        try { mapView.destroyAll() } catch (_: Exception) {}
        try { mapDataStore?.close() } catch (_: Exception) {}
        try { mapPfd?.close() } catch (_: Exception) {}
        try { tileCache?.destroy() } catch (_: Exception) {}
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
