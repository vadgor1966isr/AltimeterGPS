package com.example.altimetergps

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), LocationListener {
    private lateinit var locationManager: LocationManager
    private lateinit var altitudeText: TextView
    private lateinit var statusText: TextView
    private lateinit var coordinatesText: TextView
    private lateinit var accuracyText: TextView
    private lateinit var gpsText: TextView
    private lateinit var pinText: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastElevationRequest = 0L
    private var lastRequestedLocation: Location? = null
    private var pinnedAltitude: Double? = null
    private var latestGpsAltitude: Double? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        buildScreen()
        if (hasLocationPermission()) startGps() else {
            requestPermissions(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ), 100)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFF3F6FA.toInt())
        }

        fun label(text: String, size: Float, color: Int = 0xFF263238.toInt()): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
            }

        root.addView(label("ALTIMETER GPS", 18f))
        root.addView(label("ВЫСОТА НАД УРОВНЕМ МОРЯ", 14f).apply {
            setPadding(0, 32, 0, 8)
        })
        altitudeText = label("— м", 58f, 0xFF1565C0.toInt())
        root.addView(altitudeText)
        statusText = label("Ожидание сигнала GPS…", 14f)
        statusText.setPadding(0, 8, 0, 24)
        root.addView(statusText)
        coordinatesText = label("Координаты: —", 15f)
        root.addView(coordinatesText)
        accuracyText = label("Точность GPS: —", 15f)
        accuracyText.setPadding(0, 10, 0, 0)
        root.addView(accuracyText)
        gpsText = label("Высота GPS: —", 14f, 0xFF607D8B.toInt())
        gpsText.setPadding(0, 8, 0, 0)
        root.addView(gpsText)

        val pinButton = Button(this).apply {
            text = "Зафиксировать высоту"
            setOnClickListener {
                pinnedAltitude = altitudeText.text.toString()
                    .replace(" м", "").replace(",", ".")
                    .toDoubleOrNull()
                pinText.text = pinnedAltitude?.let {
                    "Зафиксировано: ${String.format(Locale.getDefault(), "%.0f м", it)}"
                } ?: "Пока нет значения высоты"
            }
        }
        pinButton.setPadding(0, 12, 0, 12)
        root.addView(pinButton)
        pinText = label("Зафиксированная высота: —", 14f)
        pinText.setPadding(0, 12, 0, 0)
        root.addView(pinText)

        root.addView(label(
            "Высота над уровнем моря берётся из цифровой модели рельефа через интернет. " +
                "Результат ориентировочный; точность зависит от GPS и карты высот.",
            12f, 0xFF607D8B.toInt()
        ).apply { setPadding(0, 28, 0, 0) })

        setContentView(root)
    }

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startGps() {
        if (!hasLocationPermission()) return
        try {
            statusText.text = "Поиск спутников GPS…"
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 3000L, 3f, this, Looper.getMainLooper()
            )
            val last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (last != null) onLocationChanged(last)
        } catch (e: SecurityException) {
            statusText.text = "Нет разрешения на геолокацию"
        } catch (e: Exception) {
            statusText.text = "Не удалось запустить GPS"
        }
    }

    override fun onLocationChanged(location: Location) {
        latestGpsAltitude = if (location.hasAltitude()) location.altitude else null
        coordinatesText.text = String.format(
            Locale.US, "Координаты: %.5f, %.5f", location.latitude, location.longitude
        )
        accuracyText.text = if (location.hasAccuracy()) {
            "Точность GPS: ±${location.accuracy.toInt()} м"
        } else "Точность GPS: неизвестна"
        gpsText.text = latestGpsAltitude?.let {
            String.format(Locale.getDefault(), "Высота GPS (сырая): %.0f м", it)
        } ?: "Высота GPS: нет данных"

        statusText.text = "Координаты получены. Определяем высоту по карте…"
        val now = System.currentTimeMillis()
        val previous = lastRequestedLocation
        val movedEnough = previous == null || previous.distanceTo(location) > 25f
        if (now - lastElevationRequest > 15000L && movedEnough) {
            lastElevationRequest = now
            lastRequestedLocation = Location(location)
            fetchSeaLevelElevation(location.latitude, location.longitude)
        }
    }

    private fun fetchSeaLevelElevation(lat: Double, lon: Double) {
        worker.execute {
            var connection: HttpURLConnection? = null
            try {
                val url = URL("https://api.open-elevation.com/api/v1/lookup?locations=$lat,$lon")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 10000
                    requestMethod = "GET"
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val elevation = JSONObject(body)
                    .getJSONArray("results")
                    .getJSONObject(0)
                    .getDouble("elevation")
                mainHandler.post {
                    altitudeText.text = String.format(Locale.getDefault(), "%.0f м", elevation)
                    statusText.text = "Высота по карте рельефа • обновлено сейчас"
                }
            } catch (e: Exception) {
                mainHandler.post {
                    val fallback = latestGpsAltitude
                    if (fallback != null) {
                        altitudeText.text = String.format(Locale.getDefault(), "%.0f м*", fallback)
                        statusText.text = "Нет ответа сервиса высот. Показана сырая высота GPS*"
                    } else {
                        statusText.text = "Не удалось получить высоту. Проверьте интернет и GPS."
                    }
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    override fun onProviderEnabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) statusText.text = "GPS включён"
    }

    override fun onProviderDisabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) statusText.text = "Включите GPS в настройках телефона"
    }

    @Deprecated("Deprecated in Android API")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && hasLocationPermission()) startGps()
        else statusText.text = "Для работы приложения нужно разрешить доступ к геолокации"
    }

    override fun onDestroy() {
        super.onDestroy()
        try { locationManager.removeUpdates(this) } catch (_: Exception) {}
        worker.shutdownNow()
    }
}
