plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.example.altimetergps"
 compileSdk = 35
 defaultConfig { applicationId = "com.example.altimetergps"; minSdk = 26; targetSdk = 35; versionCode = 18; versionName = "3.6" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
